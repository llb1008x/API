#ifndef __CONST__H__
#define __CONST__H__

#define PLUGIN_VERSION	"v1.3a"
#define PLUGIN_TITLE	" ��ǿ��"

#define SI_BUF_SIZE			256

#define SI_CLASSNAME_FRAME	"si_frame"
#define SI_CLASSNAME_MDI	"MDIClient"
#define SI_DLLNAME_UTF8		"siutf8.dll"

#define SI_TAB_HEIGHT		24
#define SI_TAB_CLOSE_IDX	256

#endif
