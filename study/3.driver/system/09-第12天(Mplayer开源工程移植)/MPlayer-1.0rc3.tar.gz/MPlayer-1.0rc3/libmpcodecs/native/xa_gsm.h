#ifndef MPLAYER_XA_GSM_H
#define MPLAYER_XA_GSM_H

void XA_MSGSM_Decoder(unsigned char *ibuf,unsigned short *obuf);
void XA_GSM_Decoder(unsigned char *ibuf,unsigned short *obuf);
void GSM_Init(void);

#endif /* MPLAYER_XA_GSM_H */
