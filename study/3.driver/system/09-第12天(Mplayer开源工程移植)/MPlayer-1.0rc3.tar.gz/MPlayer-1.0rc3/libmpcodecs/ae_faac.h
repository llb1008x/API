#ifndef MPLAYER_AE_FAAC_H
#define MPLAYER_AE_FAAC_H

#include "ae.h"
#include "libmpdemux/muxer.h"

int mpae_init_faac(audio_encoder_t *encoder);

#endif /* MPLAYER_AE_FAAC_H */
