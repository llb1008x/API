#ifndef MPLAYER_AE_PCM_H
#define MPLAYER_AE_PCM_H

#include "ae.h"

int mpae_init_pcm(audio_encoder_t *encoder);

#endif /* MPLAYER_AE_PCM_H */
