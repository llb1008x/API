#ifndef MPLAYER_AE_LAME_H
#define MPLAYER_AE_LAME_H

#include "ae.h"

int mpae_init_lame(audio_encoder_t *encoder);

#endif /* MPLAYER_AE_LAME_H */
