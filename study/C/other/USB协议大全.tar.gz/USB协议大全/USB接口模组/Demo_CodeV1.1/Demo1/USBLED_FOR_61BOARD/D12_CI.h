#ifndef	__D12CI_h__
#define	__D12CI_h__
//	write your header here

#define D12_NOLAZYCLOCK			0x02
#define D12_CLOCKRUNNING		0x04
#define D12_INTERRUPTMODE		0x08
#define D12_SOFTCONNECT			0x10
#define D12_ENDP_NONISO			0x00
#define D12_ENDP_ISOOUT			0x40
#define D12_ENDP_ISOIN			0x80
#define D12_ENDP_ISOIO			0xC0
#define D12_CLOCK_12M			0x03
#define D12_CLOCK_4M			0x0b
#define D12_SETTOONE			0x40
#define D12_SOFONLY				0x80

#define D12_FULLEMPTY			0x01

void D12_SetAddressEnable(unsigned int bAddress, unsigned int bEnable);
void D12_SetEndpointEnable(unsigned int bEnable);
void D12_SetMode(unsigned int bConfig, unsigned int bClkDiv);
void D12_SetDMA(unsigned int bMode);
unsigned int D12_ReadInterruptRegister(void);
unsigned int D12_SelectEndpoint(unsigned int bEndp);
unsigned int D12_ReadLastTransactionStatus(unsigned int bEndp);
unsigned int D12_ReadEndpoint(unsigned int endp, unsigned int len, unsigned int * buf);
unsigned int D12_WriteEndpoint(unsigned int endp, unsigned int len, unsigned int * buf);
void D12_SetEndpointStatus(unsigned int bEndp, unsigned int bStalled);
void D12_AcknowledgeEndpoint(unsigned int endp);
unsigned int D12_ReadEndpointAndClrD12Int(unsigned int endp, unsigned int len, unsigned int * buf);
unsigned int D12_WriteEndpointAndClrD12Int(unsigned int endp, unsigned int len, unsigned int * buf);

#endif