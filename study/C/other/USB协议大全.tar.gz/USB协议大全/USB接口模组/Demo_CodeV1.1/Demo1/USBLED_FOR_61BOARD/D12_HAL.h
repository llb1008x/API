#ifndef	__D12HAL_h__
#define	__D12HAL_h__
//	write your header here
void D12_Initial(void);
void D12_InitWrite(void);
void D12_InitRead(void);
unsigned int D12_Read();
void D12_Write(unsigned int D_or_C_Addr, unsigned int Data_or_Command);

#endif
