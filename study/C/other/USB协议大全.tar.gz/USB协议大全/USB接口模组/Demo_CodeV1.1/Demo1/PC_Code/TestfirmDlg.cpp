// TestfirmDlg.cpp : implementation file
#include "stdafx.h"
#include "Testfirm.h"
#include "TestfirmDlg.h"
//#include "Rwbulk.h"
//#include "Device.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
BOOL bFlag = 0;
HANDLE open_file( char *);

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg dialog

CTestfirmDlg::CTestfirmDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestfirmDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestfirmDlg)
	m_UsbReceive = _T("");

	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	hDeviceReadEp2=INVALID_HANDLE_VALUE;
	hDeviceWriteEp2=INVALID_HANDLE_VALUE;
	hDeviceWriteEp1=INVALID_HANDLE_VALUE;
	ID0=1;
	ID1=2;
	ID2=3;
	ulSendDataLength=0;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestfirmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestfirmDlg)
	DDX_Control(pDX, IDC_USBRECEIVE1_EDIT, m_UsbReceive_Edit);
	DDX_Control(pDX, IDC_USBSEND_EDIT, m_UsbSend_Edit);

	DDX_Text(pDX, IDC_USBRECEIVE1_EDIT, m_UsbReceive);

	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestfirmDlg, CDialog)
	//{{AFX_MSG_MAP(CTestfirmDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPENUSB_BUTTON, OnOpenusbButton)
	ON_BN_CLICKED(IDC_CLOSEUSB_BUTTON, OnCloseusbButton)
	ON_BN_CLICKED(IDC_USBSEND_BUTTON, OnUsbsendButton)
	ON_BN_CLICKED(IDC_USBRECEIVE_BUTTON, OnUsbreceiveButton)
	ON_BN_CLICKED(IDC_CONNECTTEST_BUTTON, OnConnecttestButton)
	ON_BN_CLICKED(IDC_LED1ON_BUTTON, OnLed1onButton)
	ON_BN_CLICKED(IDC_LED2ON_BUTTON, OnLed2onButton)
	ON_BN_CLICKED(IDC_LED1OFF_BUTTON, OnLed1offButton)
	ON_BN_CLICKED(IDC_LED2OFF_BUTTON, OnLed2offButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg message handlers

BOOL CTestfirmDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestfirmDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestfirmDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestfirmDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestfirmDlg::OnOK() 
{


	CDialog::OnOK();
}

void CTestfirmDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CTestfirmDlg::OnOpenusbButton() 
{
	// TODO: Add your control notification handler code here
	char *filename1="PIPE02";
	char *filename2="PIPE03";
	char *filename3="PIPE01";
	bFlag = 1;
	hDeviceReadEp2=open_file(filename1);//open endpoint2in
	hDeviceWriteEp2=open_file(filename2);//open endpoint2out
	hDeviceWriteEp1=open_file(filename3);
	if (hDeviceReadEp2 == INVALID_HANDLE_VALUE||hDeviceWriteEp2 == INVALID_HANDLE_VALUE || hDeviceWriteEp1 == INVALID_HANDLE_VALUE)
	{
		//AfxMessageBox("ERROR opening device: (%0d) returned from CreateFile\n", GetLastError());
		AfxMessageBox("ERROR open EndPoint: returned from open_File\n");
	}
	else
	{
		AfxMessageBox("Device found, EndPoint2  open .\n");
	}

}


void CTestfirmDlg::OnUsbsendButton() 
{
	// TODO: Add your control notification handler code here
	ULONG	ulWriteLen=0;
	ULONG   ulReadLen=0;
//	ULONG   ulSendDataLength=0;
	char aSendId[2];
	char aReceiveId[1];
	char aSendData[66];
    
	if(bFlag)
	{
		ulWriteLen=0;
		aSendId[0]=ID2;
		aSendId[1]=1;
	
		ulSendDataLength=m_UsbSend_Edit.GetWindowTextLength();
		if(ulSendDataLength>=65)
		{
			AfxMessageBox("�ַ����ͳɹ�����64BYTES,��һ�η���С��64BYTES\n");
			ulSendDataLength = 0;
			return;
		}
		if(!ulSendDataLength)
		{
			AfxMessageBox("�벻Ҫ�����ַ�\n");
			return;
		}

		while(ulWriteLen !=2)
		{
			WriteFile(hDeviceWriteEp1,aSendId,2, &ulWriteLen, NULL);
		}
		ulReadLen=0;
		aReceiveId[1]=0;
		while(ulReadLen !=1)
		{
			ReadFile(hDeviceReadEp2, aReceiveId, 1, &ulReadLen, NULL);	 
		}
		ulSendDataLength=m_UsbSend_Edit.GetWindowTextLength();
	
		m_UsbSend_Edit.GetWindowText(aSendData,ulSendDataLength+1);

		if(ulSendDataLength<=64)
		{

			while(ulWriteLen !=ulSendDataLength)
			{
				WriteFile(hDeviceWriteEp2,aSendData, ulSendDataLength, &ulWriteLen, NULL);
			}
			AfxMessageBox("�ַ����ͳɹ�\n");
		}


	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}
void CTestfirmDlg::OnUsbreceiveButton() 
{
	// TODO: Add your control notification handler code here
    CString show,tmp;

	ULONG	ulWriteLen=0;
	ULONG   ulReadLen=0;
//	ULONG   ulSendDataLength=0;
	char aSendId[2];
//	char aReceiveId[1];
	char aReceiveData[66];
	
	if(bFlag)
	{
		m_UsbReceive_Edit.SetSel(0,-1);
		m_UsbReceive_Edit.ReplaceSel("");

		aSendId[0]=ID2;
		aSendId[1]=2;
		ulWriteLen=0;
		while(ulWriteLen !=2)
		{
			WriteFile(hDeviceWriteEp1,aSendId,2, &ulWriteLen, NULL);
		}
		ulReadLen=0;
		while(ulReadLen !=ulSendDataLength)
		{
			ReadFile(hDeviceReadEp2, aReceiveData, ulSendDataLength, &ulReadLen, NULL);	 
		}
		for(unsigned int i=0;i<ulSendDataLength;i++)
		{
			show+=aReceiveData[i];
		}
		m_UsbReceive=show;
		UpdateData(FALSE);
		AfxMessageBox("�����ַ��ɹ�\n");
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}



void CTestfirmDlg::OnCloseusbButton() 
{
	// TODO: Add your control notification handler code here
	bFlag = 0;
	CloseIfOpen();
}

void CTestfirmDlg::CloseIfOpen(void)
{
	if (hDeviceReadEp2 != INVALID_HANDLE_VALUE)
	{

		if (!CloseHandle(hDeviceReadEp2))
		{
			AfxMessageBox("ERROR: CloseHandle1 returns: %ld \n", GetLastError());
		}
	 	hDeviceReadEp2 = INVALID_HANDLE_VALUE;
	}
	
	if (hDeviceWriteEp2 != INVALID_HANDLE_VALUE)
	{

		if (!CloseHandle(hDeviceWriteEp2))
		{
			AfxMessageBox("ERROR: CloseHandle1 returns: %ld \n", GetLastError());
		}
	 	hDeviceWriteEp2 = INVALID_HANDLE_VALUE;
	}
	if (hDeviceWriteEp1 != INVALID_HANDLE_VALUE)
	{

		if (!CloseHandle(hDeviceWriteEp1))
		{
			AfxMessageBox("ERROR: CloseHandle1 returns: %ld \n", GetLastError());
		}
	 	hDeviceWriteEp2 = INVALID_HANDLE_VALUE;
	}
	AfxMessageBox("CloseHandle success\n");

}





void CTestfirmDlg::OnConnecttestButton() 
{
	// TODO: Add your control notification handler code here
	CString show,tmp;
	char  Recievedata[1];
	char  Senddata[2];
	int i;
	ULONG nRead,nWrite;
	if(bFlag)
	{
		m_UsbReceive_Edit.SetSel(0,-1);
		m_UsbReceive_Edit.ReplaceSel("");

		Senddata[0]=ID0;
		WriteFile(hDeviceWriteEp1, Senddata, 2, &nWrite, NULL);
		for(i=0;i<50000;i++)
		{

		};
		Recievedata[0]=0x0;
		ReadFile(hDeviceReadEp2, Recievedata, 1, &nRead, NULL);
		if(Recievedata[0]==ID0)
		{
			show="ID0=";
			tmp.Format("%x",Recievedata[0]); 
			show+=tmp;
			show+=' ';
			m_UsbReceive=show;
			UpdateData(FALSE);
			AfxMessageBox("USB�������ӳɹ�\n");
		}
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}






void CTestfirmDlg::OnLed1onButton() 
{
	// TODO: Add your control notification handler code here
	char  Senddata[2];
	ULONG nWrite;
	if(bFlag)
	{
		Senddata[0]=ID1;
		Senddata[1]=1;
		WriteFile(hDeviceWriteEp1, Senddata, 2, &nWrite, NULL);
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
   
}

void CTestfirmDlg::OnLed2onButton() 
{
	// TODO: Add your control notification handler code here
	char  Senddata[2];
	ULONG nWrite;
	if(bFlag)
	{
		Senddata[0]=ID1;
		Senddata[1]=3;
		WriteFile(hDeviceWriteEp1, Senddata, 2, &nWrite, NULL);
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}

void CTestfirmDlg::OnLed1offButton() 
{
	// TODO: Add your control notification handler code here
	char  Senddata[2];
	ULONG nWrite;
	if(bFlag)
	{
		Senddata[0]=ID1;
		Senddata[1]=0;
		WriteFile(hDeviceWriteEp1, Senddata, 2, &nWrite, NULL);
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}

void CTestfirmDlg::OnLed2offButton() 
{
	// TODO: Add your control notification handler code here
	char  Senddata[2];
	ULONG nWrite;
	if(bFlag)
	{
		Senddata[0]=ID1;
		Senddata[1]=2;
		WriteFile(hDeviceWriteEp1, Senddata, 2, &nWrite, NULL);
	}
	else
	{
		AfxMessageBox("���ȴ�USB����\n");
	}
}
