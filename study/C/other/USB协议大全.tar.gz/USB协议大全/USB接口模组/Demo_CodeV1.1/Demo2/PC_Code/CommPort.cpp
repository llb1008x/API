
int ReadFile(CHAR *filename)
{
		int ret=1;
		CString msg;
        char temps[0x10];
        FILE *FileIn=fopen(filename,"rb");

        if (FileIn==NULL) {
			msg.Format("Can not open file : %s",filename);
			AfxMessageBox(msg);
			return 0;
		}
        fseek(FileIn,0,SEEK_END);
		//��ָ��ָ���ļ��Ľ�β
        m_filelen=ftell(FileIn)-256; 
		//ftell()�õ���ǰ��ָ��ƫ��ͷ�ļ���λ��
        fseek(FileIn,0,SEEK_SET);
        //���ļ�ָ��ָ���ļ��Ŀ�ʼ��
		//BYTE* m_Buffer=NULL;
		if (m_Buffer!=NULL) {
			//m_hwnd = this->m_hWnd
			SetWindowText(m_hwnd,"DVR - Buffer is freeing, please wait ...");
			free(m_Buffer);
			m_Buffer = NULL;
			SetWindowText(m_hwnd,"DVR");
		}
		m_Buffer=(BYTE*)malloc(m_filelen+0x10000);//m_filelen+64k
		memset(&m_Buffer[m_filelen],0xFF,0x10000);

		fread(m_filemsg,1,256,FileIn);
	    //BYTE m_filemsg[256];һ�ζ�һ���ֽڶ�256�Ρ��浽m_filemsg����
		//FileInΪ�ļ���ָ�룬m_filemsgΪָ�루ָ�������ݵ����飩
		memset(temps,0,0x10);
		//char temps[0x10];
		memcpy(temps,&m_filemsg[0xf0],0x0f);
		//���ļ��ĵ�240���ֽں��15�����ݿ�����temps
		//char m_format[0x10] = "SACM FORMAT 1.0";
		if (strcmp(temps,m_format)){//format is not right
		  //msg.Format("File format is not right!!");
		  //AfxMessageBox(msg);
		  return 2;
		}
		DWORD block = 512;
		DWORD rsize=0,percount=0,count;
		BYTE *p=m_Buffer;
		float flen100=((float)m_filelen)/100;
		if (flen100 == 0)
			flen100=1;
		//feof( FileIn ) �����ļ�β�����ط���		
		while( !feof( FileIn ) )   {
			//ÿ�ζ�1���ֽ�
			count=fread( p, 1, block, FileIn );
			rsize += count;
			p += count;

			if ( rsize > flen100*percount) {
				percount++;
				msg.Format("DVR - Read file %3.0i%%",(int)(rsize/flen100));
				SetWindowText(m_hwnd,msg);
			}
			//CString msg;
			MSG wmsg;
			if (::PeekMessage(&wmsg,NULL,0,0,PM_REMOVE)){
				::TranslateMessage(&wmsg);
				::DispatchMessage(&wmsg);
				if (wmsg.message==WM_CHAR){ 
					if (wmsg.wParam == VK_ESCAPE) {
						ret = 0;
						break;
					}
				}
			}
		}
		
		SetWindowText(m_hwnd,"DVR");

		fclose(FileIn);
		return ret;
}

void WriteFile(CHAR *filename)
{
		int ret=1;
		CString msg;
        FILE *FileOut;
        FileOut = fopen(filename,"wb");

		if (FileOut==NULL) 
		{
			msg.Format("Can not open file : %s",filename);
			AfxMessageBox(msg);
			return;
		}
		//BYTE m_filemsg[256]
		//ReadFile(hComm,m_buf0,258,&m_lrc,NULL);//BYTE m_buf0[300]
		//memcpy(m_filemsg,m_buf0,256);//BYTE m_filemsg[256];
		fwrite(m_filemsg,1,0xF0,FileOut);
		fwrite(m_format,1,0x10,FileOut);
		DWORD block = 512;
		DWORD wtsize=0,percount=0,wsize;
		BYTE *p=m_Buffer;//m_BufferΪȫ�ֱ���,������ص�PC�����ϡ�
		float flen100=((float)m_filelen)/100;
		if (flen100 == 0)
			flen100=1;
		
		while (wtsize < m_filelen) 
		{
			wsize = ((m_filelen-wtsize) > block) ? block : (m_filelen-wtsize);
			fwrite(p,1,wsize,FileOut);//��p�д�ŵ�����д��FileOut�ļ���
			wtsize += wsize;
			p += wsize;

			if ( wtsize > flen100*percount)
			{
				percount++;
				msg.Format("DVR - Write file %3.0i%%",(int)(wtsize/flen100));
				SetWindowText(m_hwnd,msg);
			}
			MSG wmsg;
			if (::PeekMessage(&wmsg,NULL,0,0,PM_REMOVE))
			{
				::TranslateMessage(&wmsg);
				::DispatchMessage(&wmsg);
				if (wmsg.message==WM_CHAR)
				{ 
					if (wmsg.wParam == VK_ESCAPE)
					{
						break;
					}
				}
			}
		}

		SetWindowText(m_hwnd,"DVR");

		fclose(FileOut);
}

int FunDownload(GDFS3 *fp3) 
{
    // TODO: Add your command handler code here
    DWORD i;
    DWORD temp;
    CString msg;
    //check if enough ram
     //check if enough ram
 
	//DWORD temp; 
	//BYTE m_filemsg[256];
    
        //1.Write message info to PC
   
        //2.Download data
        i=0;
        while(1)
		{
                memset(m_buf0,0x00,2);
                m_buf1[0]=0xFF;
                m_buf1[2]=SD_DnldH;       
                m_buf1[1]=SD_DnldL+1;
                WriteFile(hComm,m_buf1,3,&m_lrc,NULL);
				////////��Ҫ��ʱ�𣿣�������
                ReadFile(hComm,m_buf0,2,&m_lrc,NULL);
                if ((m_buf0[0]!=RD_DnldL+1)||(m_buf0[1]!=RD_DnldH))
				{
                        //process error 
                        return 2;
                }
                memcpy(m_buf1,&m_Buffer[i],256);    
				
				//--------------------------------------------------------
				//���������ص�������
				//--------------------------------------------------------
                DnldChecksum();
                WriteFile(hComm,m_buf1,258,&m_lrc,NULL);
                ReadFile(hComm,m_buf0,2,&m_lrc,NULL);
                if (((m_buf0[0]&0x7F)!=(RD_DnldL+1))||(m_buf0[1]!=RD_DnldH))
				{
                        //process error
                        return 2;
                }
                if ((m_buf0[0]&0x80)==0)
				{ //not rednld
                        if (i>=m_filelen) break;
                        i = i+256;
                        int percent=0;
						if (m_filelen > 0)
							percent=(int)i*100/m_filelen;
                        if (percent > 100)
                                percent=100;
                        fp3(percent);
                        MSG msg;
                        if (::PeekMessage(&msg,NULL,0,0,PM_REMOVE))
						{
                            ::TranslateMessage(&msg);
                                ::DispatchMessage(&msg);
                                if (msg.message==WM_CHAR)
								{ 
                                   if (msg.wParam == VK_ESCAPE)
								   {
                                          return 3;
                                   }
                                }
                        }
                }
        }
        //3.end download
        while (1)
		{
                m_buf1[0]=0xFF;
                m_buf1[1]=SD_DnldL+2;
                m_buf1[2]=SD_DnldH;
                WriteFile(hComm,m_buf1,3,&m_lrc,NULL);
                ReadFile(hComm,m_buf0,2,&m_lrc,NULL);
                if ((m_buf0[0]!=RD_DnldL+2)||(m_buf0[1]!=RD_DnldH))
				{
                        //process error 
                        return 2;
                }
                memset(m_buf1,0xFF,256);
                DnldChecksum();
                WriteFile(hComm,m_buf1,258,&m_lrc,NULL);
                ReadFile(hComm,m_buf0,2,&m_lrc,NULL);
                if (((m_buf0[0]&0x7F)!=(RD_DnldL+2))||(m_buf0[1]!=RD_DnldH))
				{
                        //process error
                        return 2;
                }
                if ((m_buf0[0]&0x80)==0) break;
        }

        return 1;

}


int FunUpload(int msgno,GDFS3 *fp3) 
{
        // TODO: Add your command handler code here
        DWORD i,ret;
        DWORD len;
        WORD  temp;
        BYTE  count;
        CString msg;
        //BYTE m_msgno
        m_msgno=msgno;

		m_buf1[0] = 0xFF;
		m_buf1[1] = SD_ConnectL;  //#define SD_ConnectL 0x5C
		m_buf1[2] = SD_ConnectH;  //#define SD_ConnectH 0xAA
        WriteFile(hComm,m_buf1,3,&m_lrc,NULL);//BYTE m_buf1[300]
        ReadFile(hComm,m_buf0,2,&m_lrc,NULL);//BYTE m_buf0[300]
        //1.upload message info
      
       

        //2.upload data
		if (m_Buffer!=NULL) {free(m_Buffer);m_Buffer = NULL;}
		m_Buffer=(BYTE*)malloc(len+0x10000);
        i=0;
        count=0;
        m_buf1[0]=0xFF;
        m_buf1[1]=SD_UploadL+m_msgno;////#define SD_UploadL  0x00
        m_buf1[2]=SD_UploadH;//#define SD_UploadH  0xD0
        while(1)
		{
                WriteFile(hComm,m_buf1,3,&m_lrc,NULL);
				//��Ҫ��ʱ�𣿣�������������������������������������
                ReadFile(hComm,m_buf0,2,&m_lrc,NULL);
                if ((m_buf0[0]!=(RD_UploadL+1))||(m_buf0[1]!=RD_UploadH))
				{
                        if ((m_buf0[0]==(RD_UploadL+2))&&(m_buf0[1]==RD_UploadH))
						{
                                m_filelen=i;
                                ReadFile(hComm,m_buf0,258,&m_lrc,NULL);
                                if (m_lrc!=258)
								{
                                        //process error
                                        return 2;
                                }
                                break;
                        }
                        //process error
                        return 2;
                }
                ReadFile(hComm,m_buf0,258,&m_lrc,NULL);//BYTE m_buf0[300]
                if (m_lrc==258)
				{
                        ret=UpldChecksum();
                        if (ret==1)
						{
                                // process message
                                m_buf1[1]=SD_UploadL+m_msgno;
								// m_Buffer=(BYTE*)malloc(len+0x10000);
                                memcpy(&m_Buffer[i],m_buf0,256);
                                i=i+256;
                                count=0;
                                int percent=0;
								if (len > 0)
									percent=(int)i*100/len;
                                if (percent > 100)
                                        percent=100;
                                fp3(percent);
                                MSG msg;
                                if (::PeekMessage(&msg,NULL,0,0,PM_REMOVE))
								{
                                        ::TranslateMessage(&msg);
                                        ::DispatchMessage(&msg);
                                        if (msg.message==WM_CHAR)
										{ 
                                           if (msg.wParam == VK_ESCAPE) 
										   {
                                                  return 3;
                                           }
                                        }
                                }
                                        
                        }
                        else m_buf1[1]=SD_UploadL+0x80+m_msgno;
                }
                else 
				{
                        m_buf1[1]=SD_UploadL+0x80+m_msgno;      
                        count = count + 1;
                        if (count == 20 )
						{
                                return 4;
                        }
                }
        }
        return 1;

}

/*
void let_msg_go()
{
  MSG msg;
  while ( ::PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) ){ 
        if ( msg.message==WM_QUIT ){ 
          ::PostQuitMessage(-1); 
          return;
        } 
        if (!AfxGetApp()->PreTranslateMessage(&msg)){
          ::TranslateMessage(&msg);
          ::DispatchMessage(&msg);
        }
  }                              
  AfxGetApp()->OnIdle(0);
  AfxGetApp()->OnIdle(1);
}

*/