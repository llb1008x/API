
HANDLE open_dev();
HANDLE open_file( char *filename);

