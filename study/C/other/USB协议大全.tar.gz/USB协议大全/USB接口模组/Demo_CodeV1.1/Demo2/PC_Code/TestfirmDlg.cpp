// TestfirmDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Testfirm.h"
#include "TestfirmDlg.h"
//#include "SHFileInfo1.h"

#include "Rwbulk.h"
#include "stdio.h"//for fread()
#include "memory.h"
#include "mmsystem.h"  //play wave
//----------
//#include "CommPort.h"
//#include "CommPort.cpp"
//----------
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern char * P_Dsacm_Path;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg dialog

CTestfirmDlg::CTestfirmDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestfirmDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestfirmDlg)
	m_BinFile_Path = _T("");
	m_Wave_File_Direction = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	hDeviceRD2=INVALID_HANDLE_VALUE;
	hDeviceWR2=INVALID_HANDLE_VALUE;
	ID0=1;
	ID1=2;
	ID2=3;
	ID3=4;
	nRet=10;
	UpLoad_Data_Buffer=NULL;
	DownLoad_Data_Buffer=NULL;

	Len=0;
	// download var set
	m_DownLoadFileLen=0;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestfirmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestfirmDlg)
	DDX_Control(pDX, IDC_Up_Download_FileName, m_Up_Download_FileName);
	DDX_Control(pDX, IDC_PCFILETREE, m_PCFileTree);
	DDX_Text(pDX, IDC_Up_Download_FileName, m_BinFile_Path);
	DDX_Text(pDX, IDC_Wave_Direction_Filename, m_Wave_File_Direction);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestfirmDlg, CDialog)
	//{{AFX_MSG_MAP(CTestfirmDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPENUSB_BUTTON, OnOpenusbButton)
	ON_BN_CLICKED(IDC_CLOSEUSB_BUTTON, OnCloseusbButton)
	ON_BN_CLICKED(IDC_CONNECTTEST_BUTTON, OnConnecttestButton)
//	ON_BN_CLICKED(IDC_RECORD_BUTTON, OnRecordButton)
//	ON_BN_CLICKED(IDC_STOP_BUTTON, OnStopButton)
//	ON_BN_CLICKED(IDC_PLAY_BUTTON, OnPlayButton)
	ON_BN_CLICKED(IDC_DOWNLOAD_BUTTON, OnDownloadButton)
	ON_BN_CLICKED(IDC_UPLOAD_BUTTON, OnUploadButton)
	ON_NOTIFY(TVN_ITEMEXPANDING, IDC_PCFILETREE, OnItemexpandingPcfiletree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_PCFILETREE, OnSelchangedPcfiletree)
	ON_BN_CLICKED(IDC_BIN_TO_WAVE_BUTTON, OnBinToWaveButton)
	ON_BN_CLICKED(IDC_PLAY_WAVE_BUTTON, OnPlayWaveButton)
	ON_BN_CLICKED(IDC_BIN_FILE_DIRECTION_BUTTON, OnBinFileDirectionButton)
	ON_BN_CLICKED(IDC_WAVE_FILE_DIRECTION_BUTTON, OnWaveFileDirectionButton)
	ON_BN_CLICKED(IDC_STOP_WAVE_BUTTON, OnStopWaveButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg message handlers

BOOL CTestfirmDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	Initialize();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestfirmDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestfirmDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestfirmDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestfirmDlg::OnOK() 
{


	CDialog::OnOK();
}

void CTestfirmDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}
void CTestfirmDlg::Initialize()
{
	DWORD DriveInfo;
	int offset;
	char Drive[4];
	HTREEITEM itemnow;
	HICON hIcon[11];
	HICON hIconFlash[2];
	int n;
	char Desktop[64];

	m_ImageList.Create(16,16,ILC_MASK,11,11);
	m_ImageList1.Create(16,16,ILC_MASK,2,2);

	hIcon[0] = AfxGetApp()->LoadIcon(IDI_FCLOSE);
	hIcon[1] = AfxGetApp()->LoadIcon(IDI_FOPEN);
	hIcon[2] = AfxGetApp()->LoadIcon(IDI_FLOPY);
    hIcon[3] = AfxGetApp()->LoadIcon(IDI_DRIVE);
	hIcon[4] = AfxGetApp()->LoadIcon(IDI_DESKTOP);
	hIcon[5] = AfxGetApp()->LoadIcon(IDI_DISK);
	hIcon[6] = AfxGetApp()->LoadIcon(IDI_CD);
	hIcon[7] = AfxGetApp()->LoadIcon(IDI_CDDRIVE);
	hIcon[8] = AfxGetApp()->LoadIcon(IDI_IC);
	hIcon[9] = AfxGetApp()->LoadIcon(IDI_NORMAL);
	hIcon[10] = AfxGetApp()->LoadIcon (IDI_MUSIC);


	for (n = 0; n <= 10; n++) {
		m_ImageList.Add(hIcon[n]);//CImageList m_ImageList
	}
	for(n=0;n<=1;n++)
		m_ImageList1.Add(hIconFlash[n]);//CImageList m_ImageList1

	m_PCFileTree.SetImageList(&m_ImageList,TVSIL_NORMAL);//CTreeCtrl	m_PCFileTree;

	itemnow=m_PCFileTree.InsertItem("DeskTop",4,4,TVI_ROOT); 
	::GetWindowsDirectory(Desktop,64);  //char Desktop[64],����C:\WINDOWS
	strcat(Desktop,"\\desktop\\\0");
	ReadSingleDirectory(Desktop,itemnow); //HTREEITEM itemnow;
	ReadSingleFile(Desktop,itemnow);
	DriveInfo=::GetLogicalDrives();
	
	offset=0;
	Drive[1]=':';//char Drive[4];
	Drive[2]='\\';
	Drive[3]='\0';
	while(DriveInfo)
	{
		int DriveType;

		if(DriveInfo&0x0001)
		{
			Drive[0]='A'+offset;
			switch(DriveType=::GetDriveType(Drive))
			{
			case DRIVE_FIXED:
			case DRIVE_RAMDISK:
				{
					itemnow=m_PCFileTree.InsertItem(Drive,3,3,TVI_ROOT);
					ReadSingleDirectory(Drive,itemnow);
					ReadSingleFile(Drive,itemnow);//
					break;
				}
			case DRIVE_REMOVABLE:
				{
					itemnow=m_PCFileTree.InsertItem(Drive,2,2,TVI_ROOT); 
					ReadSingleDirectory(Drive,itemnow);
					ReadSingleFile(Drive,itemnow);//
					break;	
				}
			case DRIVE_CDROM:
				{
					itemnow=m_PCFileTree.InsertItem(Drive,7,7,TVI_ROOT); 
					ReadSingleDirectory(Drive,itemnow);
					ReadSingleFile(Drive,itemnow);
					break;
				}
			case DRIVE_REMOTE:
			case DRIVE_NO_ROOT_DIR:
			case DRIVE_UNKNOWN:   
			default:
				break;
			}
		}
		
		DriveInfo>>=1;
		offset++;
	}

	
}

void CTestfirmDlg::OnItemexpandingPcfiletree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM current=pNMTreeView->itemNew.hItem;
	CString FilePath=m_PCFileTree.GetItemText(current);//CTreeCtrl	m_PCFileTree;
	HTREEITEM parent=m_PCFileTree.GetParentItem(current);
	HTREEITEM next;

	while(parent)
	{
		current=parent;
		parent=m_PCFileTree.GetParentItem(current);
		FilePath=m_PCFileTree.GetItemText(current)+"\\"+FilePath;
	}

	current=pNMTreeView->itemNew.hItem;
	for(next=m_PCFileTree.GetChildItem(current);next;next=m_PCFileTree.GetNextSiblingItem(next))
	{
		CString NextPath=FilePath;
		NextPath=NextPath+"\\"+m_PCFileTree.GetItemText(next);
		if(NextPath.GetLength ()>3)
			NextPath.Delete (3);
		else
			NextPath.Delete (2);
		NextPath+="\\";
		if(!m_PCFileTree.ItemHasChildren(next))
		{
			ReadSingleDirectory(NextPath,next);
			//ReadSingleDirectory(NextPath,next);
			ReadSingleFile(NextPath,next);
		}
	}

	*pResult = 0;
} 

void CTestfirmDlg::OnSelchangedPcfiletree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	     // TODO: Add your control notification handler code here
	CString FilePath;
	CString temp;
	HTREEITEM current;
	HTREEITEM parent;
	current=m_PCFileTree.GetSelectedItem();
	FilePath=m_PCFileTree.GetItemText(current);
	if(current)                                  
	{
		temp=m_PCFileTree.GetItemText(current);   
		BinFileName=(LPSTR)(LPCTSTR)(temp);       

	}

	parent=m_PCFileTree.GetParentItem(current);
	if(!FilePath.Compare("DeskTop")&&!parent)
	{
		char Desktop[64];
		::GetWindowsDirectory(Desktop,64);
		strcat(Desktop,"\\desktop\0");
		FilePath=Desktop; 
		FilePath.Insert (3,"\\");
	}
	while(parent)
	{
		current=parent;
		
	

	    parent=m_PCFileTree.GetParentItem(current);//ȡ·��
		FilePath=m_PCFileTree.GetItemText(current)+"\\"+FilePath;//FilePathΪ�ļ���

	}

    CString filename=FilePath;
	if(filename.GetLength ()>3)
		 filename.Delete (3);
	else
		filename.Delete (2);
	m_BinFile_Path=filename;
	UpdateData(FALSE);
	*pResult = 0;
}
void CTestfirmDlg::ReadSingleDirectory(const char *szPath, HTREEITEM previous)
{
	WIN32_FIND_DATA fData;
	HANDLE h;
	char szNewPath[MAX_PATH];//Maximum length of full path
	char *pch=NULL;

	strcpy(szNewPath,szPath);
	strcat(szNewPath,"*.*");
	h=::FindFirstFile (szNewPath,&fData);
	if (h == (HANDLE) 0xFFFFFFFF) return;
	do{
		if(!strcmp(fData.cFileName, "..") ||
                !strcmp(fData.cFileName, ".") ) continue;
		while((pch = strchr(fData.cFileName, '!')) != NULL) 
			{
                *pch = '|';
			}
		if (fData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
	            HTREEITEM itemnow;
				strcpy(szNewPath, szPath);
				strcat(szNewPath,fData.cFileName);
				strcat(szNewPath, "\\");
				itemnow=m_PCFileTree.InsertItem(fData.cFileName,0,1,previous);
		}

	}while (::FindNextFile(h, &fData));
	

}


void CTestfirmDlg::ReadSingleFile(const char *szPath, HTREEITEM previous)
{
	WIN32_FIND_DATA fData;
	HANDLE h;
	char szNewPath[MAX_PATH];
	char *pch=NULL;

	strcpy(szNewPath,szPath);
	strcat(szNewPath,"*.*");
	h=::FindFirstFile (szNewPath,&fData);
	if (h == (HANDLE) 0xFFFFFFFF) return;
	do{
		if(!strcmp(fData.cFileName, "..") ||
                !strcmp(fData.cFileName, ".") ) continue;
		while((pch = strchr(fData.cFileName, '!')) != NULL) 
			{
                *pch = '|';
			}
		if(! (fData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
	      // It's a file, so make a storage
				HTREEITEM itemnow;
				strcpy(szNewPath, szPath);
				strcat(szNewPath,fData.cFileName);
				strcat(szNewPath, "\\");
				itemnow=m_PCFileTree.InsertItem(fData.cFileName,9,9,previous);
		}
		
	
	}while (::FindNextFile(h, &fData));
}
void CTestfirmDlg::OnOpenusbButton() 
{
	// TODO: Add your control notification handler code here
	char *filename1="PIPE02";
	char *filename2="PIPE03";

	hDeviceRD2=open_file(filename1);//open endpoint1in
	hDeviceWR2=open_file(filename2);//open endpoint1out
	
	if (hDeviceRD2 == INVALID_HANDLE_VALUE||hDeviceWR2 == INVALID_HANDLE_VALUE)
	{
		//AfxMessageBox("ERROR opening device: (%0d) returned from CreateFile\n", GetLastError());
		AfxMessageBox("ERROR open EndPoint2: returned from open_File\n");
	}
	else
	{
		AfxMessageBox("Device found, EndPoint2  open .\n");
	}

}

void CTestfirmDlg::OnCloseusbButton() 
{
	// TODO: Add your control notification handler code here
	CloseIfOpen();
}

void CTestfirmDlg::CloseIfOpen(void)
{
	if (hDeviceRD2 != INVALID_HANDLE_VALUE)
	{

		if (!CloseHandle(hDeviceRD2))
		{
			AfxMessageBox("ERROR: CloseHandle1 returns: %ld \n", GetLastError());
		}

	 		hDeviceRD2 = INVALID_HANDLE_VALUE;
	}
	
	if (hDeviceWR2 != INVALID_HANDLE_VALUE)
	{

		if (!CloseHandle(hDeviceWR2))
		{
			AfxMessageBox("ERROR: CloseHandle1 returns: %ld \n", GetLastError());
		}
	 		hDeviceWR2 = INVALID_HANDLE_VALUE;
	}
	AfxMessageBox("CloseHandle success\n");

}


void CTestfirmDlg::OnConnecttestButton() 
{
	// TODO: Add your control notification handler code here
	CString show,tmp;
	char  Recievedata[1];
	char  Senddata[64];
	int i;
	ULONG nRead,nWrite;

    Senddata[0]=ID0;
Senddata[63] = 0x34;
    WriteFile(hDeviceWR2, Senddata, 64, &nWrite, NULL);
    for(i=0;i<50000;i++)
	{

	};
	Recievedata[0]=0x0;
	ReadFile(hDeviceRD2, Recievedata, 1, &nRead, NULL);
	if(Recievedata[0]==ID0)
    {
		
		AfxMessageBox("USB�������ӳɹ�\n");
	}
}


void CTestfirmDlg::OnUploadButton() 
{
	// TODO: Add your control notification handler code here
	BOOL Test=0;
	//CHAR *filename;
	char filename[0x100];
    m_Up_Download_FileName.GetWindowText(filename,0x100);
	if(filename[0]=='\0')
	{
		MessageBox("����������ѹ���ļ�·��!");
		return;
	}
    else
		Test=FunUpLoad();

	if(Test==0)
	{
		MessageBox("�������س���!");
	}
	else
	{
		MessageBox("�����������!");
		WriteDataToFile(filename);	
	}                                                                                                                                             
}
	
BOOL CTestfirmDlg::FunUpLoad()
{
    //int UpLoad_Id;
	ULONG nWrite=0;

	ULONG nRead=0;

	BOOL nRet=0;
	ULONG timeout=0;
	unsigned long i=0,j=0;
    BYTE WriteId[64];
	BYTE ReadId[5];
	BYTE UpLoad_Data_Tmp[64];
	unsigned int block = 64;
	unsigned long P=0,wsize=0,wtsize=0;
	unsigned int Int_Counter=0;
    WriteId[0]=5;//ID4=5
    WriteId[1]=1;
	ReadId[0]=0;
	ReadId[1]=0;
	ReadId[2]=0;
	ReadId[3]=0;
	ReadId[4]=0;
	WriteFile(hDeviceWR2,WriteId,64,&nWrite,NULL);//write  UpLoadID to 061
    timeout=0;
	while(ReadId[0]!=5)
	{
		ReadFile(hDeviceRD2,ReadId,5,&nRead,NULL);   //Read Apply Id
		timeout++;
		if(timeout==0x00ffffff)
		{
			MessageBox("Receive ID Fail");
			return 0;
		}
	}
	if(ReadId[0]==5)
	{
		Len=ReadId[4];
		Len<<=8;
		Len+=ReadId[3];
		Len<<=8;
		Len+=ReadId[2];
		Len<<=8;
		Len+=ReadId[1];
	}
	else
	{
		MessageBox("��IDʧ��!");
		return 0;
	}
	ReadId[0]=0;
	ReadId[1]=0;
   	ReadId[2]=0;
	ReadId[3]=0;
	ReadId[4]=0;

	if (UpLoad_Data_Buffer!=NULL)
	{	
		free(UpLoad_Data_Buffer);
		UpLoad_Data_Buffer = NULL;
	}
	UpLoad_Data_Buffer=(char*)malloc(Len+0x0100);
	//	UpLoad_Data_Buffer=(char*)malloc(Len);
	if(UpLoad_Data_Buffer==NULL)
	{
		MessageBox("�ڴ����!");
		return 0;
	}

	timeout=0;
	Int_Counter=0;
	while (wtsize<Len) 
	{
		nRead=0;       // 
		wsize=0;
		wsize = ((Len-wtsize) > block) ? block : (Len-wtsize);
		nRet=FALSE;
		while(nRet==FALSE)
		{

			nRet=ReadFile(hDeviceRD2,UpLoad_Data_Tmp,wsize,&nRead,NULL);
			if(nRet==FALSE)
			{
				MessageBox("Readfile����ʧ�ܣ�");
				return 0;
			}
//			timeout++;
			if(timeout==0x00fff)
			{
				MessageBox("Readfile����ʧ�ܣ�");
				return 0;
			}
		}

		if(nRead==wsize)
		{
			memcpy(&UpLoad_Data_Buffer[P],UpLoad_Data_Tmp,wsize);
			wtsize += wsize;
			P += wsize;
			timeout=0;
			Int_Counter++;
		}
	
		if(Int_Counter==0x002)
		{
			timeout=0;
			timeout=0;
		}
	
	}
	if(wtsize<Len)
	{
		MessageBox("�� second IDʧ��!");
		return 0;
	}
   	return 1;
}

void CTestfirmDlg::WriteDataToFile(CHAR *filename)
{
		int ret=1;
		CString msg;
        FILE *FileOut;
        DWORD block = 512;
		DWORD wtsize=0,wsize;
		char *p=UpLoad_Data_Buffer;
        FileOut = fopen(filename,"wb+");

		if (FileOut==NULL) 
		{
			msg.Format("Can not open file : %s",filename);
			AfxMessageBox(msg);
			return;
		}
	
		while (wtsize < Len) 
		{
			wsize = ((Len-wtsize) > block) ? block : (Len-wtsize);
			fwrite(p,1,wsize,FileOut);
			wtsize += wsize;
			p += wsize;
		}
		MessageBox("�������ر���ɹ�!");
		fclose(FileOut);
}

void CTestfirmDlg::OnDownloadButton() 
{
	// TODO: Add your control notification handler code here
	BOOL nRet=0;
	//CHAR *filename0;
    char filename0[0x100];
    m_Up_Download_FileName.GetWindowText(filename0,0x100);
	if(filename0[0]=='\0')
	{
		MessageBox("����������ѹ���ļ�·��!");
		return;
	}
	nRet=ReadDataFromFile(filename0);
	if(nRet==0)
	{
		MessageBox("���ļ�ʧ��");
	}
	else
	{
		MessageBox("���ļ��ɹ���");
	}
	FunDownLoad();

}

BOOL CTestfirmDlg::ReadDataFromFile(CHAR *filename)
{
	
	DWORD block = 512;
	DWORD count=0;
	CString msg;
	char *Buffer_Pointer=NULL;
    FILE *FileIn=fopen(filename,"rb+");
    if (FileIn==NULL) 
	{
		msg.Format("Can not open file : %s",filename);
		AfxMessageBox(msg);
		return 0;
	}
    fseek(FileIn,0,SEEK_END);
	m_DownLoadFileLen=ftell(FileIn);
    fseek(FileIn,0,SEEK_SET);
	if(Buffer_Pointer!=NULL)
	{
		free(Buffer_Pointer);
		
	}
    DownLoad_Data_Buffer=(char*)malloc(512*1024);
	if(DownLoad_Data_Buffer==NULL)
	{
		MessageBox("�ڴ����");
		return 0;
	}
    Buffer_Pointer=DownLoad_Data_Buffer;
	while( !feof( FileIn ) )
	{
		
		count=fread( Buffer_Pointer, 1, block, FileIn );
		Buffer_Pointer += count;
		

	}
	fclose(FileIn);
	return 1;	
}

//downdata have ben save to  char DownLoad_Data_Buffer[FILE LENGTH]
void CTestfirmDlg::FunDownLoad(void)
{
	unsigned long m_DownLoadFileLen_Tmp;
	ULONG nWrite=0,nRead=0;
	unsigned int i=0;
	unsigned long wsize=0,wtsize=0,nRet=0;
	ULONG Raise=0;
	unsigned long timeout=0;
	unsigned long j=0;
	unsigned long Count_64=0;
	ULONG EraseTime=0;
    char WriteId[64];
	char ReadId[1];
	////////////////
	BOOL WritePipe_Test;
	char DownLoad_Data_Buffer_Array[64];
	
    char * DownLoad_Data_Buffer_Pointer=DownLoad_Data_Buffer;
	m_DownLoadFileLen_Tmp=m_DownLoadFileLen;
    WriteId[0]=6;      //ID6
	WriteId[1]=1;

	WriteId[2]=(char)(m_DownLoadFileLen_Tmp & 0x000000ff);//LOW 8 BYTES
    WriteId[3]=(char)((m_DownLoadFileLen_Tmp & 0x0000ff00)>>8);//low word
    WriteId[4]=(char)((m_DownLoadFileLen_Tmp & 0x00ff0000)>>16);
	WriteId[5]=(char)((m_DownLoadFileLen_Tmp & 0xff000000)>>24);//high word

	//WriteFile(hDevice2,WriteId,4,&nWrite,NULL);   
    WriteFile(hDeviceWR2,WriteId,64,&nWrite,NULL);  
    ReadId[0]=0;
	while(ReadId[0]!=6)
	{
		nRet=ReadFile(hDeviceRD2,ReadId,1,&nRead,NULL);
		
		for(j=0;j<10000;j++)
		{
			EraseTime++;
		};
		if(EraseTime==0x00ffffff)
		{
		    MessageBox(" Read Apply error!");
			break;
		}

	}
    m_DownLoadFileLen_Tmp=m_DownLoadFileLen;

	i=0;
	
	wtsize=0;
	Count_64=0;
	while(wtsize<m_DownLoadFileLen_Tmp)
	 {
		nWrite=0;
		wsize = ((m_DownLoadFileLen-wtsize) > 64) ? 64 : (m_DownLoadFileLen-wtsize);
		memcpy(DownLoad_Data_Buffer_Array,&DownLoad_Data_Buffer_Pointer[Raise],wsize);
		WritePipe_Test=FALSE;
		while(WritePipe_Test==FALSE)
		{
			for(j=0;j<200;j++)
			{
					
			}
		
			WritePipe_Test=WriteFile(hDeviceWR2,DownLoad_Data_Buffer_Array,wsize,&nWrite,NULL);
		
			if(WritePipe_Test!=FALSE)
			{
				wtsize += wsize;
				Raise += wsize;
				timeout=0;
				Count_64++;
				i++;
			}
			else
			{
				
				timeout++;
				if(timeout==0x00ffffff)
				{
					MessageBox("��ʱ!");
					break;
				}
			}
	
			if(timeout==0x0ffff)
			{
				MessageBox("��ʱ!");
				break;
			}
			if(Count_64==5)
			{
				Count_64=5;
				Count_64=5;
			}
		}//while
     }//while
//	WriteFile(hDeviceWR2,DownLoad_Data_Buffer_Array,1,&nWrite,NULL);
    MessageBox("�ļ����سɹ���");	
	if(DownLoad_Data_Buffer!=NULL)
	{
		free(DownLoad_Data_Buffer);
		DownLoad_Data_Buffer=NULL;

	}
}


void CTestfirmDlg::OnBinToWaveButton() 
{
	// TODO: Add your control notification handler code here
    char parameter[256];
	char Dsacm_Path[256];
    //	char * P_Dsacm_Path=NULL;
	char * temp=NULL;
	CString path;
	UpdateData(TRUE);

  	 if(m_BinFile_Path=="" || m_Wave_File_Direction=="")
	 {
	    MessageBox("����������ѹ���ļ�·����wave�ļ�·����");	
		return;
	 }

	strcpy(Dsacm_Path,P_Dsacm_Path);
    strcat(Dsacm_Path,"\\dsacm2000.exe"); 
	
	 path="16 \""+m_BinFile_Path+"\" \""+m_Wave_File_Direction+"\"";

 	 temp=(LPSTR)(LPCTSTR)(path);
     strcpy(parameter,temp);
      ShellExecute(NULL,"open",Dsacm_Path, parameter, NULL, SW_HIDE);  
	 AfxMessageBox("תWAVE�ļ��ɹ���");
}

void CTestfirmDlg::OnPlayWaveButton() 
{
	// TODO: Add your control notification handler code here
	//m_Wave_File_Direction
	char * WavePath;
	if(m_Wave_File_Direction=="")
	{
		MessageBox("��ѡ��WAVE�ļ���·��");
	}
	WavePath=(LPSTR)(LPCTSTR)(m_Wave_File_Direction);
    PlaySound(WavePath,NULL,SND_ASYNC|SND_NODEFAULT );
	
}


void CTestfirmDlg::OnBinFileDirectionButton() 
{
	// TODO: Add your control notification handler code here
	CString temp;
	CFileDialog dlg ( TRUE, NULL, "*.bin", OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
                  _T("All Files (*.bin)|*.bin|"), this );

    if ( IDOK == dlg.DoModal() )
    {
 		 temp=dlg.GetFileName();
		 BinFileName=(LPSTR)(LPCTSTR)(temp);
		 m_BinFile_Path=dlg.GetPathName();
		 UpdateData(FALSE);
	      	
    }

	
}

void CTestfirmDlg::OnWaveFileDirectionButton() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg ( FALSE, NULL, "*.WAV", OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
                  _T("All Files (*.WAV)|*.WAV|"), this );

    if ( IDOK == dlg.DoModal() )
        {
          m_Wave_File_Direction=dlg.GetPathName();
		  UpdateData(FALSE);
	      	
        }

}


void CTestfirmDlg::OnStopWaveButton() 
{
	// TODO: Add your control notification handler code here
	PlaySound( NULL, NULL, NULL );
}
