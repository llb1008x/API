// CommPort.h : Header file of transfer interface 
//
//#include "DlgComPort.h"
//#include "DlgMsgNo.h"



//#define BufferSize  0x800000
#define SD_ConnectH 0xAA
#define SD_ConnectL 0x5C
#define RD_ConnectH 0xF5
#define RD_ConnectL 0xAF
#define SD_SetH     0xB0
#define SD_SetL     0x00
#define RD_SetH     0xB0
#define RD_SetL     0x00
#define SD_StatusH  0xC0
#define SD_StatusL  0x00
#define SD_UploadH  0xD0
#define SD_UploadL  0x00
#define RD_UploadH  0xD0
#define RD_UploadL  0x00
#define SD_DnldH    0xE0
#define SD_DnldL    0x00
#define RD_DnldH    0xE0
#define RD_DnldL    0x00
#define SD_DelH     0xF0
#define SD_DelL     0x00
#define RD_DelH     0xF0
#define RD_DelL     0x00

typedef struct {//24 byte
  BYTE  boxno;
  BYTE  type;
  WORD  day;
  WORD  time;
  DWORD nop1;
  DWORD nop2;
  DWORD nop3;
  DWORD lsec;
  WORD  ssec;
} MsgInfo;

typedef int  (GDFS1) (char *Title="");
typedef int  (GDFS2) (char *Msg="");
typedef int  (GDFS3) (int nPos);

HANDLE hComm;
LONG m_CurWidth;
LONG m_CurHeight;
LONG m_CharWidth;
LONG m_CharHeight;
HFONT m_hfont;
LOGFONT m_logfont;
DWORD m_filelen;
BYTE m_filemsg[256];
TCHAR  FullName[MAX_PATH];
char m_format[0x10] = "SACM FORMAT 1.0";

BYTE m_connect=0;
COMMTIMEOUTS m_to;
DWORD m_lrc;
BYTE m_buf0[300];
BYTE m_buf1[300];
DCB m_dcb;
BYTE m_baudrate=0; //0:9600,1:19200,2:38400
WORD m_blockbyte=8192; 

BYTE* m_Buffer=NULL;

BYTE m_noinBox[8];
MsgInfo m_msginfo[8][128];
BYTE m_box=0;
BYTE m_msgno;
WORD m_totalblock=100;
WORD m_leftblock=100;
HWND m_hwnd;
BOOL m_initialize=TRUE;
int  m_commport=1;
int  m_totalmsg=0;


int  ReadFile(CHAR *filename);
int  FunDownload(GDFS3 *fp3);
void WriteFile(CHAR *filename);
int  FunUpload(int msgno,GDFS3 *fp3);


