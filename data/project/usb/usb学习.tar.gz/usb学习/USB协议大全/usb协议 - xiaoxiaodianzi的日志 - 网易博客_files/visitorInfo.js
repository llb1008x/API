
if (NEVar==undefined){
	var NEVar={};
}

NEVar.gVisitorInfo={ 
     iVisitorId: '0', 
     sVisitorName:'', 
     sVisitorNickname: '',
     sVisitorAvatar:'http://b.bst.126.net/style/common/user_default.gif',
     iVisitorRank:'-100',
     sVisitorIP:'124.42.3.130',
     bSeleniumTestOn:'off'
};   


NEVar.gTrLinkBarInnerHTML='\
  \
  <a href="#" id="rmdtplgn">��¼</a><span class="bd1c">|</span>\
  <a href="http://reg.163.com/reg/reg0.jsp?url=http://blog.163.com/ntesRegBlank.html">ע��</a>\
  ';
    
NEVar.gBlogCountInfo={ 
     iTrackbackCount:'0', 
     iAccessCount: '101',
     iRecommendCount: '0'
};   

NEVar.gTopTitleInnerHTML='\
	  \
      <div class="fs01" id="spacename">xiaoxiaodianzi�Ĳ���</div>\
      <div class="fs02" id="spacedesc"></div>\
      ';

NEVar.gBlogOrderInfo={ 
     sPrevTitle: 'PROTEL���������',
     sPrevPermaSerial: '642785862008911555168',
     sNextTitle: 'USBЭ�����������ת��',
     sNextPermaSerial: '64278586200973031358528'
};   

NEVar.gBlogPermaPageInfo={
	sHostPath:'/xiaoxiaodianzi'
};

NEVar.gBlogUUID = '46062f64-b9bc-4792-97e4-e164d159fddd';



