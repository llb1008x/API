if(NECtrl==undefined){
var NECtrl={};
}
NECtrl.AdvancedEditor=Class.create();
NECtrl.AdvancedEditor.MenuCommand=function(iState,iType,oTarget){
this.state=iState;
this.type=iType;
this.target=oTarget;
}
NECtrl.AdvancedEditor.commands=[
'FontName','FontSize',
'ForeColor','BackColor','Portrait',
'Bold','Italic','Underline','JustifyLeft','JustifyCenter','JustifyRight','InsertOrderedList','InsertUnorderedList',
'Indent','Outdent','Link','Image','Media','Table','Paragraph','Line','ClearFormat',
'Copy','Paste','Cut',
'ShowCode'];
NECtrl.AdvancedEditor.commandsType=[3,3,2,2,2,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,-1,-1,-1,0];
NECtrl.AdvancedEditor.prototype={
initialize:function(sParentId,sEditorDivId){
this.options=Object.extend({
sEditorSrc:"/blankEditor.html",
bSimpleEditor:false,
iWidth:0,
iHeight:350,
iMaxLen:65535,
sObjName:null,
fnAfterLoad:null,
oAfterLoadParams:null,
fnPreview:null,
fnHideDiv:null,
oHideDivParmas:null,
iDeltaHeight:30,
oToolbarArray:null,
bFriend:true,
bHome:false,
sInitContent:null,
sTitle:null,
sEditorHint:'�����￪ʼ��д�ռǡ����� ��',
sTitleHint:'������������־����',
bBig:false,
fnSetPref:null,
fnGetPortraitPref:null,
fnSetPortraitPref:null,
bNewCommentEditor:false,
fnOnCommentFocus:null,
fnAfterPortraitClick:null,
bFeelingEditor:false
},arguments[2]||{});
this.objectName=this.options.sObjName;
this.oToolbarArray=this.options.oToolbarArray;
this.parentId=sParentId;
this.containerId=sEditorDivId;
this.editorHint=this.options.sEditorHint;
this.titleHint=this.options.sTitleHint;
this.designEditor=null;
this.designEditorDoc=null;
this.sourceEditor=null;
this.smallForeColor=null;
this.bigForeColor=null;
this.bigBackColor=null;
this.smallPortrait=null;
this.insertAnything=null;
this.bigPortrait=null;
this.oFrame=null;
this.oFrameBody=null;
this.allToolbar={};
this.textToolbar={};
this.popMenuToolbar={};
this.copyPasteToolbar={};
this.oTitle=null;
this.currMode="Design";
this.iFrameHeight=this.options.iHeight;
this.isIE;
this.bDisabled=false;
this.ranges=null;
this.onSetting=false;
this.onInserting=false;
this.bBigEditor=this.options.bBig;
this.cloneNode=null;
this.body=document.body;
this.init();
},
init:function(){
if(document.all)this.isIE=true;else this.isIE=false;
if(typeof UD!='undefined'&&typeof UD.body!='undefined'){
this.body=UD.body;
}
this._getToolbar();
var _oData={editorId:this.parentId,objName:this.options.sObjName,
height:this.options.iHeight+220,bFriend:this.options.bFriend};
var _sResult;
if(this.options.bSimpleEditor){
if(this.options.bNewCommentEditor){
$(this.containerId).innerHTML=jst_global_simple_notoolbar_editor.processUseCache(_oData);
}else{
$(this.containerId).innerHTML=jst_global_simple_editor.processUseCache(_oData);
}
this.smallPortrait=new NECtrl.Portrait(this.parentId+"smallPortrait",this,{bNav:false,sObjName:this.options.sObjName+".smallPortrait",fnAfterPortraitClick:this.options.fnAfterPortraitClick,fnGetPref:this.options.fnGetPortraitPref,fnSetPref:this.options.fnSetPortraitPref});
}else{
$(this.containerId).innerHTML=jst_global_advanced_editor.processUseCache(_oData);
if(this.bBigEditor){
this.bigForeColor=new NECtrl.ColorPanel(this.parentId+"bigForeColor",this,this.options.sObjName+".bigForeColor");
this.bigBackColor=new NECtrl.ColorPanel(this.parentId+"bigBackColor",this,this.options.sObjName+".bigBackColor");
this.bigPortrait=new NECtrl.Portrait(this.parentId+"bigPortrait",this,{bNav:true,sObjName:this.options.sObjName+".bigPortrait",fnGetPref:this.options.fnGetPortraitPref,fnSetPref:this.options.fnSetPortraitPref});
var _oBig=$("big_toolbar"+this.parentId);
_oBig.innerHTML=jst_global_advanced_editor_bigToolbar.processUseCache(_oData);
_oBig.style.display="block";
}else{
this.smallForeColor=new NECtrl.ColorPanel(this.parentId+"smallForeColor",this,this.options.sObjName+".smallForeColor");
this.smallPortrait=new NECtrl.Portrait(this.parentId+"smallPortrait",this,{bNav:true,sObjName:this.options.sObjName+".smallPortrait",fnGetPref:this.options.fnGetPortraitPref,fnSetPref:this.options.fnSetPortraitPref});
var _oSmall=$("small_toolbar"+this.parentId);
_oSmall.innerHTML=jst_global_advanced_editor_smallToolbar.processUseCache(_oData);
_oSmall.style.display="block";
}
}
this.insertAnything=new NECtrl.InsertAnything(this.parentId,this,{sObjName:this.options.sObjName+".insertAnything"});
var _oHtmlDiv=$("designEditorDiv"+this.parentId);
var _iWidth=this.options.iWidth;
if(_iWidth==0){
if(_oHtmlDiv.offsetWidth>2)
_iWidth=_oHtmlDiv.offsetWidth;
}
var _sIFrame=this.isIE?"<iframe></iframe>":"iframe";
var _oIframeObj=document.createElement(_sIFrame);
_oIframeObj.setAttribute("id","designEditor"+this.parentId);
if(this.options.bSimpleEditor){
_oIframeObj.setAttribute("width",_iWidth);
if(_iWidth!=0)
$("editorWrap"+this.parentId).style.width=_iWidth+"px";
}else{
_oIframeObj.setAttribute("width",726);
}
_oIframeObj.height=this.options.iHeight+'px';
_oIframeObj.setAttribute("name","designEditor"+this.parentId);
_oIframeObj.setAttribute("frameBorder",0);
var hash="";
if(document.domain=='163.com'){
hash="#topdomain";
}
_oIframeObj.setAttribute("src",this.options.sEditorSrc+hash);
_oIframeObj.setAttribute("designMode","on");
_oHtmlDiv.appendChild(_oIframeObj);
if(!this.options.bSimpleEditor){
this.sourceEditor=$("sourceEditor"+this.parentId);
this.sourceEditor.style.width=$("editorDiv"+this.parentId).offsetWidth-6+"px";
}
if(this.isIE){
_oIframeObj.attachEvent("onload",function(){
if(!this.options.bSimpleEditor){
event.srcElement.contentWindow.document.body.contentEditable=true;
}else if(!!hash){
event.srcElement.contentWindow.document.body.contentEditable=true;
this._fnEditorMouseOvr=this._setFrameBodyMouseOver.bind(this);
}else{
if(event.srcElement.contentWindow.document.designMode!='On'){
event.srcElement.contentWindow.document.designMode="On";
return;
}
this._fnEditorMouseOvr=this._setFrameBodyMouseOver.bind(this);
}
this._afterLoad();
}.bind(this));
}else{
var _oThis=this;
_oIframeObj.addEventListener("load",function(){
this.contentWindow.onfocus=function(){
this.document.designMode="on";
}
_oThis._afterLoad();
},false);
}
},
_afterLoad:function(){
this.oFrame=$("designEditor"+this.parentId);
this.designEditor=this.oFrame.contentWindow;
this.designEditorDoc=this.designEditor.document;
this.oFrameBody=this.designEditorDoc.body;
if(this.isIE){
Event.observe(this.designEditorDoc,"selectionchange",this.onEditContentSelChange.bind(this));
}else{
Event.observe(this.designEditorDoc,"keydown",this.onEditorContentKeyDown.bind(this));
}
Event.observe(this.designEditorDoc,"click",this.onEditorClick.bind(this));
Event.observe(window.document.body,'click',this.onWindowClick.bindAsEventListener(this));
this._registerToolbar();
if(!this.options.bSimpleEditor){
Event.observe(this.designEditor,"focus",this.onEditorFocus.bind(this));
if(this.isIE){
Event.observe(this.designEditorDoc.body,"beforedeactivate",this.onEditorBlur.bind(this));
}else{
Event.observe(this.designEditorDoc,"blur",this.onEditorBlur.bind(this));
}
this.oTitle=$("title"+this.parentId);
if(this.options.sTitle&&this.options.sTitle!='')
this.oTitle.value=this.options.sTitle;
else
this.oTitle.value=this.titleHint;
Event.observe(this.oTitle,"click",this.onTitleClick.bind(this));
Event.observe(this.oTitle,"blur",this.onTitleBlur.bind(this));
Event.observe(this.oTitle,"keypress",this.onTitleKeypress.bindAsEventListener(this));
if(this.options.sInitContent&&this.options.sInitContent!=''){
this.oFrameBody.innerHTML=this.options.sInitContent;
}else{
this.oFrameBody.innerHTML=this.editorHint;
}
if(this.isIE){
this._oSubEditor=document.createElement("iframe");
this._oSubEditor.style.cssText="height:1px;width:1px;overflow:hidden;visibility:hidden";
this.body.appendChild(this._oSubEditor);
this.designEditorDoc.body.attachEvent("onpaste",function(){
var _oSubDoc=this._oSubEditor.contentWindow.document.body;
_oSubDoc.innerHTML="";
_oSubDoc.createTextRange().execCommand("Paste");
var _htmlData=_oSubDoc.innerHTML;
if(this._checkIfHTMLTxt(_htmlData)){
if(confirm('��ճ���������к�html���������������Ķ�  \r\n\r\n�ͱ༭�ĸ�ʽ���Ƿ����ԭ���ĸ�ʽ�� ')){
var _source=this._clearAllFormat(_htmlData);
this.insertHTML(_source);
return false;
}
}
}.bind(this));
}
}else{
this.oFrameBody.style.fontSize="12px";
if(this.isIE&&!this.options.bFeelingEditor){
this.designEditorDoc.attachEvent('onmouseover',this._fnEditorMouseOvr);
}
if(this.options.fnOnCommentFocus!=null){
Event.observe(this.designEditor,"focus",this.options.fnOnCommentFocus);
}
this.designEditor.focus();
}
if(this.options.fnAfterLoad!=null){
this.options.fnAfterLoad(this.options.oAfterLoadParams);
}
},
_setFrameBodyMouseOver:function(){
if(!this._oBodyOvered){
this.designEditor.focus();
this._oBodyOvered=true;
}else{
this.oFrame.detachEvent("onmouseover",this._fnEditorMouseOvr);
}
},
_getToolbar:function(){
if(this.oToolbarArray==null){
this.oToolbarArray=[];
for(var i=0;i<17;i++)
this.oToolbarArray[i]=1;
if(!this.options.bSimpleEditor){
this.oToolbarArray[0]=0;
this.oToolbarArray[3]=0;
this.oToolbarArray[8]=0;
this.oToolbarArray[9]=0;
this.oToolbarArray[10]=0;
this.oToolbarArray[11]=0;
this.oToolbarArray[12]=0;
this.oToolbarArray[13]=0;
this.oToolbarArray[14]=0;
}else{
this.oToolbarArray[0]=0;
this.oToolbarArray[1]=0;
this.oToolbarArray[3]=0;
this.oToolbarArray[8]=0;
this.oToolbarArray[9]=0;
this.oToolbarArray[10]=0;
this.oToolbarArray[11]=0;
this.oToolbarArray[12]=0;
this.oToolbarArray[13]=0;
this.oToolbarArray[14]=0;
this.oToolbarArray[16]=0;
if(!this.options.bFriend){
this.oToolbarArray[2]=0;
this.oToolbarArray[15]=0;
}
}
}
},
_registerToolbar:function(){
if(this.bBigEditor==true){
this.allToolbar={};
this.textToolbar={};
this.popMenuToolbar={};
this.copyPasteToolbar={};
for(var i=NECtrl.AdvancedEditor.commands.length-1;i>=0;i--){
var name=NECtrl.AdvancedEditor.commands[i];
var type=NECtrl.AdvancedEditor.commandsType[i];
var oTarget=$(name+"Btn"+this.parentId);
if(oTarget==null)
continue;
var oCommand=new NECtrl.AdvancedEditor.MenuCommand(0,type,oTarget);
if(type==-1&&!this.isIE){
oCommand.state=-1;
this.changeCss(name,oTarget,-1);
}else{
this.allToolbar[name]=oCommand;
oTarget.onmouseover=this.onMenuIconOver.bind(this,name);
oTarget.onmouseout=this.onMenuIconOut.bind(this,name);
if(name!='Image'){
oTarget.onmousedown=this.onMenuIconDown.bind(this,name);
oTarget.onmouseup=this.onMenuIconUp.bind(this,name);
oTarget.onclick=this.onMenuIconClick.bindAsEventListener(this);
if(type==1||type==3){
this.textToolbar[name]=oCommand;
}
if(type>=2){
this.popMenuToolbar[name]=oCommand;
}else if(type==-1&&this.isIE){
this.copyPasteToolbar[name]=oCommand;
}
}
}
}
}else{
this.allToolbar={};
this.textToolbar={};
this.popMenuToolbar={};
for(var i=this.oToolbarArray.length-1;i>=0;i--){
if(this.oToolbarArray[i]==1){
var name=NECtrl.AdvancedEditor.commands[i];
var type=NECtrl.AdvancedEditor.commandsType[i];
var oTarget=$(name+"Btn_s"+this.parentId);
if(oTarget==null)
continue;
var oCommand=new NECtrl.AdvancedEditor.MenuCommand(0,type,oTarget);
this.allToolbar[name]=oCommand;
oTarget.onmouseover=this.onMenuIconOver.bind(this,name);
oTarget.onmouseout=this.onMenuIconOut.bind(this,name);
if(name!='Image'){
oTarget.onmousedown=this.onMenuIconDown.bind(this,name);
oTarget.onmouseup=this.onMenuIconUp.bind(this,name);
oTarget.onclick=this.onMenuIconClick.bindAsEventListener(this);
if(type==1||type==3){
this.textToolbar[name]=oCommand;
}
if(type>=2){
this.popMenuToolbar[name]=oCommand;
}
}
}
}
}
},
onTitleClick:function(){
if(this.oTitle.value==this.titleHint)
this.oTitle.value="";
if(this.bBigEditor){
$("toolbarCover"+this.parentId).style.width="80%";
$("toolbarCover"+this.parentId).style.display="block";
$("func"+this.parentId).style.display="none";
}else{
$("toolbarCover_s"+this.parentId).style.display="block";
$("func_s"+this.parentId).style.display="none";
}
},
onTitleBlur:function(){
if(this.oTitle.value==""){
this.oTitle.value=this.titleHint;
}
if(this.bBigEditor){
$("toolbarCover"+this.parentId).style.display="none";
$("func"+this.parentId).style.display="inline";
}else{
$("toolbarCover_s"+this.parentId).style.display="none";
$("func_s"+this.parentId).style.display="inline";
}
},
onTitleKeypress:function(event){
if(event.keyCode==13){
this.designEditor.focus();
Event.stop(event);
return false;
}
},
onEditorBlur:function(){
if(!this.bDisabled){
if(this.isIE&&!this.onInserting)
this.ranges=this.designEditorDoc.selection.createRange();
if(this.oFrameBody.innerHTML==""&&!this.options.bSimpleEditor){
this.oFrameBody.innerHTML=this.editorHint;
}
}
},
onMenuIconOver:function(sName){
if(!this.bDisabled||sName=="ShowCode"){
var oCommand=this.allToolbar[sName];
if(oCommand.state>=0)
this.changeCss(sName,oCommand.target,1);
}
},
onMenuIconOut:function(sName){
if(!this.bDisabled||sName=="ShowCode"){
var oCommand=this.allToolbar[sName];
switch(oCommand.state){
case 2:
this.changeCss(sName,oCommand.target,0);
oCommand.state=0;
break;
case 3:
this.changeCss(sName,oCommand.target,3);
break;
case 4:
this.changeCss(sName,oCommand.target,4);
break;
case 0:
this.changeCss(sName,oCommand.target,0);
break;
}
}
},
onMenuIconDown:function(sName){
if(sName=="ShowCode"){
this.switchEditor();
return;
}
var oCommand=this.allToolbar[sName];
if(!this.bDisabled&&oCommand.state>=0){
this.onSetting=true;
this._setAllIcons(sName);
this.onSetting=false;
this.syncTextToolbar();
}
},
onMenuIconUp:function(sName){
if(!this.bDisabled||sName=="ShowCode"){
var oCommand=this.allToolbar[sName];
if(oCommand.state>0){
if(oCommand.state>=3){
this.changeCss(sName,oCommand.target,3);
}else if(oCommand.state>=0){
this.changeCss(sName,oCommand.target,1);
}
if(!(/^(FontSize|FontName|Link|Table|Media|ClearFormat|Image)$/.test(sName))){
this.designEditor.focus();
}
}
}
},
onMenuIconClick:function(event){
if(!this.bDisabled){
Event.stop(event);
}
},
onEditorClick:function(){
if(!this.bDisabled){
this.hiddenAllMenu();
if(this.isIE&&this.bBigEditor&&!this.options.bSimpleEditor)
this.syncCopyPaste();
if(this.isIE){
if(this.designEditorDoc.selection.type.toLowerCase()=="text")
this.syncTextToolbar();
}else{
this.syncTextToolbar();
}
}
if(this.options.fnHideDiv!=null){
this.options.fnHideDiv(this.options.oHideDivParmas);
}
},
onEditorFocus:function(){
if(this.editorHint==this.oFrameBody.innerHTML){
this.oFrameBody.innerHTML="";
}
},
onWindowClick:function(event){
if(!this.bDisabled){
this.hiddenAllMenu();
}
},
onEditorContentKeyDown:function(){
if(!this.bDisabled){
this.syncTextToolbar();
}
},
onEditContentSelChange:function(){
if(!this.bDisabled&&!this.onSetting){
if(this.designEditorDoc.selection.type.toLowerCase()=="text"){
this.syncTextToolbar();
if(this.bBigEditor&&!this.options.bSimpleEditor){
this.syncCopyPaste();
}
}
}
},
_setAllIcons:function(sCurrent){
for(name in this.allToolbar){
var oCommand=this.allToolbar[name];
switch(oCommand.state){
case 0:
if(name==sCurrent){
if(oCommand.type<=0){
this.changeCss(name,oCommand.target,5);
oCommand.state=2;
this.cmd(name);
}else if(oCommand.type==1){
this.changeCss(name,oCommand.target,5);
oCommand.state=3;
this.cmd(name);
}else if(oCommand.type>=2){
this.changeCss(name,oCommand.target,5);
oCommand.state=4;
this.openMenu(name);
}
}
break;
case 3:
if(name==sCurrent){
this.changeCss(name,oCommand.target,5);
oCommand.state=0;
this.cmd(name);
}
break;
case 4:
this.changeCss(name,oCommand.target,0);
oCommand.state=0;
this.hiddenMenu(name);
break;
case 2:
if(name==sCurrent){
this.changeCss(name,oCommand.target,5);
this.cmd(name);
}
}
}
},
changeCss:function(sName,oTarget,iType){
switch(iType){
case 0:
oTarget.className="com";
break;
case 1:
oTarget.className="over";
break;
case 2:
case 3:
case 4:
oTarget.className="click";
break;
case 5:
oTarget.className="down";
break;
case-1:
oTarget.className="disb";
break;
}
},
syncTextToolbar:function(){
for(name in this.textToolbar){
var oCommand=this.textToolbar[name];
try{
switch(name){
case'FontName':
var value=this.designEditorDoc.queryCommandValue(name);
value=this._processFontName(value);
if(!this.bBigEditor)
$('FontNameValue_s'+this.parentId).innerHTML=value;
else
$('FontNameValue'+this.parentId).innerHTML=value;
break;
case'FontSize':
var value=this.designEditorDoc.queryCommandValue(name);
value=this._processFontSize(value);
if(!this.bBigEditor)
$('FontSizeValue_s'+this.parentId).innerHTML=value;
else
$('FontSizeValue'+this.parentId).innerHTML=value;
break;
default:
var value=this.designEditorDoc.queryCommandState(name);
if(value){
this.changeCss(name,oCommand.target,3);
oCommand.state=3;
}else{
this.changeCss(name,oCommand.target,0);
oCommand.state=0;
}
}
}catch(e){}
}
},
syncCopyPaste:function(){
for(name in this.copyPasteToolbar){
try{
var oCommand=this.copyPasteToolbar[name];
if(name=='Copy')
name='Cut';
if(this.designEditorDoc.queryCommandEnabled(name)){
this.changeCss(name,oCommand.target,0);
oCommand.state=0;
}else{
this.changeCss(name,oCommand.target,-1);
oCommand.state=-1;
}
}catch(e){}
}
},
showMenu:function(sMenuElem,iAdjustLeft,iAdjustTop){
if(iAdjustTop==undefined){
sMenuElem.style.top=27+"px";
}else{
sMenuElem.style.top=27+iAdjustTop+"px";
}
if(iAdjustLeft==undefined){
sMenuElem.style.left=0+"px";
}else{
sMenuElem.style.left=0+iAdjustLeft+"px";
}
sMenuElem.style.display="block";
},
setInserting:function(b){
if(b){
this.onInserting=true;
}else{
this.onInserting=false;
}
},
disableToolBar:function(bDisable){
if(bDisable){
if(!this.onSetting){
this.onSetting=true;
this.hiddenAllMenu();
for(name in this.allToolbar){
var oCommand=this.allToolbar[name];
if(name!="ShowCode"){
oCommand.state=0;
this.changeCss(name,oCommand.target,0);
}
}
this.onSetting=false;
this.bDisabled=true;
}
}else{
this.bDisabled=false;
}
},
initState:function(){
this.hiddenAllMenu();
for(name in this.allToolbar){
var oCommand=this.allToolbar[name];
oCommand.state=0;
this.changeCss(name,oCommand.target,0);
}
},
hiddenAllMenu:function(){
for(name in this.popMenuToolbar){
var oCommand=this.popMenuToolbar[name];
if(oCommand.state==4){
this.changeCss(name,oCommand.target,0);
oCommand.state=0;
this.hiddenMenu(name);
}
}
return false;
},
hiddenMenu:function(name){
var o;
if(!this.bBigEditor){
o=$(name+"Div_s"+this.parentId);
}else{
o=$(name+"Div"+this.parentId);
}
if(o!=null&&o.style.display!="none")
o.style.display="none";
if(this.options.bSimpleEditor&&o!=null){
this.body.removeChild(o);
}
},
openMenu:function(name){
var _oMemuElem;
if(!this.bBigEditor){
_oMemuElem=$(name+"Div_s"+this.parentId);
}else{
_oMemuElem=$(name+"Div"+this.parentId);
}
switch(name){
case"FontName":
case"FontSize":
this.showMenu(_oMemuElem,0,-4);
break;
case"Portrait":
if(this.options.bSimpleEditor){
_oMemuElem=this._createAndShowMenuDiv(name);
var _pos=Position.cumulativeOffset($(name+'Btn_s'+this.parentId));
this.showMenu(_oMemuElem,_pos[0]-1,_pos[1]);
this.smallPortrait.display(_oMemuElem);
}else{
this.showMenu(_oMemuElem,-140,0);
if(!this.bBigEditor)
this.smallPortrait.display(_oMemuElem);
else
this.bigPortrait.display(_oMemuElem);
}
break;
case"ForeColor":
if(this.options.bSimpleEditor){
_oMemuElem=this._createAndShowMenuDiv(name);
var _pos=Position.cumulativeOffset($(name+'Btn_s'+this.parentId));
this.showMenu(_oMemuElem,_pos[0],_pos[1]);
this.smallForeColor.display(_oMemuElem,name);
}else{
this.showMenu(_oMemuElem);
if(!this.bBigEditor)
this.smallForeColor.display(_oMemuElem,name);
else
this.bigForeColor.display(_oMemuElem,name);
}
break;
case"BackColor":
this.showMenu(_oMemuElem);
this.bigBackColor.display(_oMemuElem,name);
break;
}
},
_createAndShowMenuDiv:function(name){
var _oDiv=document.createElement('DIV');
_oDiv.id=name+'Div_s'+this.parentId;
_oDiv.style.cssText='position:absolute;border:none;z-index:10000;display:none;';
if(name=='Portrait')
_oDiv.className='edt_mgcf';
this.body.appendChild(_oDiv);
return _oDiv;
},
fixState:function(name){
var oCommand=this.allToolbar[name];
oCommand.state=0;
this.changeCss(name,oCommand.target,0);
},
cmd:function(sType){
switch(sType){
case"Link":
this._createLink();
break;
case"Media":
this._createMedia();
break;
case"Table":
this._createTable();
break;
case"Image":
this.addImg();
break;
case"Paragraph":
this._paraFormating();
break;
case"ClearFormat":
this._clearHTMLFormat();
break;
case"Line":
this.format("InsertHorizontalRule");
break;
case"JustifyLeft":
this._alignLeft();
break;
case"JustifyRight":
this._alignRight();
break;
case"JustifyCenter":
this._alignCenter();
break;
default:
this.format(sType);
}
},
format:function(sType,vPara,vLoseFocus){
this.designEditor.focus();
if(this.isIE&&vLoseFocus&&this.ranges){
this.ranges.select();
}
if(!vPara){
if(this.isIE){
this.designEditorDoc.execCommand(sType);
}else{
this.designEditorDoc.execCommand(sType,false,false);
}
}else{
this.designEditorDoc.execCommand(sType,false,vPara);
}
},
switchToolbar:function(){
this.onSetting=true;
this.hiddenAllMenu();
if(this.bBigEditor){
this.bBigEditor=false;
var oSmall=$("small_toolbar"+this.parentId);
if(oSmall.innerHTML==""){
var _oData={editorId:this.parentId,objName:this.options.sObjName};
oSmall.innerHTML=jst_global_advanced_editor_smallToolbar.processUseCache(_oData);
}
if(!this.smallForeColor)
this.smallForeColor=new NECtrl.ColorPanel(this.parentId+"smallForeColor",this,this.options.sObjName+".smallForeColor");
if(!this.smallPortrait)
this.smallPortrait=new NECtrl.Portrait(this.parentId+"smallPortrait",this,{bNav:true,sObjName:this.options.sObjName+".smallPortrait",fnGetPref:this.options.fnGetPortraitPref,fnSetPref:this.options.fnSetPortraitPref});
$("big_toolbar"+this.parentId).style.display="none";
oSmall.style.display="block";
this._registerToolbar();
this.onSetting=false;
this.designEditor.focus();
}else{
this.bBigEditor=true;
var oBig=$("big_toolbar"+this.parentId);
if(oBig.innerHTML==""){
var _oData={editorId:this.parentId,objName:this.options.sObjName};
oBig.innerHTML=jst_global_advanced_editor_bigToolbar.processUseCache(_oData);
}
if(!this.bigForeColor)
this.bigForeColor=new NECtrl.ColorPanel(this.parentId+"bigForeColor",this,this.options.sObjName+".bigForeColor");
if(!this.bigBackColor)
this.bigBackColor=new NECtrl.ColorPanel(this.parentId+"bigBackColor",this,this.options.sObjName+".bigBackColor");
if(!this.bigPortrait)
this.bigPortrait=new NECtrl.Portrait(this.parentId+"bigPortrait",this,{bNav:true,sObjName:this.options.sObjName+".bigPortrait",fnGetPref:this.options.fnGetPortraitPref,fnSetPref:this.options.fnSetPortraitPref});
$("small_toolbar"+this.parentId).style.display="none";
oBig.style.display="block";
this._registerToolbar();
this.onSetting=false;
this.designEditor.focus();
if(this.bBigEditor&&!this.options.bSimpleEditor)
this.syncCopyPaste();
}
if(this.options.fnSetPref){
this.options.fnSetPref(this.bBigEditor);
}
this.syncTextToolbar();
},
insertHTML:function(sHtml,vLoseFocus){
this.designEditor.focus();
if(this.isIE&&vLoseFocus&&this.ranges){
this.ranges.select();
}
this._beforeExecCommand();
if(this.isIE){
var rng=this.designEditorDoc.selection.createRange();
if(this.designEditorDoc.selection.type.toLowerCase()=="control"){
try{
var tg=this.designEditorDoc.body.createTextRange();
tg.moveToElementText(rng.item(0));
rng=tg;
}catch(e){}
}
rng.pasteHTML(sHtml);
}else{
this.designEditor.document.execCommand("inserthtml",null,sHtml);
}
},
_beforeExecCommand:function(){
if(this.oFrameBody.innerHTML==this.editorHint)
this.oFrameBody.innerHTML='';
},
switchEditor:function(){
var oCommand=this.allToolbar["ShowCode"];
if(this.currMode=="Design"){
this.disableToolBar(true);
$("toolbarCover"+this.parentId).style.width="536px";
$("toolbarCover"+this.parentId).style.display="block";
this.changeCss("ShowCode",oCommand.target,5);
oCommand.state=3;
if(this.oFrameBody.innerHTML!=this.editorHint)
this.sourceEditor.value=this.oFrameBody.innerHTML;
$("editorDiv"+this.parentId).style.display="none";
$("sourceDiv"+this.parentId).style.display="block";
if(this.bBigEditor){
$("func"+this.parentId).style.display="none";
}else{
$("func_s"+this.parentId).style.display="none";
}
this.currMode="Code";
oCommand.target.title="����HTML����";
this.sourceEditor.focus();
}else{
this.disableToolBar(false);
this.changeCss("ShowCode",oCommand.target,5);
oCommand.state=0;
try{
if(this.sourceEditor.value=="")
this.oFrameBody.innerHTML=this.editorHint;
else{
this.designEditorDoc.body.innerHTML=this._stripData(this.sourceEditor.value);;
}
}catch(e){}
$("editorDiv"+this.parentId).style.display="block";
$("sourceDiv"+this.parentId).style.display="none";
$("toolbarCover"+this.parentId).style.display="none";
if(this.bBigEditor){
$("func"+this.parentId).style.display="inline";
}else{
$("func_s"+this.parentId).style.display="inline";
}
this.currMode="Design";
oCommand.target.title="��ʾHTML����";
this.designEditor.focus();
}
},
setFontName:function(sFontName){
this.hiddenAllMenu();
this.format('FontName',sFontName,true);
var value=this._processFontName(sFontName);
if(!this.bBigEditor){
$('FontNameValue_s'+this.parentId).innerHTML=value;
}else{
$('FontNameValue'+this.parentId).innerHTML=value;
}
},
setFontSize:function(sFontSize){
this.hiddenAllMenu();
this.format('FontSize',sFontSize,true);
var value=this._processFontSize(sFontSize);
if(!this.bBigEditor){
$('FontSizeValue_s'+this.parentId).innerHTML=value;
}else{
$('FontSizeValue'+this.parentId).innerHTML=value;
}
},
addImg:function(){
this.designEditor.focus();
window.open("uploadBlogPhoto.do","addPicWin","resizable=no,scrollbars=no,status=yes, width=785px, height=470px");
},
_createTable:function(){
this.designEditor.focus();
this.onInserting=true;
if(this.isIE)
this.ranges=this.designEditorDoc.selection.createRange();
this.insertAnything.showTable();
},
_createMedia:function(){
this.designEditor.focus();
this.onInserting=true;
if(this.isIE)
this.ranges=this.designEditorDoc.selection.createRange();
this.insertAnything.showMedia();
},
_getSelectNode:function(){
var elm;
if(isIE){
var rng=this.designEditorDoc.selection.createRange();
elm=rng.item?rng.item(0):rng.parentElement();
}else{
var sel=this.designEditor.getSelection();
var rng=null;
if(sel.rangeCount>0){
rng=sel.getRangeAt(0);
}else{
return;
}
elm=rng.commonAncestorContainer;
if(!rng.collapsed){
if(rng.startContainer==rng.endContainer){
if(rng.startOffset-rng.endOffset<2){
if(rng.startContainer.hasChildNodes())
elm=rng.startContainer.childNodes[rng.startOffset];
}
}
}
}
return elm;
},
_alignLeft:function(){
var e=this._getSelectNode();
if(e.tagName.toLowerCase()=="img"||e.tagName.toLowerCase()=="embed"){
e.style.display="";
e.style.textAlign="";
if(isIE)
e.style.styleFloat="left";
else
e.style.cssFloat="left";
}else{
this.format("JustifyLeft");
}
},
_alignRight:function(){
var e=this._getSelectNode();
if(e.tagName.toLowerCase()=="img"||e.tagName.toLowerCase()=="embed"){
e.style.display="";
e.style.textAlign="";
if(isIE)
e.style.styleFloat="right";
else
e.style.cssFloat="right";
}else{
this.format("JustifyRight");
}
},
_alignCenter:function(){
var e=this._getSelectNode();
if(e.tagName.toLowerCase()=="img"||e.tagName.toLowerCase()=="embed"){
if(isIE)
e.style.styleFloat="";
else
e.style.cssFloat="";
e.style.textAlign="center";
e.style.display="block";
}else{
this.format("JustifyCenter");
}
},
_createLink:function(){
this.designEditor.focus();
this.onInserting=true;
if(this.isIE){
this.ranges=this.designEditorDoc.selection.createRange();
var rng=this.designEditorDoc.selection.createRange();
var elm=rng.item?rng.item(0):rng.parentElement();
var p=elm;
while(p.tagName.toLowerCase()!='a'&&p.tagName.toLowerCase()!='body'){
p=p.parentNode;
}
if(p.tagName.toLowerCase()=='a'){
this.insertAnything.showLink(true,p);
}else{
if(rng.text==""){
this.insertAnything.showLink(false,null);
}else{
if(rng.item){
this.insertAnything.showLink(false,rng.item(0).outerHTML);
}else{
this.insertAnything.showLink(false,rng.htmlText);
}
}
}
}else{
var sel=this.designEditor.getSelection();
var rng=null;
if(sel.rangeCount>0){
rng=sel.getRangeAt(0);
}else{
return;
}
var elm=rng.commonAncestorContainer;
if(!rng.collapsed){
if(rng.startContainer==rng.endContainer){
if(rng.startOffset-rng.endOffset<2){
if(rng.startContainer.hasChildNodes())
elm=rng.startContainer.childNodes[rng.startOffset];
}
}
}
var p=elm;
while(p.nodeName.toLowerCase()!='a'&&p.nodeName.toLowerCase()!='body'){
p=p.parentNode;
}
if(p.nodeName.toLowerCase()=='a'){
this.insertAnything.showLink(true,p);
}else{
if(rng.collapsed){
this.insertAnything.showLink(false,null);
}else{
if(!this.cloneNode){
this.cloneNode=document.createElement("DIV");
this.cloneNode.style.cssText="display:none;";
this.body.appendChild(this.cloneNode);
}
this.cloneNode.innerHTML="";
this.cloneNode.appendChild(rng.cloneContents());
var value=this.cloneNode.innerHTML;
value=value.replace(/<a.*?>(.*?)<\/a[^>]*>/ig,"$1");
this.insertAnything.showLink(false,value);
}
}
}
},
_processFontSize:function(value){
if(value==null||value=="")
return"�ֺ�";
switch(value+""){
case"2":
return"С";
case"3":
return"��׼";
case"4":
return"��";
case"5":
return"�ش�";
case"6":
return"����";
default:
return"�ֺ�";
}
},
_processFontName:function(value){
if(value==null||value=="")
return"����";
if(value=="����_GB2312")
return"����";
if(!this.isIE&&value.indexOf(",")!=-1){
var index=value.indexOf(",");
value=value.substring(0,index);
}
return value;
},
_doAfterGetContent:function(_sContent){
if(this.bHarm){
this.setData(_sContent);
}
if(isFirefox){
_sContent=this._fixFFLink(_sContent,"a","href");
}
this._saveDataForSubmit(_sContent);
return _sContent;
},
_fixFFLink:function(content,tag,attribute){
var _r=new RegExp('(<'+tag+'.*?'+attribute+'=")([^"]*)("[^>]*>)',"ig");
content=content.replace(_r,function($1,$2,$3,$4){
if($3.indexOf("http://")<0&&$3.indexOf("https://")<0&&$3.indexOf("mms://")<0&&$3.indexOf("rtsp://")<0&&$3.indexOf("mmst://")<0&&$3.indexOf("mailto:")<0&&$3.indexOf("mmsu://")<0&&$3.indexOf("ftp://")<0&&$3.indexOf("/")!=0){
return $2+"/"+$3+��$4;
}
return $1;
});
return content;
},
getPrevContent:function(){
var _sContent=this._getPrimitiveData();
var _sContent=this._stripData(_sContent);
return _sContent;
},
getTitle:function(){
if(this.oTitle){
if(this.oTitle.value==this.titleHint)
return"";
else
return this.oTitle.value;
}
return null;
},
setTitle:function(sTitle){
if(this.oTitle)
this.oTitle.value=sTitle;
},
_getPrimitiveData:function(){
var _sContent;
if(this.currMode=="Design"){
_sContent=this.oFrameBody.innerHTML;
}else{
_sContent=this.sourceEditor.value;
}
if(_sContent==this.editorHint)
_sContent='';
return _sContent;
},
_getReserveTag:function(){
return this.options.bSimpleEditor?[]:["embed","style"];
},
setData:function(sContent){
if(this.currMode=="Design"){
this.oFrameBody.innerHTML=sContent;
}else{
this.sourceEditor.value=sContent;
}
},
emptyContent:function(){
this.oFrameBody.innerHTML="";
},
_saveDataForSubmit:function(sContent){
try{
var oldContent=sContent;
if(this.sourceEditor.value=="")
this.oFrameBody.innerHTML=sContent;
else{
this.designEditorDoc.body.innerHTML=sContent;
}
sContent=this.oFrameBody.innerHTML;
}catch(e){}
$("HEContent"+this.parentId).value=sContent;
},
_exceedMaxLen:function(sContent){
var pureText=this.clearAllTag(sContent);
if(pureText.length>this.options.iMaxLen||sContent.length>this.options.iMaxLen*5){
return true;
}else
return false;
},
goPreview:function(){
var _htmlData=this.getPrevContent();
if(this.options.fnPreview!=null)
this.options.fnPreview(_htmlData);
},
focus:function(){
this.designEditor.focus();
},
setEditorWidth:function(iWidth){
this.oFrame.width=iWidth+"px";
$("editorWrap"+this.parentId).style.width=iWidth+"px";
},
clearAllTag:function(sContent){
return sContent.replace(/<\/?.*?>/ig,"");
},
_clearAllFormat:function(sTxt){
try{
var c=sTxt.replace(/\n/ig,"");
c=c.replace(/<script.*?>.*?<\/scrip[^>]*>/ig,"");
c=c.replace(/<[^>]*?javascript:[^>]*>/ig,"");
c=c.replace(/<style.*?>.*?<\/styl[^>]*>/ig,"");
c=c.replace(/<\/?(font|span|center|sohu|form|input|select|textarea|iframe|strong|b|EM|U|SUB|SUP)(\s[^>]*)?>/ig,"");
c=c.replace(/<\/?(div|code|h\d)[^>]*>/ig,'<br>');
c=c.replace(/<\?xml[^>]*>/ig,'');
c=c.replace(/<\!--.*?-->/ig,'');
c=c.replace(/<(\w[^>]*) class=([^ |>]*)([^>]*)/ig,"<$1$3");
c=c.replace(/<(\w[^>]*) style="([^"]*)"([^>]*)/ig,"<$1$3");
c=c.replace(/<(\w[^>]*) lang=([^ |>]*)([^>]*)/ig,"<$1$3");
c=c.replace(/<\\?\?xml[^>]*>/ig,"");
c=c.replace(/<\/?\w+:[^>]*>/ig,"");
c=c.replace(/<img.*?src=([^ |>]*)[^>]*>/ig,"<img src=$1 border=0>");
c=c.replace(/<a.*?href="([^"]*)"[^>]*>/ig,"<a href=\"$1\">");
c="MM163brMM"+c;
c=c.replace(/<br>\s*<br>/ig,'MM163brMM');
c=c.replace(/<center>\s*<center>/ig,'<center>');
c=c.replace(/<\/center>\s*<\/center>/ig,'</center>');
c=c.replace(/<center>/ig,'MM163brMM<center>');
c=c.replace(/<\/center>/ig,'</center>MM163brMM');
c=c.replace(/<br>/ig,'MM163brMM');
c=c.replace(/<p[^>]*>/ig,'MM163brMM');
c=c.replace(/<\/p[^>]*>/ig,'');
c=c.replace(/(\r|\n)/ig,'');
c=c.replace(/MM163brMM\s*MM163brMM/ig,'MM163brMM');
c=c.replace(/MM163brMM/ig,'</P><P style="TEXT-INDENT: 2em">');
c=c.replace("</P>","");
return c;
}catch(e){}
},
_clearHTMLFormat:function(){
if(confirm('"�����ʽ"���޸����µĸ�ʽ,ȷ�����? ')){
var bSelected=true;
if(this.isIE){
var rng=this.designEditorDoc.selection.createRange();
if(rng.text=="")
bSelected=false;
}else{
var rng=this.designEditor.getSelection().getRangeAt(0);
if(rng.collapsed)
bSelected=false;
}
if(bSelected){
this.format("removeformat");
}else{
var _sValue=this.oFrameBody.innerHTML;
try{
this.oFrameBody.innerHTML=this._clearAllFormat(_sValue);
}catch(e){}
}
}
return;
},
_checkIfHTMLTxt:function(sTxt){
var r=/<\/?(span|div|h2|h3|code|center|form|input|select|textarea|iframe|img|a).*?>/ig;
if(r.test(sTxt))
return true;
else
return false;
},
_paraFormating:function(){
var _sValue=this.oFrameBody.innerHTML;
var _reg=/<P>(.*)<\/P>/g;
var _sResult=_sValue.replace(_reg,'<P style="TEXT-INDENT: 2em">$1</P>');
this.oFrameBody.innerHTML=_sResult;
return;
}
}
Object.extend(NECtrl.AdvancedEditor.prototype,NECtrl.AbstractEditor.prototype);
if(NECtrl==undefined){
var NECtrl={};
}
NECtrl.ColorPanel=Class.create();
NECtrl.ColorPanel._ColorHex=['00','33','66','99','CC','FF'];
NECtrl.ColorPanel._SpColorHex=['FF0000','00FF00','0000FF','FFFF00','00FFFF','FF00FF'];
NECtrl.ColorPanel._picSrc=Const.STDomain+"/style/common/htmlEditor/place.gif";
NECtrl.ColorPanel.prototype={
initialize:function(sParentId,oHtmlEditor,sObjName){
this._sParentId=sParentId;
this._oHtmlEditor=oHtmlEditor;
this._sObjName=sObjName;
this._oCurrentColor=null;
this.simpleHTML=null;
this.fullHTML=null;
if(document.all)this.isIE=true;else this.isIE=false;
},
display:function(oColorDiv,sColorType){
this._displaySimpleColorBoard(oColorDiv,sColorType);
},
colorTxtOvr:function(event){
var e=Event.element(event);
e.style.border="1px #000080 solid";
e.style.backgroundColor="#FFEEC2";
},
colorTxtOut:function(event){
var e=Event.element(event);
e.style.border="1px white solid";
e.style.backgroundColor="white";
},
_drawSimpleColorPanel:function(){
var a=[];
a.push('<div style="border:1px #9FAC87 solid; width:158px;background-color:white;">');
a.push('<div style="position:relative;margin-left:2px; margin-top:3px; margin-bottom:0px;height:19px">');
a.push('<img id="colorClear'+this._sParentId+'" src="'+Const.STDomain+'"/style/common/htmlEditor/simple_colr_remove.gif" style="width:150px;height:17px;background-color:white;border:1px solid #FFFFFF;cursor:pointer;" />');
a.push('<div id="colorPrez'+this._sParentId+'" style="position:absolute;top:3px;left:4px;border:1px solid #ACA899;font-size:1px;width:28px;height:11px;"> </div>');
a.push('</div>');
a.push('<div>');
a.push('<table class="g_c_clrpd" id="colorSelectPanel'+this._sParentId+'" cellspacing="6" cellpadding="0" style="border-collapse:separate;">');
a.push('<tr>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#000000; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#993300; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#333300; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="���ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#003300; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#003366; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#000080; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#333399; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#333333; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ-80%"></img></td>');
a.push('</tr><tr>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#800000; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="���"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FF6600; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#808000; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="���"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#008000; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#008080; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#0000FF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#666699; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��-��"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#808080; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ-50%"></img></td>');
a.push('</tr><tr>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FF0000; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FF9900; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ǳ��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#99CC00; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="���ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#339966; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#33CCCC; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ˮ��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#3366FF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ǳ��"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#800080; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="������"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#999999; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ-40%"></img></td>');
a.push('</tr><tr>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FF00FF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="�ۺ�"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FFCC00; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FFFF00; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#00FF00; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#00FFFF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#00CCFF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#993366; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="÷��"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#C0C0C0; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ-25%"></img></td>');
a.push('</tr><tr>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FF99CC; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="õ���"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FFCC99; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FFFF99; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ǳ��"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#CCFFCC; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ǳ��"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#CCFFFF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="ǳ����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#99CCFF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#CC99FF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="����"></img></td>');
a.push('<td><img src="'+NECtrl.ColorPanel._picSrc+'" style="background-color:#FFFFFF; border:1px solid #ACA899;font-size:1px;width:11px;height:11px; cursor:pointer" title="��ɫ"></img></td>');
a.push('</tr>');
a.push('</table>');
a.push('</div>');
a.push('<img id="moreColor'+this._sParentId+'" src="http://b.bst.126.net/style/common/htmlEditor/more_colr.gif" style="border:1px solid white; margin-left:3px; margin-top:0px; margin-bottom:3px; height:16px; width:150px; cursor:pointer;"/>');
a.push('</div>');
return a.join("");
},
_drawFullColorPanel:function(){
var a=[];
a.push('<div style="width:203px; border:1px #4e6e89 solid;background-color:#FFFFFF">');
a.push('<div style="position:relative;margin:1px 1px 1px 1px;height:19px">');
a.push('<img id="colorClear'+this._sParentId+'" src="http://b.bst.126.net/style/common/htmlEditor/full_colr_remove.gif" style="width:199px;height:17px;background-color:white;border:1px solid white;cursor:pointer;" />');
a.push('<div id="colorPrez'+this._sParentId+'" style="position:absolute;top:3px;left:3px;border:1px solid #ACA899;font-size:1px;width:28px;height:11px;"> </div>');
a.push('</div>');
a.push('<div style="margin-left:2px!important;margin-left:1px;margin-top:2px!important;margin-top:1px; margin-bottom:1px;width:201px;">');
a.push('<table id="fullColorSelect'+this._sParentId+'" border="1" cellspacing="0" cellpadding="0" style="border-collapse: collapse;cursor:pointer; border:1px solid #000000" bordercolor="#000000" >');
for(i=0;i<2;i++){
for(j=0;j<6;j++){
a.push('<tr height=10>');
if(i==0){
a.push('<td style="padding:0px;font-size:0px;border:1px #000000 solid"><img '+((this.isIE)?"":"src="+NECtrl.ColorPanel._picSrc)+' width=9 style="font-size:1px;background-color:#'+NECtrl.ColorPanel._ColorHex[j]+NECtrl.ColorPanel._ColorHex[j]+NECtrl.ColorPanel._ColorHex[j]+'"></img></td>');
}else{
a.push('<td style="padding:0px;font-size:0px;border:1px #000000 solid"><img '+((this.isIE)?"":"src="+NECtrl.ColorPanel._picSrc)+' width=9 style="font-size:1px;background-color:#'+NECtrl.ColorPanel._SpColorHex[j]+'"></img></td>');
}
a.push('<td style="padding:0px;font-size:0px;border:1px #000000 solid"><img '+((this.isIE)?"":"src="+NECtrl.ColorPanel._picSrc)+' width=9 style="font-size:1px;background-color:#000000"></img></td>');
for(k=0;k<3;k++){
for(l=0;l<6;l++){
a.push('<td style="padding:0px;font-size:0px;border:1px #000000 solid"><img '+((this.isIE)?"":"src="+NECtrl.ColorPanel._picSrc)+' width=9 style="font-size:1px;background-color:#'+NECtrl.ColorPanel._ColorHex[k+i*3]+NECtrl.ColorPanel._ColorHex[l]+NECtrl.ColorPanel._ColorHex[j]+'"></img></td>');
}
}
a.push('</tr>');
}
}
a.push('</table>');
a.push('</div>');
a.push('</div>');
return a.join("");
},
_onMoreColor:function(oColorDiv,sColorType){
this._displayFullColorBoard(oColorDiv,sColorType);
},
_onColorClear:function(sColorType){
var color;
if(sColorType=="ForeColor"){
color="black";
}else if(sColorType=="BackColor"){
color="white";
}
try{
if(this._oCurrentColor!=null){
this._oCurrentColor_savedColor=color;
this._oHtmlEditor.format(sColorType,color);
}
this._oHtmlEditor.hiddenAllMenu();
return;
}catch(e){}
},
_onColorOvr:function(oEvent){
var _oNode;
if(this.isIE)
_oNode=event.srcElement;
else
_oNode=oEvent.target;
if(_oNode.tagName=="IMG"){
if(this._oCurrentColor!=null){
this._oCurrentColor.style.backgroundColor=this._oCurrentColor._background;
}
_oNode._background=_oNode.style.backgroundColor;
$("colorPrez"+this._sParentId).style.backgroundColor=_oNode.style.backgroundColor;
this._oCurrentColor=_oNode;
}
},
_onColorOut:function(sColorType){
if(this._oCurrentColor!=null){
if(this._oCurrentColor_savedColor!=null){
$("colorPrez"+this._sParentId).style.backgroundColor=this._oCurrentColor_savedColor;
}else{
if(sColorType=="ForeColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="black";
}else if(sColorType=="BackColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="white";
}
}
}
},
_onColorClick:function(sColorType,oEvent){
var _oNode;
if(this.isIE)
_oNode=event.srcElement;
else
_oNode=oEvent.target;
if(_oNode.tagName=="IMG"){
try{
if(this._oCurrentColor!=null){
this._oCurrentColor_savedColor=_oNode.style.backgroundColor;
this._oHtmlEditor.format(sColorType,_oNode.style.backgroundColor);
}
this._oHtmlEditor.hiddenAllMenu();
}catch(e){}
}
return false;
},
_displaySimpleColorBoard:function(oColorDiv,sColorType){
if(this.simpleHTML==null)
this.simpleHTML=this._drawSimpleColorPanel();
oColorDiv.innerHTML=this.simpleHTML;
if(this._oCurrentColor!=null){
$("colorPrez"+this._sParentId).style.backgroundColor=this._oCurrentColor_savedColor;
}else{
if(sColorType=="ForeColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="black";
}else if(sColorType=="BackColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="white";
}
}
var _oColorSelect=$("colorSelectPanel"+this._sParentId);
_oColorSelect.onmouseover=this._onColorOvr.bind(this);
_oColorSelect.onmouseout=this._onColorOut.bind(this,sColorType);
_oColorSelect.onclick=this._onColorClick.bind(this,sColorType);
var _oColorClear=$("colorClear"+this._sParentId);
_oColorClear.onclick=this._onColorClear.bind(this,sColorType);
_oColorClear.onmouseover=this.colorTxtOvr.bindAsEventListener(this);
_oColorClear.onmouseout=this.colorTxtOut.bindAsEventListener(this);
var _oMoreClear=$("moreColor"+this._sParentId);
_oMoreClear.onclick=this._onMoreColor.bind(this,oColorDiv,sColorType);
_oMoreClear.onmouseover=this.colorTxtOvr.bindAsEventListener(this);
_oMoreClear.onmouseout=this.colorTxtOut.bindAsEventListener(this);
return true;
},
_displayFullColorBoard:function(oColorDiv,sColorType){
if(this.fullHTML==null)
this.fullHTML=this._drawFullColorPanel();
oColorDiv.innerHTML=this.fullHTML;
var _oColorSelectPanel=$("fullColorSelect"+this._sParentId);
if(this._oCurrentColor!=null){
$("colorPrez"+this._sParentId).style.backgroundColor=this._oCurrentColor_savedColor;
}else{
if(sColorType=="ForeColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="black";
}else if(sColorType=="BackColor"){
$("colorPrez"+this._sParentId).style.backgroundColor="white";
}
}
_oColorSelectPanel.onclick=this._onColorClick.bind(this,sColorType);
_oColorSelectPanel.onmouseover=this._onColorOvr.bind(this);
_oColorSelectPanel.onmouseout=this._onColorOut.bind(this,sColorType);
var _oColorClear=$("colorClear"+this._sParentId);
_oColorClear.onclick=this._onColorClear.bind(this,sColorType);
_oColorClear.onmouseover=this.colorTxtOvr.bindAsEventListener(this);
_oColorClear.onmouseout=this.colorTxtOut.bindAsEventListener(this);
return true;
}
}
if(NECtrl==undefined){
var NECtrl={};
}
NECtrl.InsertAnything=Class.create();
NECtrl.InsertAnything.prototype={
initialize:function(sParentId,oEditor){
this.options=Object.extend({
sObjName:null
},arguments[2]||{});
this.parentId=sParentId;
this.objName=this.options.sObjName;
this.oEditor=oEditor;
this.body=document.body;
if(document.all)this.isIE=true;else this.isIE=false;
var oDiv=document.createElement('div');
oDiv.className="edt_lay_outer";
this.body.appendChild(oDiv);
this.coverBack=oDiv;
this.coverBack.style.display='none';
},
makeCenter:function(mainId){
var mainDiv=$(mainId);
var left=((document.documentElement.clientWidth||document.body.clientWidth)-mainDiv.offsetWidth)/2;
if(left<10)left=10;
var top=0;
top=(document.documentElement.scrollTop||document.body.scrollTop)+
((document.documentElement.clientHeight||document.body.clientHeight)-mainDiv.offsetHeight)/2;
if(top<40)top=40;
mainDiv.style.top=(top-120)+"px";
mainDiv.style.left=left+"px";
},
showCoverBack:function(){
if(this.coverBack)
this.coverBack.style.display='block';
},
hideCoverBack:function(name){
if(this.coverBack)
this.coverBack.style.display='none';
this.oEditor.fixState(name);
},
moveCursor2End:function(oInput){
var r=oInput.createTextRange();
r.moveStart("character",oInput.value.length);
r.collapse(true);
r.select();
},
showLink:function(hasLink,vHTML){
this.showCoverBack();
if(!this.linkWindow){
oMainDiv=document.createElement('div');
oMainDiv.className="edt_lay_com edt_lay_lnk";
oMainDiv.id='addLinkLayer'+this.parentId;
oMainDiv.innerHTML=this.drawLinkDlg();
this.body.appendChild(oMainDiv);
this.makeCenter('addLinkLayer'+this.parentId);
this.linkWindow=oMainDiv;
}else{
this.linkWindow.style.display='block';
}
var oInput=$('linkURL'+this.parentId);
if(hasLink){
$('isLink'+this.parentId).className="three";
oInput.value=vHTML.href;
}else{
$('isLink'+this.parentId).className="two";
var oInput=$('linkURL'+this.parentId);
oInput.value='http://';
}
oInput.focus();
if(this.isIE)
this.moveCursor2End(oInput);
$('linkOK'+this.parentId).onclick=this.addLink.bind(this,hasLink,vHTML);
$('linkURL'+this.parentId).onkeydown=this.linkInputKeyDown.bindEventWithArgs(this,hasLink,vHTML);
},
linkInputKeyDown:function(hasLink,vHTML,event){
if(event.keyCode==13){
this.addLink(hasLink,vHTML);
Event.stop(event);
}
},
addLink:function(hasLink,vHTML){
var sURL=$('linkURL'+this.parentId).value;
if(sURL==""||sURL=="http://"){
if(hasLink){
this.cancelLink();
}
}else{
if(sURL.indexOf("http://")!=0&&sURL.indexOf("https://")!=0&&sURL.indexOf("ftp://")!=0&&sURL.indexOf("mms://")!=0&&sURL.indexOf("rtsp://")!=0&&sURL.indexOf("mmst://")!=0&&sURL.indexOf("mmsu://")!=0&&sURL.indexOf("mailto:")!=0){
sURL="http://"+sURL;
}
if(hasLink){
var _oldHTML=vHTML.innerHTML;
vHTML.href=sURL;
vHTML.innerHTML=_oldHTML;
}else{
var value='';
if(vHTML!=null){
value='<a href="'+sURL+'" target="_blank">'+vHTML+'</a>';
}else{
value='<a href="'+sURL+'" target="_blank">'+sURL+'</a>';
}
this.oEditor.insertHTML(value,true);
}
}
this.hide('Link');
},
cancelLink:function(){
this.oEditor.format("unlink",null,true);
this.hide('Link');
},
drawLinkDlg:function(){
var s=[];
s.push('<div class="titlebar">');
s.push('<span>����/�޸�����</span>');
s.push('</div>');
s.push('<div class="content">');
s.push('<div class="addr"><input id="linkURL'+this.parentId+'" type="text" value="http://"></div>');
s.push('<div class="btm"><div id="isLink'+this.parentId+'" class="two">');
s.push('<input id="linkOK'+this.parentId+'" class="btncm btnok" type="button" value="ȷ ��">');
s.push('<input class="btncm" type="button" value="ȡ ��" onclick="'+this.objName+'.hide(\'Link\');return false;">');
s.push('<input class="btncm btoff" type="button" value="��������" onclick="'+this.objName+'.cancelLink();return false;">');
s.push('</div></div>');
return s.join('');
},
showTable:function(){
if(!this.tableWindow){
var oDiv=document.createElement('div');
oDiv.className="edt_lay_com edt_lay_tbl";
oDiv.id="tableMain"+this.parentId;
oDiv.innerHTML=this.drawTableDlg();
this.body.appendChild(oDiv);
this.makeCenter(oDiv.id);
this.tableWindow=oDiv;
}else{
this.tableWindow.style.display='block';
}
this.showCoverBack();
var oInput=$('tableRows'+this.parentId)
oInput.focus();
if(this.isIE)
this.moveCursor2End(oInput);
},
tableKeydown:function(event){
if(event.keyCode==13){
this.submitTable();
Event.stop(event);
}
},
drawTableDlg:function(){
var a=[];
a.push('<div class="titlebar">���ӱ���</div><div class="content" onkeydown="'+this.objName+'.tableKeydown(event);">');
a.push('<div style="margin-left:30px; margin-top:10px; margin-right:30px">��<span style="margin-left:23px">&nbsp;</span>��:<input id="tableRows');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:35px;" value="2"/>&nbsp;&nbsp;');
a.push('��<span style="margin-left:23px">&nbsp;</span>��:<input id="tableCols');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:35px;" value="2"/>');
a.push('</div>');
a.push('<div style="margin-left:30px; margin-top:5px; margin-right:30px">�������:<input id="tableWidth');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:52px;"/><span style="margin-left:5px">&nbsp;</span>');
a.push('<select name="p" style="width:86px!important;width:88px; height:22px" id="tableType');
a.push(this.parentId);
a.push('">');
a.push('<option value=1>�ٷֱ�</option>');
a.push('<option value=2>����</option>');
a.push('</select></div>');
a.push('<div class="tglicn" style="margin-left:30px; margin-top:8px"> <span id="tableImgAdvance');
a.push(this.parentId);
a.push('" onclick="');
a.push(this.objName);
a.push('.switchTableAdvance();return false;" class="fold" style="cursor:pointer;">&nbsp;</span><span style="cursor:pointer;" onclick="');
a.push(this.objName);
a.push('.switchTableAdvance();return false;" > �߼�����</span></div>');
a.push('<div id="tableAdvanceDetail');
a.push(this.parentId);
a.push('" style="display:none;overflow:hidden;">');
a.push('<div style="margin-left:46px; margin-top:4px">');
a.push('�߿��ϸ:<span style="margin-left:11px">&nbsp;</span><input id="tableBorder');
a.push(this.parentId);
a.push('" type="tableText');
a.push(this.parentId);
a.push('" name="textfield2" style="width:40px;" value="1"/>&nbsp;����');
a.push('</div>');
a.push('<div style="margin-left:44px; margin-top:3px">');
a.push('<div style="float:left">');
a.push('��Ԫ��߾�:&nbsp;<input id="tableCellpadding');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:40px;" value="1"/>&nbsp;');
a.push('</div>');
a.push('<div class="blkicn">&nbsp;</div>');
a.push('</div>');
a.push('<div style="margin-left:44px; margin-top:3px">');
a.push('<div style="float:left; margin-top:3px!important;margin-top:0px">');
a.push('��Ԫ����:&nbsp;<input id="tableCellspacing');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:40px;" value="1"/>&nbsp;');
a.push('</div>');
a.push('<div class="spcicn">&nbsp;</div>');
a.push('</div>');
a.push('</div>');
a.push('<div style="clear:both;height:0px;line-height:0px;font-size:0px;margin-left:56px;"></div>');
a.push('<div style="margin-left:56px; margin-top:21px;display:inline;" class="btm">');
a.push('<input name="button" type="button" class="btncm btnok" value="ȷ ��" onclick="');
a.push(this.objName);
a.push('.submitTable();"/>');
a.push('<input name="button" type="button" class="btncm" value="ȡ ��" onclick="');
a.push(this.objName);
a.push('.hide(\'Table\');"/>');
a.push('</div>');
a.push('</div>');
return a.join('');
},
switchTableAdvance:function(){
var adv=$("tableAdvanceDetail"+this.parentId);
var imgAdvance=$("tableImgAdvance"+this.parentId);
var maindiv=$('tableMain'+this.parentId);
if(adv.style.display=="none"){
adv.style.display="block";
Element.removeClassName('tableImgAdvance'+this.parentId,'fold');
Element.addClassName('tableImgAdvance'+this.parentId,'unfold');
maindiv.style.height='280px';
}else{
adv.style.display="none";
Element.removeClassName('tableImgAdvance'+this.parentId,'unfold');
Element.addClassName('tableImgAdvance'+this.parentId,'fold');
$("tableBorder"+this.parentId).value=1;
$("tableCellpadding"+this.parentId).value=0;
$("tableCellspacing"+this.parentId).value=0;
maindiv.style.height='218px';
}
},
submitTable:function(){
var rows=$F("tableRows"+this.parentId);
var cols=$F("tableCols"+this.parentId);
var width=$F("tableWidth"+this.parentId);
var selection=$("tableType"+this.parentId);
var widthType=selection.options[selection.selectedIndex].value;
var border=$F("tableBorder"+this.parentId);
var cellpadding=$F("tableCellpadding"+this.parentId);
var cellspacing=$F("tableCellspacing"+this.parentId);
this.addTable(rows,cols,width,widthType,border,cellpadding,cellspacing);
this.hide('Table');
},
addTable:function(iRows,iCols,iWidth,iWidthType,iBorder,iCellpadding,iCellspacing){
var _reg=/^\d+$/;
if(!_reg.test(iRows)||(iRows==0))
return;
if(!_reg.test(iCols)||(iCols==0))
return;
var _sWidth="";
if(!_reg.test(iWidth)){
_sWidth="100%";
}else{
if(iWidthType==1){
if(iWidth<=100&&iWidth>=0)
_sWidth=iWidth+"%";
else
_sWidth="100%";
}else if(iWidthType==2){
_sWidth=iWidth+"px";
}else{
_sWidth="100%";
}
}
var _sBorder=iBorder;
if(!_reg.test(iBorder))
_sBorder=0;
var _sCellpadding=iCellpadding;
if(!_reg.test(iCellpadding))
_sCellpadding=0;
var _sCellspacing=iCellspacing;
if(!_reg.test(iCellspacing))
_sCellspacing=0;
var _s=[];
if(_sBorder==0){
_s.push('<table class="editor_zero_border" width="');
}else{
_s.push('<table style="border:'+_sBorder+'px solid" width="');
}
_s.push(_sWidth);
_s.push('" border="');
_s.push(_sBorder);
_s.push('" cellPadding="');
_s.push(_sCellpadding);
_s.push('" cellSpacing="');
_s.push(_sCellspacing);
_s.push('">');
for(var i=0;i<iRows;++i){
_s.push('<tr>');
for(var j=0;j<iCols;++j){
_s.push('<td>&nbsp;</td>');
}
_s.push('</tr>');
}
_s.push('</table>');
var _sHTML=_s.join("");
this.oEditor.insertHTML(_sHTML,true);
},
showMedia:function(){
if(!this.mediaWindow){
var oDiv=document.createElement('div');
oDiv.className="edt_lay_com edt_lay_mda";
oDiv.id='mediaMain'+this.parentId;
oDiv.innerHTML=this.drawMediaDlg();
this.body.appendChild(oDiv);
this.makeCenter(oDiv.id);
this.mediaWindow=oDiv;
}else{
this.mediaWindow.style.display='block';
}
this.initMediaWindow();
this.showCoverBack();
var oInput=$('mediaUrl'+this.parentId);
oInput.focus();
if(this.isIE)
this.moveCursor2End(oInput);
},
mediaInputKeydown:function(event){
if(event.keyCode==13){
this.submitMedia();
Event.stop(event);
}
},
drawMediaDlg:function(){
var a=[];
a.push('<div class="titlebar">���Ӷ�ý��</div><div class="content">');
a.push('<div style="margin-left:20px; margin-top:10px"> �� ַ��');
a.push('<input id="mediaUrl');
a.push(this.parentId);
a.push('" ');
a.push('onkeydown="');
a.push(this.objName);
a.push('.mediaInputKeydown(event);" ');
a.push('type="text" name="textfield" style="width:420px;" class="utxt" value="http://"/>');
a.push('</div>');
a.push('<div class="tglicn" style="margin-left:20px; margin-top:10px"><span id="mediaImgAdvance');
a.push(this.parentId);
a.push('" onclick="');
a.push(this.objName);
a.push('.switchMediaAdvance();return false;" class="fold" style="cursor:pointer;">&nbsp;</span> <span style="cursor:pointer;color:#3366cc;" onclick="');
a.push(this.objName);
a.push('.switchMediaAdvance();return false;" > �߼�ѡ��</span></div>');
a.push('<div id="mediaAdvanceDetail');
a.push(this.parentId);
a.push('" style="display:none">');
a.push('<div style="margin-left:38px; margin-top:10px"><span>���ŷ�ʽ��</span>');
a.push('<input id="mediaAutoPlay');
a.push(this.parentId);
a.push('" type="checkbox" name="checkbox" value="checkbox" class="cb" style="margin-left:7px;"/>');
a.push('<span style="color:#000;">�Զ�����</span>');
a.push('<input id="mediaLoopPlay');
a.push(this.parentId);
a.push('" type="checkbox" name="checkbox" value="checkbox" class="cb" style="margin-left:19px;"/>');
a.push('<span style="color:#000;">ѭ������</span>');
a.push('</div>');
a.push('<div style="margin-left:38px; margin-top:10px"> ��ʾ�ߴ磺<span style="color:#000;"> ��</span>&nbsp;');
a.push('<input id="mediaWidth');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:40px;margin-right:25px;"/>');
a.push('<span style="color:#000;">��</span>&nbsp;');
a.push('<input id="mediaHeight');
a.push(this.parentId);
a.push('" type="text" name="textfield2" style="width:40px;"/><span style="color:#000;"> ����</span>');
a.push('</div>');
a.push('<div style="margin-left:38px; margin-top:15px;overflow:hidden;">');
a.push('<div style="float:left;"> ���뷽ʽ��</div>');
a.push('<div class="icnwrp" style="margin-left:3px;" ><div id="mediaDefault');
a.push(this.parentId);
a.push('" class="mdad" onclick="');
a.push(this.objName);
a.push('.ImgClick(this)">&nbsp;</div></div>');
a.push('<div class="icnwrp"><div id="mediaLeft');
a.push(this.parentId);
a.push('" class="mdal" onclick="');
a.push(this.objName);
a.push('.ImgClick(this)">&nbsp;</div></div>');
a.push('<div class="icnwrp"><div id="mediaCenter');
a.push(this.parentId);
a.push('" class="mdac" onclick="');
a.push(this.objName);
a.push('.ImgClick(this)">&nbsp;</div></div>');
a.push('<div class="icnwrp"><div id="mediaRight');
a.push(this.parentId);
a.push('" class="mdar" onclick="');
a.push(this.objName);
a.push('.ImgClick(this)">&nbsp;</div></div>');
a.push('</div>');
a.push('<div style="clear:both; margin-left:127px; margin-top:3px;">');
a.push('<span style="color:#000;">Ĭ��</span>');
a.push('<span style="margin-left:62px;color:#000;">����</span>');
a.push('<span style="margin-left:62px;color:#000;">����</span>');
a.push('<span style="margin-left:62px;color:#000;">����</span>');
a.push('</div>');
a.push('<div style="margin-left:37px; margin-top:15px;"><input id="mediaRemember');
a.push(this.parentId);
a.push('" type="checkbox" class="cb"/> <span style="color:#000;font-size:12px;">�Ժ�ʹ�ô˴�����</span></div>');
a.push('</div>');
a.push('<div style="margin-left:180px; margin-top:15px;display:inline;" class="btm">');
a.push('<input name="button" type="button" class="btncm btnok" value="ȷ ��" onclick="');
a.push(this.objName);
a.push('.submitMedia();"/>');
a.push('<input name="button" type="button"  class="btncm" value="ȡ ��" onclick="');
a.push(this.objName);
a.push('.hide(\'Media\');"/>');
a.push('</div>');
return a.join('');
},
initMediaWindow:function(){
this.setMediaByCookie();
},
setMediaByCookie:function(){
var c=this.getCookieByName("addMediaCookie");
var mediaCookie=c.split('|');
if(mediaCookie[0]==1){
$("mediaAutoPlay"+this.parentId).checked=true;
}else{
$("mediaAutoPlay"+this.parentId).checked=false;
}
if(mediaCookie[1]==1){
$("mediaLoopPlay"+this.parentId).checked=true;
}else{
$("mediaLoopPlay"+this.parentId).checked=false;
}
if(mediaCookie[2]!=undefined&&mediaCookie[2]!="")
$("mediaWidth"+this.parentId).value=mediaCookie[2];
if(mediaCookie[3]!=undefined&&mediaCookie[3]!="")
$("mediaHeight"+this.parentId).value=mediaCookie[3];
var oPosition;
switch(mediaCookie[4]){
case"mediaLeft":
oPosition=$("mediaLeft"+this.parentId);
break;
case"mediaCenter":
oPosition=$("mediaCenter"+this.parentId);
break;
case"mediaRight":
oPosition=$("mediaRight"+this.parentId);
break;
default:
oPosition=$("mediaDefault"+this.parentId);
}
oPosition.style.borderColor="#316AC5";
this.currPos=oPosition;
},
addCookie:function(autoChecked,loopChecked,wid,high,position){
var date=new Date();
var expireDays=300;
date.setTime(date.getTime()+expireDays*24*3600*1000);
document.cookie='addMediaCookie='+autoChecked+'|'+loopChecked+'|'+
wid+'|'+high+'|'+position
+";domain=163.com;expires="+date.toGMTString();
},
getCookieByName:function(c_name){
if(document.cookie.length>0){
c_start=document.cookie.indexOf(c_name+"=");
if(c_start!=-1){
c_start=c_start+c_name.length+1;
c_end=document.cookie.indexOf(";",c_start);
if(c_end==-1)
c_end=document.cookie.length;
return unescape(document.cookie.substring(c_start,c_end));
}
}
return"";
},
switchMediaAdvance:function(){
var adv=$("mediaAdvanceDetail"+this.parentId);
var imgAdvance=$("mediaImgAdvance"+this.parentId);
if(adv.style.display=="none"){
adv.style.display="block";
Element.removeClassName('mediaImgAdvance'+this.parentId,'fold');
Element.addClassName('mediaImgAdvance'+this.parentId,'unfold');
this.mediaWindow.style.height='355px';
}else{
adv.style.display="none";
Element.removeClassName('mediaImgAdvance'+this.parentId,'unfold');
Element.addClassName('mediaImgAdvance'+this.parentId,'fold');
this.mediaWindow.style.height='155px';
}
},
ImgClick:function(obj){
if(obj!=this.currPos){
obj.style.borderColor="#316AC5";
this.currPos.style.borderColor="white";
this.currPos=obj;
}
},
isInt:function(oNum){
if(!oNum)
return false;
var strP=/^\d+$/;
if(!strP.test(oNum))
return false;
else
return true;
},
clearMedia:function(){
$("mediaAutoPlay"+this.parentId).checked=false;
$("mediaLoopPlay"+this.parentId).checked=false;
$("mediaWidth"+this.parentId).value='';
$("mediaHeight"+this.parentId).value='';
$("mediaLeft"+this.parentId).style.border='white 2px solid';
$("mediaCenter"+this.parentId).style.border='white 2px solid';
$("mediaRight"+this.parentId).style.border='white 2px solid';
$("mediaDefault"+this.parentId).style.border='white 2px solid';
$("mediaRemember"+this.parentId).checked=false;
},
submitMedia:function(){
var autoPlay;
var loopPlay;
var width;
var height;
if($("mediaAutoPlay"+this.parentId).checked==true){
autoPlay=1;
}else{
autoPlay=0;
}
if($("mediaLoopPlay"+this.parentId).checked==true){
loopPlay=1;
}else{
loopPlay=0;
}
var wid=$("mediaWidth"+this.parentId).value;
var high=$("mediaHeight"+this.parentId).value;
if(wid==''||!this.isInt(wid)){
width="";
}else{
width=wid;
}
if(high==''||!this.isInt(high)){
height="";
}else{
height=high;
}
if($("mediaRemember"+this.parentId).checked==true){
this.addCookie(autoPlay,loopPlay,width,height,this.currPos.id);
}
var sUrl=$("mediaUrl"+this.parentId).value;
this.addMedia(sUrl,autoPlay,loopPlay,width,height,this.currPos.id);
this.hide('Media');
},
addMedia:function(sUrl,bAuto,bLoop,width,height,sPos){
if(sUrl==""||sUrl=="http://")
return false;
var _real=/^http:\/\/(.+)\.(rm|rmvb|rt|ra|rp|rv|mov|qt|aac|m4a|m4p|ssm|sdp|3gp|amr|awb|3g2|divx)$/ig;
var _wm=/^http:\/\/(.+)\.(mp3|avi|asf|wmv|wma|mpg|mpeg|wax|asx|wm|wmx|wvx|wav|mpv|mps|m2v|m1v|mpe|mpa|mp4|m4e|mp2|mp1|au|aif|aiff|mid|midi|rmi)$/ig;
var _flash=/^http:\/\/(.+)\.swf$/ig;
var _sPos=sPos;
var _sAuto=bAuto;
var _sLoop=bLoop;
var _sWidHigh;
if(width!=""){
_sWidHigh=" width="+width;
}else{
_sWidHigh="";
}
if(height!=""){
_sWidHigh=_sWidHigh+" height="+height;
}
var _sMediaHTML='';
var _sStyle="";
switch(_sPos){
case"mediaLeft":
_sStyle="FLOAT: left; MARGIN: 0px 10px 10px 0px";
break;
case"mediaCenter":
_sStyle="DISPLAY: block; MARGIN: 0px auto 10px; TEXT-ALIGN: center";
break;
case"mediaRight":
_sStyle="FLOAT: right; MARGIN: 0px 0px 10px 10px";
break;
default:
_sStyle="DISPLAY: block";
}
var _bIsReal=false;
if(_real.test(sUrl)){
_bIsReal=true;
if(width==""||height==""){
_sWidHigh="width=300 height=200";
}
_sMediaHTML='<embed src='+sUrl+' style="'+_sStyle+'" type="audio/x-pn-realaudio-plugin" controls="ImageWindow,ControlPanel,StatusBar" '+
_sWidHigh+' autostart="'+_sAuto+'" loop="'+_sLoop+'"></embed>';
}else if(_wm.test(sUrl)){
_sMediaHTML='<embed src='+sUrl+' style="'+_sStyle+'" pluginspage="http://www.microsoft.com/isapi/redir.dll?prd=windows&amp;sbp=mediaplayer&amp;ar=media&amp;sba=plugin&amp;" type="application/x-mplayer2" showcontrols="1" showaudiocontrols="1" showstatusbar="1" enablecontextmenu="1" '+
_sWidHigh+' autostart="'+_sAuto+'" loop="'+_sLoop+'"></embed>';
}else if(_flash.test(sUrl)){
_sMediaHTML='<embed src='+sUrl+' style="'+_sStyle+'" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" '+
'wmode="transparent" quality="high" '+_sWidHigh+'></embed>';
}else{
_sMediaHTML='<embed src='+sUrl+' style="'+_sStyle+'"'+_sWidHigh+' autostart="'+_sAuto+'" loop="'+_sLoop+'"></embed>';
}
_sMediaHTML+='&nbsp;';
this.oEditor.insertHTML(_sMediaHTML,true);
if(this.isIE&&_bIsReal)
this.oEditor.designEditorDoc.body.contentEditable=true;
},
hide:function(name){
if(this.linkWindow)this.linkWindow.style.display='none';
if(this.tableWindow)this.tableWindow.style.display='none';
if(this.mediaWindow)this.mediaWindow.style.display='none';
this.hideCoverBack(name);
if(name=='Media')
this.clearMedia();
this.oEditor.setInserting(false);
}
}
if(NECtrl==undefined){
var NECtrl={};
}
NECtrl.Portrait=Class.create();
NECtrl.Portrait._faceTips=
['΢Ц','����Ц','����','ʧ��','����',
'�ú�Ц','�','�絽��','��','����ˮ��',
'������','����','գ��','������','��',
'������','��˵','��','ɫ����','��ѵ',
'�ɰ�','YEAH','����','����','����',
'����','��Ľ��','��','�ڱǿ�','����',
'����','����','�ϴ�','Ƿ��','����Ц��',
'����','����æ','���','͵͵Ц','�ͻ�����',
'������һ��','������','�ݰ�','�����Ц','����',
'����','����','�ѹ�','̾��','����Ů��',
'õ��','�ð���','������','����','NO',
'YES','�ո���','������','����','��������',
'��Ѫ�ĵ�','ը��','����','������','��Ѫ����',
'���','��һ��','����','��绰','��',
'����','����','��Ǯ','̫��','����',
'����','Сè','С��','��ͷ','��ˮ',
'����','����','����','Լ��','CALL��'
];
NECtrl.Portrait._westTips=
['΢Ц','����','����','����','���˰�','����','ţ��','С��','������','����',
'����','����','ʱ��','����','��ˬ','ʹ��','ţͷ','����','���հ�','�ټ�',
'˧��','��һ��','�绰','�׻�','���ǰ�','����ͷ','yes','no','ˬ��','С��',
'����','����','����','����','����','����','����','yeah','���','�ȷ�',
'����','����','����','����','��ף','��̾','�к�','��ο','���а�','����',
'ʤ����','�к�','�ҿ�','�ɰ�','��ˬ','����','��Ц','call��','����Ŷ','��Ϣ',
'��','����','��Ц','����','����','Ż��','����','�ұ���','����','����',
'��ҽ','����','ϲ����','������','��','����','����','����','��ù','�Ҷ�',
'����ˮ','�ٶ�','������','��ӭ','��ϲ','�ʼ�','���ҵ�','����','ɫ����','�װ���',
'��ϡ��','ǿ','�Ⱦ�','�군','��ͷ','�ݰ�','ˬ��','�׻�','������','�',
'������','���','С����','����'
];
NECtrl.Portrait._popoTips=
['������','������','֩����','΢Ц','ץ��','����Ѫ','˭��p','������','���','Ѫ����',
'���ǰ�','���Ƿ','��˥','��Һ�','Ͷ��','��Ц','����ˮ','�ϴ�','�۰�','������',
'����','ʹ��','����','����','����','����','����','����','��','����',
'ŭ��','ɵЦ','����','��ù','����','��Ľ','͵��','����','��ש','������',
'��ɫ','����','����','����','����','����','������','����','ǿ','��',
'ˬ��','����','yoyo','̫�в�','����','����','ˣ��','ȱ��','�ִ���','�Ѻ�',
'����','�ҿ�','����','����','������','����','��ҲҪ','��ζ','��Ц','����',
'����','����','����','�κ�','����','�ߺ�','�۾�','����','��С��','������',
'�׳���','���','��ӭ','����',
'��ǹ','�緫','����','����MM','����',
'����','ƽ��ľ','Ǧ��','ȭ��','���',
'���','����','��ȭ��','�ﾶ','�ﾶMM',
'����','����','����','�Ÿ���','����',
'����','����','����','Ƥ��ͧ','Ƥ��ͧ',
'ƹ��','���г�','������','ɳ̲����','ˮ������',
'���','��̨','����','��Ӿ','��ë��','���ͣ�','���ͣ�'
];
NECtrl.Portrait._bearTips=
['����','������','����ʳ','д��','����','����','��Ƥ��','����Ŷ','�Է���','�Ա���',
'��Ц','����','����','����','����','գ�۾�','������','����','������','������',
'��в','�����','����','����','�߸�','ħ����','���','�ټ�','����'
];
NECtrl.Portrait._tuTips=
['���峬�˳¶�','�����','��~~~������','�Ա���','HAPPY~~',
'�� ������','�ü��ü�','�ÿ���','BS��','������',
'���峬��','��Ƥ','WS�ϱ��','����С����','�ڰ��ڱǿ�',
'��ը����','�糾ʽ����','����תȦȦ','ɫ������','�����ӳ�',
'��һ��','��ݮ������','��������','����С��','��������',
'��׷ѽ׷','����ѽ��','�滨����','��Ҫ�뿪��','���������',
'Թ��','ץ��','WS͵͵Ц','��ӭ��ӭ','���һ�ӭ',
'����ŤŤ','ɫɫŤŤ','����ŤŤ','���˵�С�','˧��',
'WS�۾���','�����°���','ָ�ű�����','���ĵ�Ʈ��','������',
'������','��ˬ','121 121 121','�����������','ҡ��ҡ',
'���ҵ�����','С��ŤŤ','С��ŤŤ','�²��°�','С������',
'С������','С������','С������','HAPPYС����','����С����',
'����С����','����Ů����','������ɫ��WSN~~~~','��˵����','����ʲô��',
'��ʬ����','��ʬ����','��ʬ�ְ�','��ʬүү','һ����~~',
'һ����~~','����һ��','��ŤŤ��','��ŤŤ��','��ʬ���������~~~',
'ż���ڽ�����','������~','�Ļ�ŭ��','����~~','�׵ط���',
'����','�~~~','���ȷ���','�����̴��к�','���ȷ���',
'ʥ������','ʥ����','ϴ�װ�',' �̲���Ĥ','�ɿ�����Ĥ',
'˯����','��ƨ��ը','��������','������Ӿ','�Ȼ���',
'��ϲ����','�вƽ���','��������','�Բ���','������',
'����','����','���ӻ��','���˽ڿ���','��˼����',
'С�ɰ�','С����','ץץ��','���տ���','�ٽ�','ҡҡ��','����ŤŤ��','�Թ�ŤŤ��','����·','���˻����','�󱦱�','ţ����','������','�ñ���','������','�߱���','������','�򱦱�','�ﱦ��','������','������','������','������','�Ա���','��ˮ','��ˮ','�ټ�PMP','����PMP'
];
NECtrl.Portrait._rTips=
['��������','�ɶ�','ŤŤ����','����','�Ҿ�˵��','������','����','����Ҽ���','��Ц','̫��Ц��','��ô!?','���ҵ�','���Կ�','�����!','ҡ��','Ť��','�ٲ���','����','����Ȧ','��ô����...','����','�����!!','����ʹ!','���������','YinЦ','����','��ʹ���!','����','�㰡�㰡!','Ǳˮ','����','С����!','NONONO','��ô����ô��?','��Ƥ','����LOLI','����','Ťͷ','��߲����Ǳ߲���!','�緹!','�ݰ�','�尡','����','�е��Ծ�������','����','ҡҡ�λ�','����','ʧ��','��ͳ���!','�о�ϲ!','��ѽѽѽ!','������','��ȦȦ','������!','������','��ѽ��ѽ!~','ͷ�ܹ⻬','��˵û˵��!','����ҡ��!','��������','���ʡ�','������','������','��ˢ��ˢѹ','��ϴ��ϴ��','����...','��ʬ','�ұ��ұ��','����������','�㶺�ˣ�','������','ɱ�˿�ħ','���򡫡�','ײǽ��','�尡��','����ս','��ͷ','������ȥ','ȸԾ��','��Ϣ��','ײͷ��'];
NECtrl.Portrait._gTips=
['����','̾��','��Ӵ~','����','��Ϻ��','88','����','�۸���','������','������','��HIGH','ȼ�ˣ�','�װ�D','�Ȳ�','ͷ��','���в�','��~','����','����','�ţ�','��ͷ','��Ҫ߹~','��~','��ɫ����','����','NONO','̧�۾�','��ʹ','����','��ȭ','������','̾','��ħ','������','��������','�ܴ��','�Ⱦ�','��Ŷ','�ܴ̼���','ѧϰ','����','��','����','����','�ٱ���','����','�ð�߹','�۸���','Ʈ~','��~','ҡ߹ҡ','����','����']
NECtrl.Portrait._mayangTips=
['����Ӭ','����','͵��','��','����','ˢ��','����','�Ժ���','�����ǹھ�','Ѭ��Ӭ','������','ҡͷ','תͷб��','����','����','̾��','��Σ����','����','���','��','��','���','Ʈ��','��','��','�ƻ�','ŭ','��ָ','˯��','�ʺ�','��','����','ʤ��','Ү','����','��','��Ц','����','������'];
NECtrl.Portrait._naiTips=
['����','èè','�Ұ���ƿ','����','����','�ټ�','���ͷ�','��������','��Ц','����ҧ��ƿ','ŭ��','��Ц2','΢Ц','����','�������۹�','����ƿ','�������','����ƿ˯��','ſ�ڵ��Ͽ�','��Ű','����','��üͷ','·��','����ͷ','�������','������ͷ','����','������ƿ','ʤ������','����','ָ��','����','����������','������','��Ϣһ��','�����','��ڴ�����','��в','�ƻ���Ц','��Ҫ','̤����ƿ��Ц','�ż���ͷ������','�����','��������','������ҡҡ��ƿ','�ж�','��Ц���I','������Ц','����','��ѵ','����','����2','��ͷ','Ŭ��','����','Ż��','����','��','��','��','����','��','��','����','�ɻ�','�ֹ�','����','�ȶ�','��','��ŭ','Ϲ����','�̳�','����','˯����','����','�̳����','����','��ɨ','�ɾ�ʮ��','��Ǯ','���۸�','�׵�','��ǰ����','��','������','���Ϻ�','ð����','�ݰ�','-�����ܲ�','��ɰ�','�����ƿ��','��ð','����','˦ͷ','лл','�Ӱ�','��ʹ','����','���','�绰����','����','�Ժ���','ϴ��','SORRY','�����','ɳ��','����','����','��ң','ҡ��','����','����','ײǽ','��','��ϲ','������','����2','����','��','Ͷ��','�����','K��','ɱ��','��������','����','DJ','��������','����','˱��ָ','���','������','��Ū','����','������Ĺ���','����'];
NECtrl.Portrait._minimoTips=
['��ϲ��','��','���','Ʈ��','����','������','��','�����','��','��','�ɰ�','����Ů��','����','��ˣ','����','�Զ���','�����´�','Ǯ��Ǯ','����','�м�ı','��Ц','Ǳˮ̫��','�����','��Ҫ','˯��','ŤŤ����','������','����','����','·��','����','����','������','����','�Ҵ���','�ټ�','��','����','����','����','͵��','ʤ��','����','�Ҵ�','��'];
NECtrl.Portrait._mlihoTips=
['�Զ���','���۸���','�ٺ�','��ӭ','�װ���','����','͵��','Ц����','��Ѫ','�ټ�','������','�ܺú�ǿ��','ˣ��','����','�Һ�','����','��Ǯ','������','��ϲ','����','����','ϲ��','�۰�','����','����','����','����','�����','�ɻ�','����Ů߹','ˢ����','����','������','������','��ŭ','������','��������','����','������','��Ц','����','����','����','����','����','̽��','����','����','Ű��','�ܹ�'];
NECtrl.Portrait._likiTips=
['ok','͵Ц','��Ц','����','���','����','���','��Ľ','ŭ��','ʧ��','��','��ǰ��','�ϴ�','��ѵ','��','���','ί��','�׻�','��','��Ƥ','��','����','��','����','ˢ��','����'];
NECtrl.Portrait._mxTips=
['����','����','��','��Ц','գ��','������','����','��ͷ','ҡͷ','��','������','������','������','happy','������','���տ���','����','������','����','��','һ����','����','ŤѽŤ','������','������','����','�ױ���','����','����','������','����','͵Ц','���','��','��','˽��','����','ί��','����','��','ǿ��','͵��','��ס','�׻�','����','hi','˯','����','ôô','��','��','��Ҫ','����','��','�ټ�','��˵','����','����','Ť��','������'];
NECtrl.Portrait._xiayuTips=
['555��','����','���','����','�ߺ�~~','happy~','������','Ү~','����','ί��','love','����','ǰ��','˼��','����ʹ','love','����','ǰ��','˼��','����ʹ','�Է���','˯����','��ױ','����','ʲô','����','æ','�����Ŀ�','��Ц','���ͷ�','�ȹ�֭','��','ŭ��','��ǿ��','ɵ����','������','no','˦��','����'];
NECtrl.Portrait._coboTips=
['������','�˯','��������','�����','NO!NO!',
'Hi!','��ĥ����ĥ��','ײǽ','�꣡','��������',
'Ǳˮ��','͵Ц','����','�ٱ�','Ц����',
'�ұ�','�ٹ�','����','��','��HAPPYŶ',
'��','�ٺ�','��ѽ','����','����',
'ŤŤ','����','����','��Ʈ','��ת����',
'����Ť','�������','������ȥ','������','��ϲ����',
'Ү��','���͡�','��ð��','������','����ͷ',
'����','���ҵ�','������ӭ��','����','�й�����',
'�Ҷ�','����','����','����̫������','����',
'������','������','��ʽ�η�','�Ҷ�','��������',
'�һ�ȦȦ','������','ͬ־�Ǻá�','���׵�','�Բ�',
'�Ҵ��Ҵ�','����','����','Ү��','������',
'��ƨ','��������...','Ŷ��','�ߣ�','��������','������','���У�','Ŷ','�õ�����','�� ��','���У�','��ȹ��','������','������','���ۻ���','���У�','��������','�ң��ϴ�','�ܼ�ȭ��','�꣡С����!','��ת���֣�','��','��ĥ','ײǽ','�ҳ�','����','�ٹ�','�Ʒ���','����ʮ����','����','�����С���','��Ů','88','Ц������','�����Ǽ���ɣ�','װ�ɰ�','��������','88','�ᰡ��','no no'];
NECtrl.Portrait._popTips=
['�Է�','��','ץ��','��Ѫ','��','����','����','ɨ��','Ǳˮ','BIBI','KAO','����','����','����','��','ˬ��','��˦','����','Ӵ��','ȥ���','����','����','�����','�ж�','��ˮ','��ð�','�㡭���ҵ�','��','ϴ����',' ��¹����',
'��ǹ','������','�ҡ�����ѽ������','����ɶ��','ǡ��һȭ','�ٱǱ�','������','��','������','�ú���','��ͷ','�����','��Ц',' ��Ц','��'];
NECtrl.Portrait._meakyTips=
['����','����','ý��','��Ц','����','����','����','���','����','�ܲ�','��~','Ĥ��','ŭ��','�Բ�'];
NECtrl.Portrait._wuzhiTips=
['������','ʯ��','Ԫ������','���Գ�','����','�ֲ�','����·','������˼','���տ���','��','����ν','����','������','лл','͵��','kiss','���','Ƥ������','������','������','��������','�ڱ���','��Ц','����','sm','orz','��','ɫ����','ҧס','����','�����ǳ�','����','�����','ҡͷ����','�˯','����','ŭ','˼��'];
NECtrl.Portrait._pegTips=
['����','�ٺ�...','����','��������','�Ұ�ƯƯ','ˢ��','��ó�','��ѽ','����','��������','����','����','�ԹϹ�','�Ұ����','���湦','�ɰ�','��Ц','˯����','����','ʤ��','ί��','��˯����','����','��˯��','����','������'];
NECtrl.Portrait._frogleonTips=
['����','����','����','ŭ','�ɻ�',
'�ɰ�','����','����','ί��','ϲ��',
'ʹ��','��ϲ','��ף','����','��Ц',
'ȸԾ','ҧ���г�','��ˬ','��С����','����',
'�亹','����','�Ծ�','ץ��','����',
'��ϲ','����','����','����','�ж�'];
NECtrl.Portrait._zhuxiaoliangTips=['�ҷɡ�','��·�','����','����','�绨��','���Ӭ','�м�','�޸��㿴','������','����','�Է���','�ó�','Ʈ��','�ݿ���','�ݲ�'];
NECtrl.Portrait._popommTips=[
'ͬ��','����','Ů��','����','����Ĥ',
'��ˣ','����','����','�ȿ�','����',
'��Ҫ�� ','����','����','�밲','Ϊʲô',
'ŭ','����','�ɰ�'
];
NECtrl.Portrait._tips=
{"face":NECtrl.Portrait._faceTips,
"popo":NECtrl.Portrait._popoTips,
"west":NECtrl.Portrait._westTips,
"bear":NECtrl.Portrait._bearTips,
"tu":NECtrl.Portrait._tuTips,
"r":NECtrl.Portrait._rTips,
"g":NECtrl.Portrait._gTips,
"mayang":NECtrl.Portrait._mayangTips,
"nai":NECtrl.Portrait._naiTips,
"minimo":NECtrl.Portrait._minimoTips,
"mliho":NECtrl.Portrait._mlihoTips,
"liki":NECtrl.Portrait._likiTips,
"mx":NECtrl.Portrait._mxTips,
"xiayu":NECtrl.Portrait._xiayuTips,
"cobo":NECtrl.Portrait._coboTips,
"pop":NECtrl.Portrait._popTips,
"meaky":NECtrl.Portrait._meakyTips,
"wuzhi":NECtrl.Portrait._wuzhiTips,
"peg":NECtrl.Portrait._pegTips,
"frogleon":NECtrl.Portrait._frogleonTips,
"zhuxiaoliang":NECtrl.Portrait._zhuxiaoliangTips,
"popomm":NECtrl.Portrait._popommTips
};
NECtrl.Portrait._filePath="http://b.bst.126.net/style/common/htmlEditor/portrait/";
NECtrl.Portrait._row=6;
NECtrl.Portrait._col=10;
NECtrl.Portrait._navRow=8;
NECtrl.Portrait._navPageHeight=176;
NECtrl.Portrait._portraitPage=function(iSize,sName,sPath,iGrid,bNewly){
this.size=iSize;
this.name=sName;
this.path=sPath;
this.grid=iGrid;
this.newly=bNewly;
this.pageCount=Math.ceil(iSize/(NECtrl.Portrait._row/iGrid*NECtrl.Portrait._col/iGrid))-1;
};
NECtrl.Portrait._allCat={
"face":new NECtrl.Portrait._portraitPage(85,"����","face",1),
"popo":new NECtrl.Portrait._portraitPage(121,"������","popo",1),
"west":new NECtrl.Portrait._portraitPage(104,"�λ�����","west",1),
"bear":new NECtrl.Portrait._portraitPage(29,"������","bear",2),
"tu":new NECtrl.Portrait._portraitPage(133,"�ö���","tu",2),
"r":new NECtrl.Portrait._portraitPage(81,"������","r",2),
"g":new NECtrl.Portrait._portraitPage(53,"��ͷ��","g",2),
"mayang":new NECtrl.Portrait._portraitPage(39,"����è","mayang",2),
"nai":new NECtrl.Portrait._portraitPage(135,"��ƿ��","nai",2),
"minimo":new NECtrl.Portrait._portraitPage(45,"ññ��","minimo",2),
"mliho":new NECtrl.Portrait._portraitPage(50,"������","mliho",2),
"liki":new NECtrl.Portrait._portraitPage(26,"liki����","liki",2),
"mx":new NECtrl.Portrait._portraitPage(60,"��������","mx",2),
"xiayu":new NECtrl.Portrait._portraitPage(34,"С��","xiayu",2),
"cobo":new NECtrl.Portrait._portraitPage(105,"�����","cobo",2,true),
"pop":new NECtrl.Portrait._portraitPage(45,"���ڱ�","pop",2,true),
"meaky":new NECtrl.Portrait._portraitPage(14,"������è","meaky",2),
"wuzhi":new NECtrl.Portrait._portraitPage(38,"��֪��è","wuzhi",2),
"peg":new NECtrl.Portrait._portraitPage(15,"PEG","peg",2),
"frogleon":new NECtrl.Portrait._portraitPage(30,"�̶���","frogleon",2),
"zhuxiaoliang":new NECtrl.Portrait._portraitPage(15,"��С��","zhuxiaoliang",2),
"popomm":new NECtrl.Portrait._portraitPage(18,"������","popomm",2)
};
NECtrl.Portrait._allTypes=["face","popo","west","bear","tu","r","g","mayang","nai","minimo","mliho","liki","mx","xiayu","cobo","pop","meaky","wuzhi","peg","frogleon","zhuxiaoliang","popomm"];
NECtrl.Portrait.prototype={
initialize:function(sParentId,oHtmlEditor){
this._oOptions=Object.extend({
bNav:false,
sObjName:null,
fnGetPref:null,
fnAfterPortraitClick:null,
fnSetPref:null
},arguments[2]||{});
this._sParentId=sParentId;
this._oHtmlEditor=oHtmlEditor;
this._sStart="face";
this._current=new Object();
this._current.navPage=0;
this._current.type=this._sStart;
this._current.page=0;
this._sObjectName=this._oOptions.sObjName;
this._oPortraitDiv=null;
var _data={editorId:this._sParentId,isNav:this._oOptions.bNav,objName:this._sObjectName};
this._sPortraitHTML=NECtrl.Portrait._sPorJst.processUseCache(_data);
return this;
},
display:function(oPortraitDiv){
var _type=this._current.type;
if(this._oOptions.fnGetPref){
_type=this._oOptions.fnGetPref()||this._current.type;
}
var _page=this._current.page,_types=NECtrl.Portrait._allTypes;
oPortraitDiv.innerHTML=this._sPortraitHTML;
this._oPortraitDiv=oPortraitDiv;
this._oPortraitDiv.onclick=function(oEvent){
Event.stop(isIE?window.event:oEvent);
};
if(this._oOptions.bNav==true){
this._setNav();
}
this.go(_type);
for(var i=0;i<_page;i++)
this.portraitNextPage();
},
go:function(sType){
this._current.type=sType;
this._current.page=0;
this._change(sType);
},
clickNavPageup:function(){
if(this._current.navPage>0){
var _navs=$('navs'+this._sParentId),_style=_navs.style;
_style.top=parseInt(_style.top)+NECtrl.Portrait._navPageHeight+'px';
this._current.navPage--;
!(this._current.navPage)&&Element.addClassName('navPageup'+this._sParentId,'disabled');
Element.removeClassName('navPagedown'+this._sParentId,'disabled');
this.go(NECtrl.Portrait._allTypes[this._current.navPage*NECtrl.Portrait._navRow]);
}
},
clickNavPagedown:function(){
var _navPageCount=Math.floor(NECtrl.Portrait._allTypes.length/NECtrl.Portrait._navRow)+1;
if(this._current.navPage<_navPageCount-1){
var _navs=$('navs'+this._sParentId),_style=_navs.style;
_style.top=parseInt(_style.top)-NECtrl.Portrait._navPageHeight+'px';
this._current.navPage++;
if(this._current.navPage==_navPageCount-1)
Element.addClassName('navPagedown'+this._sParentId,'disabled');
Element.removeClassName('navPageup'+this._sParentId,'disabled');
this.go(NECtrl.Portrait._allTypes[this._current.navPage*NECtrl.Portrait._navRow]);
}
},
portraitMouseOvr:function(oPorPic,iNum,iGrid){
oPorPic.style.border='1px solid #000000';
var _oPreview=$("portraitPreview"+this._sParentId);
var row,col;
if(iGrid==1){
row=NECtrl.Portrait._row;
col=NECtrl.Portrait._col;
}else{
row=NECtrl.Portrait._row/2;
col=NECtrl.Portrait._col/2;
}
var _iCountStart=this._current.page*row*col;
_oPreview.innerHTML='<table style="table-layout:auto;width:60px;height:60px;border:solid #777777 1px;background-color:#ffffff"><tr valign=middle align=center><td><img src='+NECtrl.Portrait._filePath+this._current.type+"/preview/"+this._current.type+(_iCountStart+iNum)+'.gif></td></tr></table>';
var _pos=oPorPic.parentNode.cellIndex;
if(Math.round(_pos/col)){
_oPreview.style.left='4px';
_oPreview.style.right='';
}else{
if(this._oOptions.bNav==true){
_oPreview.style.right='69px';
}else{
_oPreview.style.right='7px';
}
_oPreview.style.left='';
}
_oPreview.style.top="5px";
_oPreview.style.display="block";
},
portraitMouseOut:function(oPorPic){
oPorPic.style.border='';
var _oPreview=$("portraitPreview"+this._sParentId);
_oPreview.style.display="none";
},
portraitClick:function(_element){
var sSrc=_element.attributes['source'].nodeValue;
if(sSrc!=null){
var index=sSrc.lastIndexOf("/");
var file=sSrc.substring(index);
sSrc=sSrc.replace(file,"/preview"+file);
this._oHtmlEditor.format("InsertImage",sSrc);
this._oHtmlEditor.hiddenAllMenu();
if(this._oOptions.fnAfterPortraitClick){
this._oOptions.fnAfterPortraitClick();
}
}
},
portraitNextPage:function(){
var _obj=this._getTypeObj(this._current.type);
if(this._current.page!=_obj.pageCount){
this._current.page++;
}
this._change(this._current.type);
$('portraitContent'+this._sParentId).className=this._current.type+this._current.page;
},
portraitPrePage:function(){
if(this._current.page!=0){
this._current.page--;
}
this._change(this._current.type);
$('portraitContent'+this._sParentId).className=this._current.type+this._current.page;
},
_setNav:function(){
var _temp=document.createElement('div');
var _iSize=NECtrl.Portrait._allTypes.length;
for(var i=0;i<_iSize;i++){
var _oNav=document.createElement('div');
var _sType=NECtrl.Portrait._allTypes[i];
_oNav.id=_sType+this._sParentId;
_oNav.className="navitem";
_temp.appendChild(_oNav);
}
var _navs=$('navs'+this._sParentId)
var _navPageCount=Math.floor(NECtrl.Portrait._allTypes.length/NECtrl.Portrait._navRow)+1,_page=this._current.navPage;
if(_page>=0){
var _style=_navs.style;
_style.top=parseInt(_style.top)-_page*NECtrl.Portrait._navPageHeight+'px';
if(_page==_navPageCount-1)
Element.addClassName('navPagedown'+this._sParentId,'disabled');
if(_page==0)
Element.addClassName('navPageup'+this._sParentId,'disabled');
}
_navs.appendChild(_temp);
},
_changeTag:function(sType){
var _iSize=NECtrl.Portrait._allTypes.length;
for(var i=0;i<_iSize;i++){
var _type=NECtrl.Portrait._allTypes[i];
var _oNav=$(_type+this._sParentId);
if(_type==sType){
Element.addClassName(_oNav,"mf_nowchose");
_oNav.innerHTML="&nbsp;"+NECtrl.Portrait._allCat[_type].name+(NECtrl.Portrait._allCat[_type].newly?'<span>��</span>':'');
Element.removeClassName('navPageup'+this._sParentId,'delbd');
Element.removeClassName('navPagedown'+this._sParentId,'delbd');
if(i%NECtrl.Portrait._navRow==0)
Element.addClassName('navPageup'+this._sParentId,'delbd');
else if((i+1)%NECtrl.Portrait._navRow==0)
Element.addClassName('navPagedown'+this._sParentId,'delbd');
}else{
_oNav.className="navitem";
_oNav.innerHTML='<a  href="#" onclick="'+this._sObjectName+'.go(\''+_type+'\'); return false;">'+NECtrl.Portrait._allCat[_type].name+(NECtrl.Portrait._allCat[_type].newly?'<span>��</span>':'')+'</a>';
}
}
if(this._oOptions.fnSetPref){
this._oOptions.fnSetPref(this._current.type);
}
},
_change:function(sType){
if(this._oOptions.bNav==true){
this._changeTag(sType);
}
this._fillPic(sType);
this._getPage(sType);
},
_getPage:function(sType){
var _oPage=$("portraitPage"+this._sParentId);
var obj=this._getTypeObj(sType);
_oPage.innerHTML=((this._current.page!=0)?'<a href="#" id="portraitPrePage'+this._sParentId+'" class="mf_link" onclick="'+this._sObjectName+'.portraitPrePage();return false;">��һҳ</a>':'<span style="color:#777777">��һҳ</span>')+
'&nbsp;<span style="color:#777777;">|</span>&nbsp;'+
((this._current.page!=obj.pageCount)?'<a href="#" class="mf_link" onclick="'+this._sObjectName+'.portraitNextPage();return false;">��һҳ</a>':'<span style="color:#777777">��һҳ</span>');
},
_fillPic:function(sType){
var _iCount=this._getCurrentPageCount(sType,this._current.page);
var row,col,borderLen;
if(NECtrl.Portrait._allCat[sType].grid==1){
row=NECtrl.Portrait._row;
col=NECtrl.Portrait._col;
borderLen=29;
}else{
row=NECtrl.Portrait._row/2;
col=NECtrl.Portrait._col/2;
borderLen=59;
}
var _iCountStart=this._current.page*row*col;
var _oContent=$("portraitContent"+this._sParentId);
var n=0;
for(var i=_oContent.rows.length-1;i>-1;i--){
_oContent.deleteRow(i);
}
for(var i=0;i<row;i++){
if(n==_iCount)break;
var tr=_oContent.insertRow(-1);
for(var j=0;j<col;j++){
if(n==_iCount){
if(_iCount<col){
for(var k=0;k<(col-_iCount);k++){
var emptyTd=tr.insertCell(-1);
emptyTd.cssText="height:"+borderLen+"px; width:"+borderLen+"px;";
}
}
break;
}
var _oTd=tr.insertCell(-1);
_oTd.style.cssText="height:"+borderLen+"px; width:"+borderLen+"px; text-align:center;";
_oTd.innerHTML='<div style=" width:'+(borderLen-2)+'px; height:'+(borderLen-2)+'px;text-align:center;" onmouseover="'+this._sObjectName+'.portraitMouseOvr(this,'+n+','+NECtrl.Portrait._allCat[sType].grid+')" onmouseout="'+this._sObjectName+'.portraitMouseOut(this)"><a href="#"><img src="http://b.bst.126.net/style/common/empty.gif" source="'+NECtrl.Portrait._filePath+sType+"/"+sType+(_iCountStart+n)+'.gif" width="'+(borderLen-4)+'" height="'+(borderLen-4)+'" title="'+NECtrl.Portrait._tips[sType][_iCountStart+n]+'" border="0" onclick="'+this._sObjectName+'.portraitClick(this);return false;"></a></div>';
n++;
}
}
_oContent.className=sType+'0';
},
_getCurrentPageCount:function(sType,iPage){
var size=NECtrl.Portrait._allCat[sType].size;
var pageCount=NECtrl.Portrait._allCat[sType].pageCount;
var row,col;
if(NECtrl.Portrait._allCat[sType].grid==1){
row=NECtrl.Portrait._row;
col=NECtrl.Portrait._col;
}else{
row=NECtrl.Portrait._row/2;
col=NECtrl.Portrait._col/2;
}
if(iPage==pageCount){
if(size%(row*col)==0)
return(row*col);
else
return size%(row*col);
}else{
return row*col;
}
},
_getTypeObj:function(sType){
return NECtrl.Portrait._allCat[sType];
}
}
NECtrl.Portrait._sPorJst=new String('\
 {if isNav == true}\
  <table style="width:374px;height:220px" border="0" cellpadding="0" cellspacing="0">\
 {else}\
  <table style="width:317px;height:220px" border="0" cellpadding="0" cellspacing="0">\
 {/if}\
 <tr>\
 <td valign="top" bgcolor="#e5e5e1" id="magicface${editorId}" style="width:308px;height:200px;border:1px solid #aaaaaa; border-right:none; padding:3px;">\
  <div style="height:182px;">\
   <table style="width:308px" border="0" cellspacing="1" cellpadding="0" id="portraitContent${editorId}"></table>\
  </div>\
  <div id="portraitPage${editorId}" class="mf_page"></div>\
 </td>\
 {if isNav == true}\
  <td style="width:64px" valign="top">\
  <div id="portraitNav${editorId}" class="portraitNav">\
  <a href="#" id="navPageup${editorId}" class="pgup" onclick="${objName}.clickNavPageup();return false;"><div class="pgupline"><div class="n_ f26">&nbsp;</div></div></a>\
  <div class="navs_con"><div id="navs${editorId}" class="navs" style="top:0px;"></div></div>\
  <a href="#" id="navPagedown${editorId}" class="pgdown" onclick="${objName}.clickNavPagedown();return false;"><div class="pgdownline"><div class="n_ f27">&nbsp;</div></div></a>\
  </div>\
  </td>\
 {else}\
  <td class="mf_leftBorder" style="height:200px;width:2px">&nbsp;</td>\
 {/if}\
 </tr>\
 </table>\
 <div id="portraitPreview${editorId}" style="position:absolute;z-index:200000;display:none"></div>');
var jst_global_simple_editor=new String('\
<div id="editorWrap${editorId}" class="edt_relt">\
 <input type="hidden" name="HEContent" id="HEContent${editorId}">\
 <div class="edt_relt">\
  <table border="0" class="nEdt ccEdt"><tr>\
      <td class="td0">&nbsp;</td>\
      <td class="td2"><div id="BoldBtn_s${editorId}" class="com" title="�Ӵ�"><div class="av_ bld i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
      <td class="td2"><div id="ItalicBtn_s${editorId}" class="com" title="б��"><div class="av_ Ita i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
      <td class="td2"><div id="UnderlineBtn_s${editorId}" class="com" title="�»���"><div class="av_ udl i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
   <td class="td2"><div id="PortraitBtn_s${editorId}" class="com" title="ħ������"><div class="av_ fac i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
   <td>&nbsp;</td>\
  </tr></table>\
 </div>\
 <div id="designEditorDiv${editorId}"></div>\
</div>\
');
var jst_global_simple_notoolbar_editor=new String('\
<div id="editorWrap${editorId}" class="edt_relt">\
 <input type="hidden" name="HEContent" id="HEContent${editorId}">\
 <div class="edt_relt" style="display:none">\
  <table border="0" class="nEdt ccEdt"><tr>\
      <td class="td0" style="width:2px;">&nbsp;</td>\
   <td class="td2"><div id="PortraitBtn_s${editorId}" class="com" title="ħ������"><div class="av_ fac i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
   <td>&nbsp;</td>\
  </tr></table>\
 </div>\
 <div id="designEditorDiv${editorId}"></div>\
</div>\
');
var jst_global_advanced_editor=new String('\
<div id="editorWrap${editorId}" class="edt_relt">\
 <input type="hidden" name="HEContent" id="HEContent${editorId}">\
    <div id="toolbar${editorId}" >\
  <div id="small_toolbar${editorId}" class="edt_relt" style="display:none;"></div>\
  <div id="big_toolbar${editorId}" class="edt_relt" style="display:none;zoom:1"></div>\
    </div>\
 <!--�����Ǳ༭��-->\
 <div class="EdtPaper" id="editorDiv${editorId}" style="display:block">\
  <div class="pp shw">\
   <div class="t"></div>\
   <div class="wp">\
    <div class="uRule"><input id="title${editorId}" name="title" type="text" class="tt" maxlength="255" AUTOCOMPLETE="off"></div>\
    <div class="content" id="designEditorDiv${editorId}"></div>\
    <div class="bRule"></div>\
   </div>\
   <div class="b"></div>\
  </div>\
 </div>\
 <div id="sourceDiv${editorId}" style="display:none" class="sourEdt">\
  <textarea id="sourceEditor${editorId}" class="content" style="height:${height}px;"></textarea>\
 </div>\
</div>\
');
var jst_global_advanced_editor_smallToolbar=new String('\
<table border="0" class="nEdt ccEdt smlEdt"><tr>\
    <td class="td0">&nbsp;</td>\
 <td class="td2"><div id="BoldBtn_s${editorId}" class="com" title="�Ӵ�"><div class="av_ bld i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="ItalicBtn_s${editorId}" class="com" title="б��"><div class="av_ Ita i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="UnderlineBtn_s${editorId}" class="com" title="�»���"><div class="av_ udl i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td5 zhgh"><div class="edt_relt">\
     <div id="FontSizeBtn_s${editorId}" class="com"><div id="FontSizeValue_s${editorId}" class="txt">�ֺ�</div><div class="av_ arw l">&nbsp;</div></div>\
     <div id="FontSizeDiv_s${editorId}" class="ftsz" style="display:none;">\
   <a onclick="${objName}.setFontSize(2);return false;" href="#" class="n" style="font-size:x-small;">С</a>\
   <a onclick="${objName}.setFontSize(3);return false;" href="#" class="n" style="font-size:small;">��׼</a>\
   <a onclick="${objName}.setFontSize(4);return false;" href="#" class="n" style="font-size:medium;">��</a>\
   <a onclick="${objName}.setFontSize(5);return false;" href="#" class="n" style="font-size:large;">�ش�</a>\
   <a onclick="${objName}.setFontSize(6);return false;" href="#" class="n" style="font-size:x-large;">����</a>\
  </div>\
    </div></td>\
    <td class="td0">&nbsp;</div>\
    <td class="td2"><div class="edt_relt">\
     <div id="ForeColorBtn_s${editorId}" class="com" title="������ɫ"><div class="av_ fco i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div>\
  <div id="ForeColorDiv_s${editorId}" style="display:none;position:absolute;z-index:100000;background:#FFF;"></div>\
 </div></td>\
 <td class="td3" ><div class="av_ ssp i"><img  src="http://b.bst.126.net/style/common/empty.gif"/></div></td>\
 <td class="td2"><div id="LinkBtn_s${editorId}" class="com" title="������"><div class="av_ lnk i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
 <td class="td2"><div class="edt_relt">\
     <div id="PortraitBtn_s${editorId}" class="com" title="ħ������"><div class="av_ fac i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div>\
  <div id="PortraitDiv_s${editorId}"  class="edt_mgcf" style="display:none;"></div>\
 </div></td>\
 <td class="td2"><div id="ImageBtn_s${editorId}" class="com" title="����ͼƬ" onclick="${objName}.addImg()"><div class="av_ sIm i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
 <td class="td6"><div class="menu">\
  <span id="func_s${editorId}"><a onclick="${objName}.switchToolbar();return false;" href="#">ȫ������</a>&nbsp;&nbsp;|&nbsp;&nbsp;</span><span><a onclick="${objName}.goPreview();return false;" href="#">Ԥ��</a></span>\
 </div></td>\
</tr></table>\
<div class="disbBar disbSml" id="toolbarCover_s${editorId}" style="display:none;"></div>\
');
var jst_global_advanced_editor_bigToolbar=new String('\
<table border="0" class="nEdt">\
  <tr class="top">\
    <td rowspan="2" class="td0">&nbsp;</td>\
    <td rowspan="2" class="td1"><div id="PasteBtn${editorId}" class="com" title="ճ��"><div class="av_ pst i"><img class="bpic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="CutBtn${editorId}" class="com" title="����"><div class="av_ cut i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td rowspan="2" class="td3"><div class="av_ spl i"><img src="http://b.bst.126.net/style/common/empty.gif"/></div></td>\
    <td colspan="3" class="td4 zhgh"><div class="edt_relt">\
     <div class="com" id="FontNameBtn${editorId}"><div id="FontNameValue${editorId}" class="txt">����</div><div class="av_ arw l">&nbsp;</div></div>\
     <div id="FontNameDiv${editorId}" class="ftna" style="display:none;">\
   <a onclick="${objName}.setFontName(\'����\');return false;" href="#" class="n" style="font-family: \'����\';">����</a>\
   <a onclick="${objName}.setFontName(\'����\');return false;" href="#" class="n" style="font-family: \'����\';">����</a>\
   <a onclick="${objName}.setFontName(\'����_GB2312\');return false;" href="#" class="n" style="font-family: \'����_GB2312\';">����</a>\
   <a onclick="${objName}.setFontName(\'����\');return false;" href="#" class="n" style="font-family: \'����\';">����</a>\
   <a onclick="${objName}.setFontName(\'��Բ\');return false;" href="#" class="n" style="font-family: \'��Բ\';">��Բ</a>\
   <a onclick="${objName}.setFontName(\'Arial\');return false;" href="#" class="n" style="font-family: \'Arial\';">Arial</a>\
   <a onclick="${objName}.setFontName(\'Arial Narrow\');return false;" href="#" class="n" style="font-family: \'Arial Narrow\';">Arial Narrow</a>\
   <a onclick="${objName}.setFontName(\'Arial Black\');return false;" href="#" class="n" style="font-family:\'Arial Black\';">Arial Black</a>\
   <a onclick="${objName}.setFontName(\'Comic Sans MS\');return false;" href="#" class="n" style="font-family: \'Comic Sans MS\';">Comic Sans MS</a>\
   <a onclick="${objName}.setFontName(\'Courier\');return false;" href="#" class="n" style="font-family: \'Courier\';">Courier</a>\
   <a onclick="${objName}.setFontName(\'System\');return false;" href="#" class="n" style="font-family: \'System\';">System</a>\
   <a onclick="${objName}.setFontName(\'Verdana\');return false;" href="#" class="n" style="font-family: \'Verdana\';">Verdana</a>\
  </div>\
    </div></td>\
    <td colspan="2" class="td5 zhgh"><div class="edt_relt">\
     <div id="FontSizeBtn${editorId}" class="com"><div id="FontSizeValue${editorId}" class="txt">�ֺ�</div><div class="av_ arw l">&nbsp;</div></div>\
     <div id="FontSizeDiv${editorId}" class="ftsz" style="display:none;">\
   <a onclick="${objName}.setFontSize(2);return false;" href="#" class="n" style="font-size:x-small;">С</a>\
   <a onclick="${objName}.setFontSize(3);return false;" href="#" class="n" style="font-size:small;">��׼</a>\
   <a onclick="${objName}.setFontSize(4);return false;" href="#" class="n" style="font-size:medium;">��</a>\
   <a onclick="${objName}.setFontSize(5);return false;" href="#" class="n" style="font-size:large;">�ش�</a>\
   <a onclick="${objName}.setFontSize(6);return false;" href="#" class="n" style="font-size:x-large;">����</a>\
  </div>\
    </div></td>\
    <td rowspan="2" class="td3"><div class="av_ spl i"><img src="http://b.bst.126.net/style/common/empty.gif"/></div></td>\
    <td class="td2"><div id="InsertOrderedListBtn${editorId}" class="com" title="�����б�"><div class="av_ olt i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="InsertUnorderedListBtn${editorId}" class="com" title="�����б�"><div class="av_ ult i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="IndentBtn${editorId}" class="com" title="��������"><div class="av_ idt i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="OutdentBtn${editorId}" class="com" title="��������"><div class="av_ odt i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td rowspan="2" class="td3"><div class="av_ spl i"><img  src="http://b.bst.126.net/style/common/empty.gif"/></div></td>\
    <td rowspan="2" class="td1"><div id="ImageBtn${editorId}" class="com" title="����ͼƬ" onclick="${objName}.addImg()"><div class="av_ ima i"><img class="bpic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="TableBtn${editorId}" class="com" title="���ӱ���"><div class="av_ tbl i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="LineBtn${editorId}" class="com" title="�ָ���"><div class="av_ lne i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="ClearFormatBtn${editorId}" class="com" title="�����ʽ"><div class="av_ fmt i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td rowspan="2" class="td3"><div class="av_ spl i"><img  src="http://b.bst.126.net/style/common/empty.gif"/></div></td>\
    <td>&nbsp;</td>\
    <td class="td6"><div class="menu">\
     <span id="func${editorId}"><a onclick="${objName}.switchToolbar();return false;" href="#">�򵥹���</a>&nbsp;&nbsp;|&nbsp;&nbsp;</span><span><a onclick="${objName}.goPreview();return false;" href="#">Ԥ��</a></span>\
    </div></td>\
  </tr>\
  <tr class="bottom">\
    <td class="td2"><div id="CopyBtn${editorId}" class="com" title="����"><div class="av_ cpy i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="BoldBtn${editorId}" class="com" title="�Ӵ�"><div class="av_ bld i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="ItalicBtn${editorId}" class="com" title="б��"><div class="av_ Ita i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="UnderlineBtn${editorId}" class="com" title="�»���"><div class="av_ udl i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div class="edt_relt">\
     <div id="ForeColorBtn${editorId}" class="com" title="������ɫ"><div class="av_ fco i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div>\
  <div id="ForeColorDiv${editorId}" style="display:none;position:absolute;z-index:100000;background:#FFF;"></div>\
 </div></td>\
    <td class="td2"><div class="edt_relt">\
     <div id="BackColorBtn${editorId}" class="com" title="������ɫ"><div class="av_ bco i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div>\
  <div id="BackColorDiv${editorId}"  style="display:none;position:absolute;z-index:100000;background:#FFF"></div>\
 </div></td>\
    <td class="td2"><div id="JustifyLeftBtn${editorId}" class="com" title="�����"><div class="av_ jtl i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="JustifyCenterBtn${editorId}" class="com" title="���ж���"><div class="av_ jtc i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="JustifyRightBtn${editorId}" class="com" title="�Ҷ���"><div class="av_ jtr i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="ParagraphBtn${editorId}" class="com" title="���仯"><div class="av_ pra i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="LinkBtn${editorId}" class="com" title="������"><div class="av_ lnk i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div class="edt_relt">\
     <div id="PortraitBtn${editorId}" class="com" title="ħ������"><div class="av_ fac i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div>\
  <div id="PortraitDiv${editorId}" class="edt_mgcf" style="display:none;"></div>\
 </div></td>\
    <td class="td2"><div id="MediaBtn${editorId}" class="com" title="�����ý��"><div class="av_ mdi i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td class="td2"><div id="ShowCodeBtn${editorId}" class="com" title="��ʾHTML����"><div class="av_ prv i"><img class="pic" src="http://b.bst.126.net/style/common/empty.gif"/></div></div></td>\
    <td>&nbsp;</td>\
  </tr>\
</table>\
<div class="disbBar" id="toolbarCover${editorId}" style="display:none;"></div>\
');
