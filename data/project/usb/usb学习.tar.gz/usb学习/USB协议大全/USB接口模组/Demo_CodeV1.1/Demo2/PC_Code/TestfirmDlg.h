// TestfirmDlg.h : header file
//
//#include "Wave1.h"
#if !defined(AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_)
#define AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_

#if _MSC_VER > 1000


//static char* UsbName = "\\\\.\\D12TestDevice0";
static char* UsbName = "\\\\.\\AbinDsDevice0";
//char Dsacm_Path[256];


#define NUM 64
//BYTE ByteCom[NUM];
//BYTE* UpLoad_Data_Buffer;
#include "stdafx.h"


#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg dialog

class CTestfirmDlg : public CDialog
{
// Construction
public:

public:
	CTestfirmDlg(CWnd* pParent = NULL);	// standard constructor
	void CloseIfOpen(void);
	BOOL FunUpLoad(void);
	void FunDownLoad(void);
	void Initialize(void);
	void WriteDataToFile(CHAR *filename);
	BOOL ReadDataFromFile(CHAR *filename);

	//////
	void ReadSingleDirectory(const char *szPath,HTREEITEM previous);
	void ReadSingleFile(const char *szPath, HTREEITEM previous);
	/////

//	HANDLE OpenByName(void);
	HANDLE hDeviceRD2;  
	HANDLE hDeviceWR2;  
	//BYTE ByteData[NUM];
    char * UpLoad_Data_Buffer;
    // CString m_FilePath;

	unsigned long m_DownLoadFileLen;
//    char  DownLoad_Data_Buffer[1024];
	char * DownLoad_Data_Buffer;
	char * BinFileName;
// Dialog Data
	//{{AFX_DATA(CTestfirmDlg)
	enum { IDD = IDD_TESTFIRM_DIALOG };
	CEdit	m_Up_Download_FileName;
	CTreeCtrl	m_PCFileTree;
	int		m_Seg_Edit;
	int		m_Com_Edit;
	int		m_TestCom_Edit;
	int		m_ComLow_Edit;
	int		m_ComHigh_Edit;
	int		m_SegHigh_Edit;
	int		m_SegLow_Edit;
	CString	m_BinFile_Path;
	CString	m_Wave_File_Direction;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestfirmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
    int ID0,ID1,ID2,ID3;
	unsigned long nRet;
	unsigned long Len;

private:
	CImageList m_ImageList;
	CImageList m_ImageList1;
	//BYTE Data_Dvr[64*1024];
	//char Data_Dvr[64*1024];

	//  Set DownLoad file Var
	//unsigned long m_DownLoadFileLen;
    //char * DownLoad_Data_Buffer;


	// Generated message map functions
	//{{AFX_MSG(CTestfirmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnOpenusbButton();
	afx_msg void OnCloseusbButton();
	afx_msg void OnConnecttestButton();
//	afx_msg void OnRecordButton();
//	afx_msg void OnStopButton();
//	afx_msg void OnPlayButton();
	afx_msg void OnDownloadButton();
	afx_msg void OnUploadButton();
	afx_msg void OnItemexpandingPcfiletree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedPcfiletree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBinToWaveButton();
	afx_msg void OnPlayWaveButton();
	afx_msg void OnBinFileDirectionButton();
	afx_msg void OnWaveFileDirectionButton();
	afx_msg void OnWaveFilePathButton();
	afx_msg void OnStopWaveButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_)
