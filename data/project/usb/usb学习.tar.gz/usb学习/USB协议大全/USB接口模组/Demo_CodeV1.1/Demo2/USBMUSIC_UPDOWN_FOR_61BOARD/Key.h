#ifndef	__KEY_h__
#define	__KEY_h__
//	write your header here

void Key_Init(void);
void Key_Scan(void);
unsigned Key_Get(void);

#define KEY_1		0x01
#define KEY_2		0x02
#define KEY_3		0x04

#endif
