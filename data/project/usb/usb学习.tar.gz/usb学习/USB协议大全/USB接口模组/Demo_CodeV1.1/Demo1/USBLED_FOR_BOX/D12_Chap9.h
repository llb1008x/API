#ifndef	__CHAP9_h__
#define	__CHAP9_h__
//	write your header here

#define MSB(x)	(((x) >> 16) & 0xFFFF)

typedef unsigned int UINT;
typedef unsigned long int ULINt;

typedef union _epp_flags
{
	struct _flags
	{
		unsigned int bus_reset				: 1;
		unsigned int suspend				: 1;
		unsigned int setup_packet			: 1;
		unsigned int remote_wakeup			: 1;
		unsigned int in_isr					: 1;
		unsigned int control_state			: 2;
		unsigned int configuration			: 1;
		unsigned int Ep1_ReceiveDataFlag	: 1;
		unsigned int Ep1_SendDataFlag		: 1;
		unsigned int Ep2_ReceiveDataFlag	: 1;
		unsigned int Ep2_SendDataFlag		: 1;
	}bits;
}EPPFLAGS;

typedef struct _device_request
{
	unsigned int bmRequestType;
	unsigned int bRequest;
	unsigned long int wValue;
	unsigned long int wIndex;
	unsigned long int wLength;
}DEVICE_REQUEST;

#define MAX_CONTROLDATA_SIZE	8
typedef struct _control_transfers
{
	DEVICE_REQUEST DeviceRequest;
	unsigned long int wLength;
	unsigned long int wCount;
	unsigned int * pData;
	unsigned int dataBuffer[MAX_CONTROLDATA_SIZE];
}CONTROL_TRANSFERS;

extern EPPFLAGS bEPPflags;
extern CONTROL_TRANSFERS ControlData;

void D12_Reserved(void);
void D12_Get_Status(void);
void D12_Clear_Feature(void);
void D12_Set_Feature(void);
void D12_Set_Address(void);
void D12_Get_Descriptor(void);
void D12_Get_Configuration(void);
void D12_Set_Configuration(void);
void D12_Get_Interface(void);
void D12_Set_Interface(void);

void D12_Stall_Ep0(void);
void D12_Single_Transmit(unsigned int * buf, unsigned int len);
void D12_Code_Transmit(unsigned int * pRomData, unsigned long int len);
void D12_Init_Unconfig(void);
void D12_Init_Config(void);

#define D12_STALL				0x02

#define USB_RECIPIENT				(unsigned char)0x1F
#define USB_RECIPIENT_DEVICE		(unsigned char)0x00
#define USB_RECIPIENT_INTERFACE		(unsigned char)0x01
#define USB_RECIPIENT_ENDPOINT		(unsigned char)0x02

#define MAX_ENDPOINTS				(unsigned int)0x3
#define EP0_PACKET_SIZE				(unsigned long int)0x0010
#define EP1_PACKET_SIZE				(unsigned long int)0x0004
#define EP2_PACKET_SIZE				(unsigned long int)0x0040

#define USB_IDLE					0
#define USB_TRANSMIT				1
#define USB_RECEIVE					2

#define USB_REQUEST_TYPE_MASK		(unsigned int)0x60
#define USB_STANDARD_REQUEST		(unsigned int)0x00
#define USB_VENDOR_REQUEST			(unsigned int)0x40
#define USB_REQUEST_MASK			(unsigned int)0x0F
#define DEVICE_ADDRESS_MASK			(unsigned int)0x7F

#define USB_DEVICE_DESCRIPTOR_TYPE				0x01
#define USB_CONFIGURATION_DESCRIPTOR_TYPE		0x02
#define USB_STRING_DESCRIPTOR_TYPE				0x03
#define USB_INTERFACE_DESCRIPTOR_TYPE			0x04
#define USB_ENDPOINT_DESCRIPTOR_TYPE			0x05
#define USB_POWER_DESCRIPTOR_TYPE				0x06

#define USB_ENDPOINT_TYPE_MASK					0x03
#define USB_ENDPOINT_TYPE_CONTROL				0x00
#define USB_ENDPOINT_TYPE_ISOCHRONOUS			0x01
#define USB_ENDPOINT_TYPE_BULK					0x02
#define USB_ENDPOINT_TYPE_INTERRUPT				0x03
#define USB_ENDPOINT_DIRECTION_MASK				0x80

#define USB_FEATURE_ENDPOINT_STALL				0x0000
#define USB_FEATURE_REMOTE_WAKEUP				0x0001

#endif