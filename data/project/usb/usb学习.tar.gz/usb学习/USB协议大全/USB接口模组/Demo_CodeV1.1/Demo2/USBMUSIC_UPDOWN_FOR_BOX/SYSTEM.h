#ifndef	__SYSTEM_h__
#define	__SYSTEM_h__
//	write your header here
#define ID0		1			// 00000001B
#define ID1		2			// 00000010B
#define ID2		3			// 00000011B
#define ID3		4
#define ID4		5
#define ID5		6

#define KEY_NO		0x00
#define KEY_REC		0x01
#define KEY_STOP	0x02
#define KEY_PLAY	0x04

#define START_ADDR	0x00001000		// ����¼����ʼ��ַ
#define END_ADDR	0x00010000		// ����¼��������ַ
#define PAGE_SIZE	0x800

#define STOP		0
#define RECORD		1
#define PLAY		2

#define FULL		1
#define EMPTY		2

extern unsigned int uiKey;
extern unsigned int uiStatus;
extern unsigned int MainEpBuf[64];
extern unsigned long int SpeechFileLength;
extern unsigned long int Addr_UpLoad;
extern unsigned int G_UpLoad_Flag;
extern unsigned long Leave_Len;
extern unsigned int G_UpLoad_Flag;

extern void Dvr(void);
extern void UpLoad(void);
extern void DownLoad(void);

#endif
