#ifndef	__DESCRIPTOR_h__
#define	__DESCRIPTOR_h__
//	write your header here

typedef struct _USB_DEVICE_DESCRIPTOR
{
	UINT bLength;
	UINT bDescriptorType;
	ULINt bcdUSB;
	UINT bDeviceClass;
	UINT bDeviceSubClass;
	UINT bDeviceProtocol;
	UINT bMaxPacketSize0;
	ULINt idVendor;
	ULINt idProduct;
	ULINt bcdDevice;
	UINT iManufacturer;
	UINT iProduct;
	UINT iSerialNumber;
	UINT bNumConfigurations;
}USB_DEVICE_DESCRIPTOR;

typedef struct _USB_ENDPOINT_DESCRIPTOR
{
	UINT bLength;
	UINT bDescriptorType;
	UINT bEndpointAddress;
	UINT bmAttributes;
	ULINt wMaxPacketSize;
	UINT bInterval;
}USB_ENDPOINT_DESCRIPTOR, *PUSB_ENDPOINT_DESCRIPTOR;

typedef struct _USB_CONFIGURATION_DESCRIPTOR
{
	UINT bLength;
	UINT bDescriptorType;
	ULINt wTotalLength;
	UINT bNumInterfaces;
	UINT bConfigurationValue;
	UINT iConfiguration;
	UINT bmAttributes;
	UINT MaxPower;
}USB_CONFIGURATION_DESCRIPTOR, *PUSB_CONFIGURATION_DESCRIPTOR;

typedef struct _USB_INTERFACE_DESCRIPTOR
{
	UINT bLength;
	UINT bDescriptorType;
	UINT bInterfaceNumber;
	UINT bAlternateSetting;
	UINT bNumEndpoints;
	UINT bInterfaceClass;
	UINT bInterfaceSubClass;
	UINT bInterfaceProtocol;
	UINT iInterface;
}USB_INTERFACE_DESCRIPTOR, *PUSB_INTERFACE_DESCRIPTOR;


#define NUM_ENDPOINTS	4
#define CONFIG_DESCRIPTOR_LENGTH	\
		(unsigned long int)(sizeof(USB_CONFIGURATION_DESCRIPTOR)\
		+ sizeof(USB_INTERFACE_DESCRIPTOR)\
		+ (NUM_ENDPOINTS * sizeof(USB_ENDPOINT_DESCRIPTOR)))

#define USB_CLASS_CODE_TEST_CLASS_DEVICE			0xdc
#define USB_SUBCLASS_CODE_TEST_CLASS_D12			0xA0
#define USB_PROTOCOL_CODE_TEST_CLASS_D12			0xB0

extern const USB_DEVICE_DESCRIPTOR DeviceDescr;
extern const USB_CONFIGURATION_DESCRIPTOR ConfigDescr;
extern const USB_INTERFACE_DESCRIPTOR InterfaceDescr;
extern const USB_ENDPOINT_DESCRIPTOR EP1_TXDescr;
extern const USB_ENDPOINT_DESCRIPTOR EP1_RXDescr;
extern const USB_ENDPOINT_DESCRIPTOR EP2_TXDescr;
extern const USB_ENDPOINT_DESCRIPTOR EP2_RXDescr;

#endif
