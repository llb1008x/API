/*
   //*************************************************************************
   //
   //                  P H I L I P S   P R O P R I E T A R Y
   //
   //           COPYRIGHT (c)   1998 BY PHILIPS SINGAPORE.
   //                     --  ALL RIGHTS RESERVED  --
   //
   // File Name:	Device.CPP
   // Author:		Wenkai Du
   // Created:		14 Jun 98
   // Modified:
   // Revision:		1.0
   //
   //*************************************************************************
   //
   //*************************************************************************
   */

#include "stdafx.h"



#include "devioctl.h"
#include <setupapi.h>//
#include <basetyps.h>//��DEFINE_GUID�йأ�vc��ͷ�ļ�
#include "usbdi.h"//��PUSB_DEVICE_DESCRIPTOR�йأ���USB�豸�Ľӿ�

#include "GUID829.h"
//  ��GUID829.h��DEFINE_GUID(GUID_CLASS_D12_BULK, 
//0x77f49320, 0x16ef, 0x11d2, 0xad, 0x51, 0x0, 0x60, 0x97, 0xb5, 0x14, 0xdd);
char completeDeviceName[256] = "";  //generated from the GUID registered by the driver itself 


//hOut = OpenOneDevice (hardwareDeviceInfo, &deviceInfoData, outNameBuf);
HANDLE
OpenOneDevice (
    IN       HDEVINFO                    HardwareDeviceInfo,
    IN       PSP_INTERFACE_DEVICE_DATA   DeviceInfoData,
	IN		 char *devName
    )
/*++
Routine Description:

    Given the HardwareDeviceInfo, representing a handle to the plug and
    play information, and deviceInfoData, representing a specific usb device,
    open that device and fill in all the relevant information in the given
    USB_DEVICE_DESCRIPTOR structure.

Arguments:

    HardwareDeviceInfo:  handle to info obtained from Pnp mgr via SetupDiGetClassDevs()
    DeviceInfoData:      ptr to info obtained via SetupDiEnumInterfaceDevice()

Return Value:

    return HANDLE if the open and initialization was successfull,
	else INVLAID_HANDLE_VALUE.

--*/
{
    PSP_INTERFACE_DEVICE_DETAIL_DATA     functionClassDeviceData = NULL;
    ULONG                                predictedLength = 0;
    ULONG                                requiredLength = 0;
	HANDLE								 hOut = INVALID_HANDLE_VALUE;

    //
    // allocate a function class device data structure to receive the
    // goods about this particular device.
    //
    SetupDiGetInterfaceDeviceDetail (
            HardwareDeviceInfo,
            DeviceInfoData,
            NULL, // probing so no output buffer yet
            0, // probing so output buffer length of zero
            &requiredLength,
            NULL); // not interested in the specific dev-node


    predictedLength = requiredLength;
    // sizeof (SP_FNCLASS_DEVICE_DATA) + 512;

    functionClassDeviceData = (PSP_INTERFACE_DEVICE_DETAIL_DATA)malloc (predictedLength);
    functionClassDeviceData->cbSize = sizeof (SP_INTERFACE_DEVICE_DETAIL_DATA);

    //
    // Retrieve the information from Plug and Play.
    //
    if (! SetupDiGetInterfaceDeviceDetail (
               HardwareDeviceInfo,
               DeviceInfoData,
               functionClassDeviceData,//ָ��һ��������,���ڽ���ָ���ӿڵ���Ϣ
               predictedLength,
               &requiredLength,
               NULL)) {
        return INVALID_HANDLE_VALUE;
    }

	strcpy( devName,functionClassDeviceData->DevicePath) ;

    hOut = CreateFile (
                  functionClassDeviceData->DevicePath,
                  GENERIC_READ | GENERIC_WRITE,
                  FILE_SHARE_READ | FILE_SHARE_WRITE,
                  NULL, // no SECURITY_ATTRIBUTES structure
                  OPEN_EXISTING, // No special create flags
                  0, // No special attributes
                  NULL); // No template file

    if (INVALID_HANDLE_VALUE == hOut) {
    }

	free(functionClassDeviceData);

	return hOut;
}


HANDLE
//OpenUsbDevice( (LPGUID)&GUID_CLASS_D12_BULK, completeDeviceName)
OpenUsbDevice( LPGUID  pGuid, char *outNameBuf)
/*++
Routine Description:

   Do the required PnP things in order to find 
   the next available proper device in the system at this time.

Arguments:

    pGuid:      ptr to GUID registered by the driver itself
    outNameBuf: the generated name for this device

Return Value:

    return HANDLE if the open and initialization was successful,
	else INVLAID_HANDLE_VALUE.
--*/
{
   ULONG NumberDevices;
   HANDLE hOut = INVALID_HANDLE_VALUE;
   HDEVINFO                 hardwareDeviceInfo;
   SP_INTERFACE_DEVICE_DATA deviceInfoData;
   ULONG                    i;
   BOOLEAN                  done;
   PUSB_DEVICE_DESCRIPTOR   usbDeviceInst;
   PUSB_DEVICE_DESCRIPTOR	*UsbDevices = &usbDeviceInst;

   *UsbDevices = NULL;//
   NumberDevices = 0;

   //
   // Open a handle to the plug and play dev node.
   // SetupDiGetClassDevs() returns a device information set that contains info on all 
   // installed devices of a specified class.
   //�ú���������ȡ�豸����Ϣ��,����������ָ������ƥ��������Ѿ���װ���豸��
  //����ú�������ʧ�ܣ��򷵻�INVALID_HANDLE_VALUE.
   hardwareDeviceInfo = SetupDiGetClassDevs (
                           pGuid,
                           NULL, // Define no enumerator (global)
                           NULL, // Define no
                           (DIGCF_PRESENT | // Only Devices present
                          // DIGCF_INTERFACEDEVICE)); // Function class devices.
                            DIGCF_DEVICEINTERFACE));
   //
   // Take a wild guess at the number of devices we have;
   // Be prepared to realloc and retry if there are more than we guessed
   //
   NumberDevices = 4;//
   done = FALSE;
   //�ڵ��ú���SetupDiEnumDeviceInterfaces()ǰ������cbsize��ֵ
   deviceInfoData.cbSize = sizeof (SP_INTERFACE_DEVICE_DATA);

   i=0;
   while (!done) 
   {
      NumberDevices *= 2;  //

      if (*UsbDevices)
	  {
         *UsbDevices =
               (PUSB_DEVICE_DESCRIPTOR)realloc (*UsbDevices, (NumberDevices * sizeof (USB_DEVICE_DESCRIPTOR)));
      } 
	  else 
	  {
         *UsbDevices = (PUSB_DEVICE_DESCRIPTOR)calloc (NumberDevices, sizeof (USB_DEVICE_DESCRIPTOR));
		 //The calloc function allocates storage space for an array of num elements, each of length size bytes. Each element is initialized to 0.


      }

      if (NULL == *UsbDevices)
	  {

         // SetupDiDestroyDeviceInfoList destroys a device information set 
         // and frees all associated memory.

         SetupDiDestroyDeviceInfoList (hardwareDeviceInfo);
         return INVALID_HANDLE_VALUE;
      }
//	     PUSB_DEVICE_DESCRIPTOR   usbDeviceInst;
//   PUSB_DEVICE_DESCRIPTOR	*UsbDevices = &usbDeviceInst;
      usbDeviceInst = *UsbDevices + i;//

      for (; i < NumberDevices; i++)  // NumberDevices = 4;
	  {

         // SetupDiEnumDeviceInterfaces() returns information about device interfaces 
         // exposed by one or more devices. Each call returns information about one interface;
         // the routine can be called repeatedly to get information about several interfaces
         // exposed by one or more devices.
         //���������豸��Ϣ����һ���豸�ӿ�Ԫ�صĻ����ṹ��ÿ�ε��øú�������һ���豸�ӿڵ���Ϣ��
		  //�����ظ����ô˺�����ֱ����ȡ���豸��Ϣ�������е��豸�Ľӿ���Ϣ��
         if (SetupDiEnumDeviceInterfaces (hardwareDeviceInfo,
                                         0, // We don't care about specific PDOs
										 pGuid,//��ʶ��������ӿڵ��豸�ӿ���
                                         i,
                                         &deviceInfoData)) //ָ��һ����������ó���Ļ�����
		 {

            hOut = OpenOneDevice (hardwareDeviceInfo, &deviceInfoData, outNameBuf);
			if ( hOut != INVALID_HANDLE_VALUE )
			{
				//��ʧ��,���˳�whileѭ��.
               done = TRUE;
               break;
			}
         } 
		 else 
		 {
			 //ʵ�ʵĽӿ�����NumberDevices��.
            if (ERROR_NO_MORE_ITEMS == GetLastError())
			{
               done = TRUE;
               break;
            }
         }
      }
   }

   NumberDevices = i;

   // SetupDiDestroyDeviceInfoList() destroys a device information set 
   // and frees all associated memory.

   SetupDiDestroyDeviceInfoList (hardwareDeviceInfo);

   if (*UsbDevices) 
	   free(*UsbDevices);

   return hOut;
}



BOOL
//if ( !GetUsbDeviceFileName( (LPGUID) &GUID_CLASS_D12_BULK,completeDeviceName) )
GetUsbDeviceFileName( LPGUID  pGuid, char *outNameBuf)
/*++
Routine Description:

    Given a ptr to a driver-registered GUID, give us a string with the device name
    that can be used in a CreateFile() call.
    Actually briefly opens and closes the device and sets outBuf if successfull;
    returns FALSE if not 

Arguments:

    pGuid:      ptr to GUID registered by the driver itself
    outNameBuf: the generated zero-terminated name for this device

Return Value:

    TRUE on success else FALSE

--*/
{
	HANDLE hDev = OpenUsbDevice( pGuid, outNameBuf );
	if ( hDev != INVALID_HANDLE_VALUE )
	{
		CloseHandle( hDev );
		return TRUE;
	}
	return FALSE;

}

HANDLE
open_dev()
/*++
Routine Description:

    Called by dumpUsbConfig() to open an instance of our device

Arguments:

    None

Return Value:

    Device handle on success else NULL

--*/
{

	HANDLE hDEV = OpenUsbDevice( (LPGUID)&GUID_CLASS_D12_BULK, completeDeviceName);

	return hDEV;
}


HANDLE
open_file( char *filename)//hFile = open_file(threadParam->pipe_name);strcpy(m_GenericOut.pipe_name, (LPCSTR)"PIPE01");//��ʼ��ͨ��
/*++
Routine Description:

    Called by main() to open an instance of our device after obtaining its name

Arguments:

    None

Return Value:

    Device handle on success else NULL

--*/
{

	HANDLE h;
//GetUsbDeviceFileName( LPGUID  pGuid, char *outNameBuf)
//{
//	HANDLE hDev = OpenUsbDevice( pGuid, outNameBuf );
	           
//	if ( hDev != INVALID_HANDLE_VALUE )//��Ч
//	{
//		CloseHandle( hDev );//
//		return TRUE;
//	}
//	return FALSE;

//}

	if ( !GetUsbDeviceFileName( //�����ɹ����ã��򷵻�true��
		(LPGUID) &GUID_CLASS_D12_BULK, //
		completeDeviceName) )//
	{
		return  INVALID_HANDLE_VALUE; 
	}

    strcat (completeDeviceName,
			"\\"
			);			

    strcat (completeDeviceName,
			filename
			);					

	h = CreateFile(completeDeviceName,//
		GENERIC_WRITE | GENERIC_READ,
		FILE_SHARE_WRITE | FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
//        FILE_FLAG_OVERLAPPED,
		0,
		NULL);

	return h;
}


