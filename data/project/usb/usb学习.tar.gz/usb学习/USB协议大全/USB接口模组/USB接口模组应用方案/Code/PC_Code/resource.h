//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Testfirm.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTFIRM_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_FLOPY                       130
#define IDI_CDDRIVE                     131
#define IDI_CD                          132
#define IDI_FCLOSE                      133
#define IDI_DESKTOP                     134
#define IDI_DISK                        135
#define IDI_DRIVE                       136
#define IDI_MUSIC                       137
#define IDI_IC                          138
#define IDI_NORMAL                      139
#define IDI_FOPEN                       140
#define IDC_EDIT1                       1000
#define IDC_Up_Download_FileName        1000
#define IDC_EDIT2                       1001
#define IDC_DownloadFilename            1001
#define IDC_Wave_Direction_Filename     1001
#define IDC_COM_EDIT                    1002
#define IDC_COMLOW_EDIT                 1002
#define IDC_SEGLOW_EDIT                 1003
#define IDC_SEGHIGH_EDIT                1004
#define IDC_OPENUSB_BUTTON              1006
#define IDC_CLOSEUSB_BUTTON             1007
#define IDC_USBSEND_BUTTON              1008
#define IDC_USBRECEIVE_BUTTON           1009
#define IDC_USBRECEIVE_EDIT             1010
#define IDC_USBSEND_EDIT                1010
#define IDC_EDIT3                       1011
#define IDC_USBRECEIVE1_EDIT            1011
#define IDC_SPIN1                       1013
#define IDC_CONNECTTEST_BUTTON          1014
#define IDC_SETCOMSEG_BUTTON            1015
#define IDC_COMHIGH_EDIT                1016
#define IDC_MUSIC_BUTTON                1017
#define IDC_MUSIC2_BUTTON               1018
#define IDC_MUSIC3_BUTTON               1019
#define IDC_LED1ON_BUTTON               1020
#define IDC_LED2ON_BUTTON               1021
#define IDC_LED1OFF_BUTTON              1022
#define IDC_LED2OFF_BUTTON              1023
#define IDC_RECORD_BUTTON               1024
#define IDC_STOP_BUTTON                 1025
#define IDC_PLAY_BUTTON                 1026
#define IDC_UPLOAD_BUTTON               1027
#define IDC_DOWNLOAD_BUTTON             1028
#define IDC_PCFILETREE                  1029
#define IDC_REFRESH_BUTTON              1030
#define IDC_BIN_TO_WAVE_BUTTON          1031
#define IDC_BIN_FILE_DIRECTION_BUTTON   1032
#define IDC_BUTTON                      1034
#define IDC_WAVE_FILE_DIRECTION_BUTTON  1034
#define IDC_PLAY_WAVE_BUTTON            1035
#define IDC_BUTTON1                     1037
#define IDC_STOP_WAVE_BUTTON            1037
#define IDC_BUTTON2                     1038
#define IDC_BUTTON3                     1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
