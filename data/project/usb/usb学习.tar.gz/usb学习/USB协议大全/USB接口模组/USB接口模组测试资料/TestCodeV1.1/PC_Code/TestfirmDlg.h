// TestfirmDlg.h : header file
//

#if !defined(AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_)
#define AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_

#if _MSC_VER > 1000
//static char* UsbName = "\\\\.\\AbinDsDevice0";
#define NUM 64
//BYTE ByteCom[NUM];

#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestfirmDlg dialog

class CTestfirmDlg : public CDialog
{
// Construction
public:
	CTestfirmDlg(CWnd* pParent = NULL);	// standard constructor
	void CloseIfOpen(void);
//	HANDLE OpenByName(void);
	HANDLE hDeviceReadEp2;  
	HANDLE hDeviceWriteEp2;  
	HANDLE hDeviceWriteEp1;
	//BYTE ByteData[NUM];

// Dialog Data
	//{{AFX_DATA(CTestfirmDlg)
	enum { IDD = IDD_TESTFIRM_DIALOG };
	CEdit	m_UsbReceive_Edit;
	CEdit	m_UsbSend_Edit;
	int		m_Seg_Edit;
	int		m_Com_Edit;
	int		m_TestCom_Edit;
	CString	m_UsbReceive;
	int		m_ComLow_Edit;
	int		m_ComHigh_Edit;
	int		m_SegHigh_Edit;
	int		m_SegLow_Edit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestfirmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
    int ID0,ID1,ID2;
	unsigned int ulSendDataLength;
	// Generated message map functions
	//{{AFX_MSG(CTestfirmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnOpenusbButton();
	afx_msg void OnCloseusbButton();
	afx_msg void OnUsbsendButton();
	afx_msg void OnUsbreceiveButton();
	afx_msg void OnConnecttestButton();
	afx_msg void OnSetcomsegButton();
	afx_msg void OnMusicButton();
	afx_msg void OnMusic2Button();
	afx_msg void OnMusic3Button();
	afx_msg void OnLed1onButton();
	afx_msg void OnLed2onButton();
	afx_msg void OnLed1offButton();
	afx_msg void OnLed2offButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTFIRMDLG_H__9F59BEE6_0D2C_11D7_81CC_00051C10A8DE__INCLUDED_)
