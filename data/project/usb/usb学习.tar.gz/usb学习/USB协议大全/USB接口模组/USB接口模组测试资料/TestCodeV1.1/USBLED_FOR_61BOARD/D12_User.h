#ifndef	__D12DRIVER_h__
#define	__D12DRIVER_h__
//	write your header here

#define D12_INT_ENDP0OUT		(unsigned int)0x01
#define D12_INT_ENDP0IN			(unsigned int)0x02
#define D12_INT_ENDP1OUT		(unsigned int)0x04
#define D12_INT_ENDP1IN			(unsigned int)0x08
#define D12_INT_ENDP2OUT		(unsigned int)0x10
#define D12_INT_ENDP2IN			(unsigned int)0x20
#define D12_INT_BUSRESET		(unsigned int)0x40
#define D12_INT_SUSPENDCHANGE	(unsigned int)0x80
#define D12_INT_EOT				(unsigned int)0x0100
#define D12_SETUPPACKET			0x20

void D12_Control_Handler(void);
void D12_Disconnect_USB(void);
void D12_Connect_USB(void);
void D12_Reconnect_USB(void);
void D12_USB_Isr(void);
void D12_DMA_Eot(void);
void D12_Ep0_TxDone(void);
void D12_Ep0_RxDone(void);
void D12_Ep1_TxDone(void);
void D12_Ep1_RxDone(void);
void D12_Main_TxDone(void);
void D12_Main_RxDone(void);

#endif
